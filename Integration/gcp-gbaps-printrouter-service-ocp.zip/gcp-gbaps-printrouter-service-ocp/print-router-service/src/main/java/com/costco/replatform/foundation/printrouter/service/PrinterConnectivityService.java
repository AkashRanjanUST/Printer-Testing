package com.costco.replatform.foundation.printrouter.service;

import com.costco.replatform.foundation.printrouter.common.enums.DocumentType;
import com.costco.replatform.foundation.printrouter.common.enums.PrintRequestStatus;
import com.costco.replatform.foundation.printrouter.config.PrinterIppProperties;
import com.costco.replatform.foundation.printrouter.exception.ErrorCode;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrintRouteResponse;
import com.costco.replatform.foundation.printrouter.model.PrintStatusResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterIppResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class PrinterConnectivityService {

	private static final short PRINT_JOB_OPERATION_ID = 0x0002;

	private static final int OPERATION_ATTRIBUTES_TAG = 0x01;
	private static final int END_OF_ATTRIBUTES_TAG = 0x03;

	private static final int NAME_WITHOUT_LANGUAGE_TAG = 0x42;
	private static final int URI_TAG = 0x45;
	private static final int CHARSET_TAG = 0x47;
	private static final int NATURAL_LANGUAGE_TAG = 0x48;
	private static final int MIME_MEDIA_TYPE_TAG = 0x49;

	private static final int MINIMUM_IPP_RESPONSE_LENGTH = 8;

	private static final int INTEGER_TAG = 0x21;

	private static final short GET_JOB_ATTRIBUTES_OPERATION_ID = 0x0009;
	private static final int KEYWORD_TAG = 0x44;

	private final PrinterIppProperties properties;
	private final HttpClient httpClient;

	public PrinterConnectivityService(PrinterIppProperties properties) {
		this.properties = properties;

//		this.httpClient = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
//				.connectTimeout(Duration.ofSeconds(properties.getConnectTimeoutSeconds()))
//				.followRedirects(HttpClient.Redirect.NORMAL).build();
		
		this.httpClient=HttpClient.newBuilder()
		            .followRedirects(HttpClient.Redirect.ALWAYS)
		            .connectTimeout(Duration.ofSeconds(10))
		            .authenticator(new Authenticator() {
		                @Override
		                protected PasswordAuthentication getPasswordAuthentication() {

		                    log.info(
		                            "Authentication requested. Host={}, Scheme={}, Prompt={}",
		                            getRequestingHost(),
		                            getRequestingScheme(),
		                            getRequestingPrompt());

		                    return new PasswordAuthentication(
		                            properties.getDomainUsername(),
		                            properties.getPassword().toCharArray());
		                }
		            })
		            .build();
		
	}

	private static final Logger log = LoggerFactory.getLogger(PrinterConnectivityService.class);

	/**
	 * Method to do Print.
	 * 
	 * @param printRouteResponse
	 * @param routeApiResponse
	 * @param itemNo
	 * @param documentName
	 * @param documentType
	 * @param trackingId
	 * @param printContent
	 * @param printerList
	 * @return
	 */

	public ApiResponse<PrintRouteResponse> doPrint(Integer itemNo, String documentName, String documentType,
			String trackingId, String printContent, List<PrinterMetadata> printerList) {
		PrintRouteResponse printRouteResponse = new PrintRouteResponse();
		ApiResponse<PrintRouteResponse> routeApiResponse = ApiResponse.init(printRouteResponse);
		for (PrinterMetadata printerMetadata : printerList) {
			if (printerMetadata != null) {
				String printerName = printerMetadata.getPrinterName();
				String printerIp=printerMetadata.getIpAddress();
				if(printerIp==null || printerIp.equalsIgnoreCase(StringUtils.EMPTY) ||printerIp.equalsIgnoreCase("EMPTY") ) {
					log.warn("OCP_PRINT_ROUTE_EXCEPOTION::Ip addess from AD response is invalid:"+printerIp);
					return ApiResponse.error("PrinterIp is invalid");
				}
				log.info("OCP_PRINT_ROUTE::Sending IPP request to printer:" + printerIp + "...");
				Integer printResponseStatus = null;
				ApiResponse<PrinterIppResponse> printResponse = sendPrintRequest(itemNo, printerName, documentName,
						documentType, printContent,printerIp);
				log.info("OCP_PRINT_ROUTE::Print request successfully submitted to printer.TrackingID:" + trackingId
						+ "...");
				if (printResponse != null && printResponse.getResponse() != null) {
					log.info("OCP_PRINT_ROUTE::Printer Response Received:" + printResponse.getResponse().toString());
					printResponseStatus = printResponse.getResponse().getStatus();
					log.info("OCP_PRINT_ROUTE::Printer Response HTTP Status: {}", printResponseStatus);

				}
				if (printResponseStatus != null && printResponseStatus == 200) {
					routeApiResponse = ApiResponse.ok(printRouteResponse);
					routeApiResponse.getResponse().setPrintStatus(printResponse.getResponse().getPrintJobStatus());
					routeApiResponse.getResponse().setPrinterName(printerName);
					routeApiResponse.getResponse().setPrinterIp(printerIp);
					routeApiResponse.getResponse().setLocationId(printerMetadata.getLocation());
					routeApiResponse.getResponse().setPrinterIp(printerMetadata.getIpAddress());
					routeApiResponse.getResponse().setPrintJobId(printResponse.getResponse().getPrintJobId());
					if (routeApiResponse.getResponse() != null) {
						log.info("OCP_PRINT_ROUTE_SUCCESS_RESP::RouteApiResponse.getResponse(): {}",
								routeApiResponse.getResponse().toString());
					}
					log.info(
							"OCP_PRINT_ROUTE_SUCCESS::========== Print Request Routed to Printer Successfully ==========");
					return routeApiResponse;

				} else {
					routeApiResponse = ApiResponse.failures("Exception", printResponse.getResponse().getMessage(), 500);
				}
			}
		}
		return routeApiResponse;
	}

	/**
	 * Method to do Print.
	 * 
	 * @param printRouteResponse
	 * @param routeApiResponse
	 * @param itemNo
	 * @param documentName
	 * @param documentType
	 * @param trackingId
	 * @param printContent
	 * @param printerList
	 * @return
	 */

	public ApiResponse<PrintStatusResponse> doStatusCheck(Integer itemNo, String printerName, int jobId,String printerIp) {
		PrintStatusResponse printRouteResponse = new PrintStatusResponse();
		ApiResponse<PrintStatusResponse> statusApiResponse = ApiResponse.init(printRouteResponse);
		if (printerName != null) {

			log.info("OCP_PRINT_STATUS::Sending IPP request to printer:" + printerName + "...");
			Integer printResponseStatus = null;
			ApiResponse<PrinterIppResponse> printResponse = sendPrintJobStatusRequest(itemNo, printerName, jobId,printerIp);
			log.info("OCP_PRINT_STATUS::Job Statusrequest successfully submitted to printer.jobId:" + jobId + "...");
			if (printResponse != null && printResponse.getResponse() != null) {
				log.info("OCP_PRINT_STATUS::Printer Response Received:" + printResponse.getResponse().toString());
				printResponseStatus = printResponse.getResponse().getStatus();
				log.info("OCP_PRINT_STATUS::Printer Response HTTP Status: {}", printResponseStatus);

			}
			if (printResponseStatus != null && printResponseStatus == 200) {
				statusApiResponse = ApiResponse.ok(printRouteResponse);
				statusApiResponse.getResponse().setPrintJobStatus(printResponse.getResponse().getPrintJobStatus());
				statusApiResponse.getResponse().setPrinterName(printerName);
				statusApiResponse.getResponse().setPrinterIp(printerIp);
				statusApiResponse.getResponse().setPrintJobId(jobId);
				log.info("OCP_PRINT_STATUS_SUCCESS_RESP::RouteApiResponse.getResponse(): {}",
						statusApiResponse.getResponse());
				log.info(
						"OCP_PRINT_STATUS_SUCCESS::========== Print Status Request send to Printer Successfully ==========");
				return statusApiResponse;

			}
		}

		return statusApiResponse;
	}

	/**
	 * Sends the configured plain-text content to the configured IPP queue.
	 * 
	 * @param itemNo
	 * @param printerName
	 * @param printerJobName
	 * @return
	 */
//	private ApiResponse<PrinterIppResponse> sendPrintRequest(int itemNo, String printerName, String printerJobName,
//			String docType, String printContent) {
//		// int requestId = ThreadLocalRandom.current().nextInt(1, Integer.MAX_VALUE);
//
//		try {
//			validateInput();
//
//			byte[] ippRequest = buildIppPrintRequest(itemNo, printerName, printerJobName, docType, printContent);
//
//			HttpRequest httpRequest = buildHttpRequest(ippRequest);
//
//			HttpResponse<byte[]> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofByteArray());
//
//			PrinterIppResponse printerResponse = processResponse(httpResponse, itemNo);
//
//			if (printerResponse.isOk()) {
//				return ApiResponse.ok(printerResponse);
//			}
//
//			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), printerResponse.getMessage(),
//					getFailureHttpStatus(printerResponse));
//
//		} catch (IllegalArgumentException exception) {
//			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), exception.getMessage(),
//					HttpStatus.BAD_REQUEST.value());
//
//		} catch (InterruptedException exception) {
//			Thread.currentThread().interrupt();
//
//			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), "IPP print request was interrupted",
//					HttpStatus.INTERNAL_SERVER_ERROR.value());
//
//		} catch (IOException exception) {
//			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(),
//					"IPP communication failed: " + getExceptionMessage(exception), HttpStatus.BAD_GATEWAY.value());
//
//		} catch (Exception exception) {
//			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(),
//					"Unexpected error while sending IPP request: " + getExceptionMessage(exception),
//					HttpStatus.INTERNAL_SERVER_ERROR.value());
//		}
//	}

	private ApiResponse<PrinterIppResponse> sendPrintRequest(int itemNo, String printerName, String printerJobName,
			String docType, String printContent,String printerIp) {

		try {

			validateInput();

			byte[] ippRequest = buildIppPrintRequest(itemNo, printerName, printerJobName, docType, printContent,printerIp);

			HttpRequest httpRequest = buildHttpRequest(ippRequest,printerIp);

			log.info("Sending IPP request...");
			log.info("Request Id      : {}", itemNo);
			log.info("Printer Name    : {}", printerName);
			log.info("Print Job Name  : {}", printerJobName);
			log.info("Queue URL       : {}", properties.getQueueUrl());

			HttpResponse<byte[]> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofByteArray());

			log.info("HTTP Status: {}", httpResponse.statusCode());

			httpResponse.headers().map().forEach((name, values) -> log.info("Header: {}={}", name, values));

			if (httpResponse.statusCode() == 401) {

				String responseBody = new String(httpResponse.body(), StandardCharsets.UTF_8);

				log.error("Authentication failed.");
				log.error("Response Body: {}", responseBody);

				return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(),
						"Authentication failed. Server returned HTTP 401.", HttpStatus.UNAUTHORIZED.value());
			}

			PrinterIppResponse printerResponse = processResponse(httpResponse, itemNo);

			if (printerResponse.isOk()) {
				return ApiResponse.ok(printerResponse);
			}

			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), printerResponse.getMessage(),
					getFailureHttpStatus(printerResponse));

		} catch (IllegalArgumentException exception) {

			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), exception.getMessage(),
					HttpStatus.BAD_REQUEST.value());

		} catch (InterruptedException exception) {

			Thread.currentThread().interrupt();

			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), "IPP print request was interrupted",
					HttpStatus.INTERNAL_SERVER_ERROR.value());

		} catch (IOException exception) {

			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(),
					"IPP communication failed: " + getExceptionMessage(exception), HttpStatus.BAD_GATEWAY.value());

		} catch (Exception exception) {

			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(),
					"Unexpected error while sending IPP request: " + getExceptionMessage(exception),
					HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}
	
	
	

	/**
	 * Sends the configured plain-text content to the configured IPP queue.
	 * 
	 * @param itemNo
	 * @param printerName
	 * @param printerJobName
	 * @return
	 */
	private ApiResponse<PrinterIppResponse> sendPrintJobStatusRequest(int itemNo, String printerName, int jobId,String printerIp) {
		// int requestId = ThreadLocalRandom.current().nextInt(1, Integer.MAX_VALUE);

		try {
			validateInput();

			byte[] ippRequest = buildIppPrintJobStatusRequest(itemNo, printerName, jobId,printerIp);

			HttpRequest httpRequest = buildHttpRequest(ippRequest,printerIp);

			HttpResponse<byte[]> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofByteArray());

			PrinterIppResponse printerResponse = processResponse(httpResponse, itemNo);

			if (printerResponse.isOk()) {
				return ApiResponse.ok(printerResponse);
			}

			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), printerResponse.getMessage(),
					getFailureHttpStatus(printerResponse));

		} catch (IllegalArgumentException exception) {
			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), exception.getMessage(),
					HttpStatus.BAD_REQUEST.value());

		} catch (InterruptedException exception) {
			Thread.currentThread().interrupt();

			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), "IPP print request was interrupted",
					HttpStatus.INTERNAL_SERVER_ERROR.value());

		} catch (IOException exception) {
			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(),
					"IPP communication failed: " + getExceptionMessage(exception), HttpStatus.BAD_GATEWAY.value());

		} catch (Exception exception) {
			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(),
					"Unexpected error while sending IPP request: " + getExceptionMessage(exception),
					HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}

	/**
	 * Method to build Get Job Status Ipp Request.
	 * 
	 * @param requestId
	 * @param printerName
	 * @param jobId
	 * @return
	 * @throws IOException
	 */
	private byte[] buildIppPrintJobStatusRequest(int itemNo, String printerName, int jobId,String printerIp) throws IOException {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		try (DataOutputStream output = new DataOutputStream(buffer)) {
			// IPP Version 1.1
			output.writeByte(0x01);
			output.writeByte(0x01);
			// Get-Job-Attributes
			output.writeShort(GET_JOB_ATTRIBUTES_OPERATION_ID);
			output.writeInt(itemNo);
			output.writeByte(OPERATION_ATTRIBUTES_TAG);
			writeStringAttribute(output, CHARSET_TAG, "attributes-charset", "utf-8");
			writeStringAttribute(output, NATURAL_LANGUAGE_TAG, "attributes-natural-language", "en");
			writeStringAttribute(output, URI_TAG, "printer-uri", "http://"+printerIp);

			// Job ID to query
			writeIntegerAttribute(output, 0x21, "job-id", jobId);
			// Request only required status attribute
			writeStringAttribute(output, KEYWORD_TAG, "requested-attributes", "job-state");
			output.writeByte(END_OF_ATTRIBUTES_TAG);
			output.flush();
		}

		return buffer.toByteArray();
	}

	/**
	 * Method to build Http Request.
	 * 
	 * @param ippRequest
	 * @return
	 */
//	private HttpRequest buildHttpRequest(byte[] ippRequest) {
//		String authorizationHeader = buildBasicAuthorizationHeader();
//
//		return HttpRequest.newBuilder().uri(URI.create(properties.getQueueUrl()))
//				.timeout(Duration.ofSeconds(properties.getRequestTimeoutSeconds()))
//				.header("Content-Type", "application/ipp").header("Accept", "application/ipp")
//				.header("Authorization", authorizationHeader).POST(HttpRequest.BodyPublishers.ofByteArray(ippRequest))
//				.build();
//	}

	private HttpRequest buildHttpRequest(byte[] ippRequest,String printerIp) {

		log.info("IPP Endpoint: {}", properties.getQueueUrl());
		return HttpRequest.newBuilder().uri(URI.create("http://"+printerIp))
				.timeout(Duration.ofSeconds(properties.getRequestTimeoutSeconds()))
				.header("Content-Type", "application/ipp").header("Accept", "application/ipp")
				.POST(HttpRequest.BodyPublishers.ofByteArray(ippRequest)).build();
	}

	/**
	 * Method to build auth header.
	 * 
	 * @return
	 */
	private String buildBasicAuthorizationHeader() {
		String credentials = properties.getDomainUsername() + ":" + properties.getPassword();
		return "Basic " + Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
	}

	/**
	 * Method to build Request.
	 * 
	 * @param itemNumber
	 * @param printerName
	 * @param printJobName
	 * @return
	 * @throws IOException
	 */
	private byte[] buildIppPrintRequest(int itemNumber, String printerName, String printJobName, String documentType,
			String printContent,String printerIp) throws IOException {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();

		try (DataOutputStream output = new DataOutputStream(buffer)) {

			output.writeByte(0x01);
			output.writeByte(0x01);

			output.writeShort(PRINT_JOB_OPERATION_ID);
			output.writeInt(itemNumber);

			output.writeByte(OPERATION_ATTRIBUTES_TAG);

			writeStringAttribute(output, CHARSET_TAG, "attributes-charset", "utf-8");

			writeStringAttribute(output, NATURAL_LANGUAGE_TAG, "attributes-natural-language", "en");

			writeStringAttribute(output, URI_TAG, "printer-uri",  "http://"+printerIp);

			writeStringAttribute(output, NAME_WITHOUT_LANGUAGE_TAG, "requesting-user-name",
					properties.getRequestingUser());

			writeStringAttribute(output, NAME_WITHOUT_LANGUAGE_TAG, "job-name", properties.getJobName() + printJobName);

			writeStringAttribute(output, MIME_MEDIA_TYPE_TAG, "document-format", "text/plain");

			// Print 10 copies
			// writeIntegerAttribute(output, 0x21, "copies", 10);

			output.writeByte(END_OF_ATTRIBUTES_TAG);

			output.write(properties.getPrintContent().getBytes(StandardCharsets.UTF_8));

			// byte[] documentBytes = getDocumentBytes(documentType, printContent);

			// output.write(documentBytes);

			output.flush();
		}

		return buffer.toByteArray();
	}

	/**
	 * Method to get document Types.
	 * 
	 * @param documentType
	 * @param printContent
	 * @return
	 */
	private byte[] getDocumentBytes(String documentType, String printContent) {
		byte[] documentBytes = null;

		if (DocumentType.PDF.name().equalsIgnoreCase(documentType)) {

			// PDF bytes were stored in String
			// Recover original bytes using ISO-8859-1
			documentBytes = printContent.getBytes(StandardCharsets.ISO_8859_1);

		} else if (DocumentType.ZPL.name().equalsIgnoreCase(documentType)) {

			// ZPL text
			documentBytes = printContent.getBytes(StandardCharsets.UTF_8);

		} else {

			// Fallback
			documentBytes = printContent.getBytes(StandardCharsets.UTF_8);
		}
		return documentBytes;
	}

	private void writeStringAttribute(DataOutputStream output, int valueTag, String attributeName,
			String attributeValue) throws IOException {
		byte[] nameBytes = attributeName.getBytes(StandardCharsets.US_ASCII);

		byte[] valueBytes = attributeValue.getBytes(StandardCharsets.UTF_8);

		output.writeByte(valueTag);

		output.writeShort(nameBytes.length);
		output.write(nameBytes);

		output.writeShort(valueBytes.length);
		output.write(valueBytes);
	}

	/**
	 * Method to write Integer Attribute
	 * 
	 * @param output
	 * @param valueTag
	 * @param attributeName
	 * @param value
	 * @throws IOException
	 */

	private void writeIntegerAttribute(DataOutputStream output, int valueTag, String attributeName, int value)
			throws IOException {

		output.writeByte(valueTag); // 0x21 = integer

		byte[] nameBytes = attributeName.getBytes(StandardCharsets.US_ASCII);
		output.writeShort(nameBytes.length);
		output.write(nameBytes);

		output.writeShort(4); // integer value length
		output.writeInt(value);
	}

	private PrinterIppResponse processResponse(HttpResponse<byte[]> response, int itemNumber) {
		int httpStatus = response.statusCode();
		byte[] responseBody = response.body();

		if (httpStatus == HttpStatus.UNAUTHORIZED.value()) {
			String authenticationScheme = response.headers().firstValue("WWW-Authenticate").orElse("Not provided");

			return buildPrinterResponse(httpStatus, null, itemNumber,
					"HTTP authentication failed. Scheme: " + authenticationScheme, false, null);
		}

		if (httpStatus == HttpStatus.FORBIDDEN.value()) {
			return buildPrinterResponse(httpStatus, null, itemNumber, "User is not authorized to print to this queue",
					false, null);
		}

		if (httpStatus == HttpStatus.NOT_FOUND.value()) {
			return buildPrinterResponse(httpStatus, null, itemNumber, "IPP queue URL was not found", false, null);
		}

		if (httpStatus < 200 || httpStatus >= 300) {
			return buildPrinterResponse(httpStatus, null, itemNumber,
					"IPP HTTP request failed with status " + httpStatus, false, null);
		}

		if (responseBody == null || responseBody.length < MINIMUM_IPP_RESPONSE_LENGTH) {
			return buildPrinterResponse(httpStatus, null, itemNumber,
					"HTTP request succeeded, but the response " + "is not a valid IPP response", false, null);
		}

		int ippMajorVersion = responseBody[0] & 0xFF;
		int ippMinorVersion = responseBody[1] & 0xFF;

		int ippStatus = ((responseBody[2] & 0xFF) << 8) | (responseBody[3] & 0xFF);

		int responseRequestId = ((responseBody[4] & 0xFF) << 24) | ((responseBody[5] & 0xFF) << 16)
				| ((responseBody[6] & 0xFF) << 8) | (responseBody[7] & 0xFF);

		if (responseRequestId != itemNumber) {
			return buildPrinterResponse(httpStatus, ippStatus, responseRequestId,
					"IPP response request ID mismatch. Expected: " + itemNumber + ", received: " + responseRequestId,
					false, null);
		}

		String statusMessage = "IPP version: " + ippMajorVersion + "." + ippMinorVersion + ", status: "
				+ String.format("0x%04X", ippStatus) + " " + getIppStatusDescription(ippStatus);

		if (ippStatus <= 0x00FF) { // 200-OK
			Integer jobId = extractJobId(responseBody);
			Integer jobState = extractJobState(responseBody);
		PrinterIppResponse	responseObj= buildPrinterResponse(httpStatus, ippStatus, responseRequestId,
					"Print job accepted. " + statusMessage, true, jobId);
			 if (jobState != null) {
			        responseObj.setPrintJobStatus(getJobStateDescription(jobState));
			    }
			 return responseObj;
		}

		return buildPrinterResponse(httpStatus, ippStatus, responseRequestId, "Print job rejected. " + statusMessage,
				false, null);
	}
	
	
	/**
	 * Method to get Job description.
	 * @param state
	 * @return
	 */
	private String getJobStateDescription(Integer state) {

	    if (state == null) {
	        return null;
	    }

	    switch (state) {
	        case 3:
	            return "PENDING";

	        case 4:
	            return "PENDING_HELD";

	        case 5:
	            return "PROCESSING";

	        case 6:
	            return "STOPPED";

	        case 7:
	            return "CANCELED";

	        case 8:
	            return "ABORTED";

	        case 9:
	            return "COMPLETED";

	        default:
	            return "UNKNOWN(" + state + ")";
	    }
	}
	
	
	/**
	 * Method to get job state.
	 * @param ippResponse
	 * @return
	 */
	
	private Integer extractJobState(byte[] ippResponse) {

	    try {

	        for (int i = 0; i < ippResponse.length - 20; i++) {

	            if ((ippResponse[i] & 0xFF) == 0x23) { // enum value tag

	                int nameLength =
	                        ((ippResponse[i + 1] & 0xFF) << 8)
	                                | (ippResponse[i + 2] & 0xFF);

	                if (nameLength <= 0 || i + 3 + nameLength >= ippResponse.length) {
	                    continue;
	                }

	                String attributeName =
	                        new String(
	                                ippResponse,
	                                i + 3,
	                                nameLength,
	                                StandardCharsets.US_ASCII);

	                if ("job-state".equals(attributeName)) {

	                    int valueLengthIndex = i + 3 + nameLength;

	                    int valueLength =
	                            ((ippResponse[valueLengthIndex] & 0xFF) << 8)
	                                    | (ippResponse[valueLengthIndex + 1] & 0xFF);

	                    if (valueLength == 4) {

	                        int valueIndex = valueLengthIndex + 2;

	                        return ((ippResponse[valueIndex] & 0xFF) << 24)
	                                | ((ippResponse[valueIndex + 1] & 0xFF) << 16)
	                                | ((ippResponse[valueIndex + 2] & 0xFF) << 8)
	                                | (ippResponse[valueIndex + 3] & 0xFF);
	                    }
	                }
	            }
	        }

	    } catch (Exception ex) {
	        log.warn("Unable to parse job-state", ex);
	    }

	    return null;
	}

	/**
	 * Method to get jobId.
	 * 
	 * @param ippResponse
	 * @return
	 */
	private Integer extractJobId(byte[] ippResponse) {

		int pos = 8; // Skip IPP header

		while (pos < ippResponse.length) {

			int tag = ippResponse[pos++] & 0xFF;

			if (tag == 0x03) { // end-of-attributes-tag
				break;
			}

			if (tag <= 0x0F) {
				continue; // delimiter tags
			}

			if (pos + 2 > ippResponse.length)
				break;

			int nameLength = ((ippResponse[pos] & 0xFF) << 8) | (ippResponse[pos + 1] & 0xFF);
			pos += 2;

			if (pos + nameLength > ippResponse.length)
				break;

			String name = new String(ippResponse, pos, nameLength, java.nio.charset.StandardCharsets.UTF_8);
			pos += nameLength;

			int valueLength = ((ippResponse[pos] & 0xFF) << 8) | (ippResponse[pos + 1] & 0xFF);
			pos += 2;

			if (pos + valueLength > ippResponse.length)
				break;

			if ("job-id".equals(name) && valueLength == 4) {
				return ((ippResponse[pos] & 0xFF) << 24) | ((ippResponse[pos + 1] & 0xFF) << 16)
						| ((ippResponse[pos + 2] & 0xFF) << 8) | (ippResponse[pos + 3] & 0xFF);
			}

			pos += valueLength;
		}

		return null;
	}

	private PrinterIppResponse buildPrinterResponse(int httpStatus, Integer ippStatus, int requestId, String message,
			boolean success, Integer printJobId) {
		PrinterIppResponse response = new PrinterIppResponse();
		response.setOk(success);
		// data.setTransId("TXN12345");
		response.setStatus(httpStatus);
		response.setMessage(message);
		// response.setPrinterName("Zebra-01");
		response.setPrintJobId(printJobId);
		//response.setPrintJobStatus("SUBMITTED");
		return response;
	}

	private int getFailureHttpStatus(PrinterIppResponse printerResponse) {
		int status = printerResponse.getStatus();

		if (status >= 400 && status <= 599) {
			return status;
		}

		return HttpStatus.BAD_GATEWAY.value();
	}

	private String getIppStatusDescription(int ippStatus) {
		return switch (ippStatus) {
		case 0x0000 -> "successful-ok";
		case 0x0001 -> "successful-ok-ignored-or-substituted-attributes";
		case 0x0002 -> "successful-ok-conflicting-attributes";
		case 0x0400 -> "client-error-bad-request";
		case 0x0401 -> "client-error-forbidden";
		case 0x0402 -> "client-error-not-authenticated";
		case 0x0403 -> "client-error-not-authorized";
		case 0x0404 -> "client-error-not-possible";
		case 0x0406 -> "client-error-not-found";
		case 0x040A -> "client-error-document-format-not-supported";
		case 0x0500 -> "server-error-internal-error";
		case 0x0501 -> "server-error-operation-not-supported";
		case 0x0502 -> "server-error-service-unavailable";
		case 0x0503 -> "server-error-version-not-supported";
		default -> String.format("unknown-ipp-status-0x%04X", ippStatus);
		};
	}

	private void validateInput() {
		if (isBlank(properties.getQueueUrl())) {
			throw new IllegalArgumentException("Queue URL must not be empty");
		}

		URI queueUri;

		try {
			queueUri = URI.create(properties.getQueueUrl());
		} catch (IllegalArgumentException exception) {
			throw new IllegalArgumentException("Queue URL is invalid", exception);
		}

		String scheme = queueUri.getScheme();

		if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
			throw new IllegalArgumentException("Queue URL must use HTTP or HTTPS");
		}

		if (isBlank(queueUri.getHost())) {
			throw new IllegalArgumentException("Queue URL must contain a valid host");
		}

		if (isBlank(queueUri.getPath()) || "/".equals(queueUri.getPath())) {
			throw new IllegalArgumentException("Queue URL must contain an IPP queue path");
		}

		if (isBlank(properties.getRequestingUser())) {
			throw new IllegalArgumentException("Requesting user must not be empty");
		}

		if (isBlank(properties.getDomainUsername())) {
			throw new IllegalArgumentException("Authentication username must not be empty");
		}

		if (isBlank(properties.getPassword())) {
			throw new IllegalArgumentException("Authentication password must not be empty");
		}

		if (isBlank(properties.getJobName())) {
			throw new IllegalArgumentException("Job name must not be empty");
		}

		if (isBlank(properties.getPrintContent())) {
			throw new IllegalArgumentException("Print content must not be empty");
		}

		if (properties.getConnectTimeoutSeconds() <= 0) {
			throw new IllegalArgumentException("Connect timeout must be greater than zero");
		}

		if (properties.getRequestTimeoutSeconds() <= 0) {
			throw new IllegalArgumentException("Request timeout must be greater than zero");
		}
	}

	private boolean isBlank(String value) {
		return value == null || value.isBlank();
	}

	private String getExceptionMessage(Exception exception) {
		return isBlank(exception.getMessage()) ? exception.getClass().getSimpleName() : exception.getMessage();
	}
}