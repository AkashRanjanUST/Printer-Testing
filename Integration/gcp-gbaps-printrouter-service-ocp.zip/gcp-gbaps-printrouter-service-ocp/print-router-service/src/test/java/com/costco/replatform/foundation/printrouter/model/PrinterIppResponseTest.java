package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class PrinterIppResponseTest {

    @Test
    @DisplayName("Default values are initialized correctly")
    void defaults() {

        PrinterIppResponse response = new PrinterIppResponse();

        assertThat(response.isOk()).isFalse();
        assertThat(response.getTransId()).isNull();
        assertThat(response.getStatus()).isZero();
        assertThat(response.getMessage()).isNull();
        assertThat(response.getPrinterName()).isNull();
        assertThat(response.getPrinterIp()).isNull();
        assertThat(response.getPrintJobId()).isNull();
        assertThat(response.getPrintJobStatus()).isNull();
    }

    @Test
    @DisplayName("Setters and getters round-trip every field")
    void settersAndGetters_roundTrip() {

        PrinterIppResponse response = new PrinterIppResponse();

        response.setOk(true);
        response.setTransId("TX-001");
        response.setStatus(200);
        response.setMessage("Print successful");
        response.setPrinterName("Laser1");
        response.setPrinterIp("10.10.10.10");
        response.setPrintJobId(12345);
        response.setPrintJobStatus("COMPLETED");

        assertThat(response.isOk()).isTrue();
        assertThat(response.getTransId()).isEqualTo("TX-001");
        assertThat(response.getStatus()).isEqualTo(200);
        assertThat(response.getMessage()).isEqualTo("Print successful");
        assertThat(response.getPrinterName()).isEqualTo("Laser1");
        assertThat(response.getPrinterIp()).isEqualTo("10.10.10.10");
        assertThat(response.getPrintJobId()).isEqualTo(12345);
        assertThat(response.getPrintJobStatus()).isEqualTo("COMPLETED");
    }

    @Test
    @DisplayName("setStatus(Integer null) keeps default zero")
    void setStatusNull_onNewObject_keepsZero() {

        PrinterIppResponse response = new PrinterIppResponse();

        response.setStatus((Integer) null);

        assertThat(response.getStatus()).isZero();
    }

    @Test
    @DisplayName("setStatus(Integer null) keeps existing value")
    void setStatusNull_afterValue_keepsPreviousValue() {

        PrinterIppResponse response = new PrinterIppResponse();

        response.setStatus(400);

        response.setStatus((Integer) null);

        assertThat(response.getStatus()).isEqualTo(400);
    }

    @Test
    @DisplayName("setStatus(int) updates status")
    void setStatusPrimitive_updatesValue() {

        PrinterIppResponse response = new PrinterIppResponse();

        response.setStatus(201);

        assertThat(response.getStatus()).isEqualTo(201);
    }

    @Test
    @DisplayName("toString contains significant field values")
    void toString_containsFields() {

        PrinterIppResponse response = new PrinterIppResponse();

        response.setOk(true);
        response.setTransId("TX-001");
        response.setStatus(200);
        response.setMessage("Success");
        response.setPrinterName("Laser1");
        response.setPrinterIp("10.10.10.10");
        response.setPrintJobId(123);
        response.setPrintJobStatus("PRINTED");

        String value = response.toString();

        assertThat(value)
                .contains("TX-001")
                .contains("Success")
                .contains("Laser1")
                .contains("10.10.10.10")
                .contains("123")
                .contains("PRINTED");
    }
}