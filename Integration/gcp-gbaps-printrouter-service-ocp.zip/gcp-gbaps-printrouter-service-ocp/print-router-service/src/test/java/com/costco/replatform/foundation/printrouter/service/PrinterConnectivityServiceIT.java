package com.costco.replatform.foundation.printrouter.service;

import com.costco.replatform.foundation.printrouter.config.PrinterIppProperties;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrintRouteResponse;
import com.costco.replatform.foundation.printrouter.model.PrintStatusResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;
import com.github.tomakehurst.wiremock.junit5.WireMockExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import java.nio.ByteBuffer;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;

class PrinterConnectivityServiceIT {

    @RegisterExtension
    static WireMockExtension wireMock =
            WireMockExtension.newInstance()
                    .options(wireMockConfig().dynamicPort())
                    .build();

    private PrinterConnectivityService service;

    @BeforeEach
    void setUp() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setQueueUrl(
                "http://localhost/printers/");

        properties.setRequestingUser("test-user");
        properties.setDomainUsername("TEST\\test-user");
        properties.setPassword("test-password");
        properties.setJobName("IT_JOB_");
        properties.setPrintContent("Integration Test Content");
        properties.setConnectTimeoutSeconds(1);
        properties.setRequestTimeoutSeconds(2);

        service =
                new PrinterConnectivityService(properties);
    }

    private static byte[] ippResponse(
            int ippStatus,
            int requestId) {

        return ByteBuffer.allocate(8)
                .put((byte) 1)
                .put((byte) 1)
                .putShort((short) ippStatus)
                .putInt(requestId)
                .array();
    }

    private PrinterMetadata printer() {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("Laser1");
        printer.setLocation("01680");
        printer.setIpAddress(
                "localhost:" + wireMock.getPort());

        return printer;
    }

    @Test
    @DisplayName("doPrint returns error when printer IP is null")
    void doPrint_nullIp_returnsError() {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("Laser1");
        printer.setIpAddress(null);

        ApiResponse<PrintRouteResponse> result =
                service.doPrint(
                        7,
                        "DOC",
                        "PDF",
                        "TRACK1",
                        "CONTENT",
                        List.of(printer));

        assertThat(result.isSuccess())
                .isFalse();

        assertThat(result.getMessage())
                .isEqualTo("PrinterIp is invalid");
    }

    @Test
    @DisplayName("doPrint returns error when printer IP is empty")
    void doPrint_emptyIp_returnsError() {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("Laser1");
        printer.setIpAddress("");

        ApiResponse<PrintRouteResponse> result =
                service.doPrint(
                        7,
                        "DOC",
                        "PDF",
                        "TRACK1",
                        "CONTENT",
                        List.of(printer));

        assertThat(result.isSuccess())
                .isFalse();

        assertThat(result.getMessage())
                .isEqualTo("PrinterIp is invalid");
    }

    @Test
    @DisplayName("doPrint succeeds when server returns successful IPP response")
    void doPrint_success() {

        wireMock.stubFor(
                post(anyUrl())
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withBody(
                                                ippResponse(
                                                        0x0000,
                                                        7))));

        ApiResponse<PrintRouteResponse> result =
                service.doPrint(
                        7,
                        "DOCUMENT",
                        "PDF",
                        "TRACK1",
                        "CONTENT",
                        List.of(printer()));

        assertThat(result.isSuccess())
                .isTrue();

        assertThat(result.getResponse())
                .isNotNull();

        assertThat(result.getResponse()
                .getPrinterName())
                .isEqualTo("Laser1");

        assertThat(result.getResponse()
                .getPrinterIp())
                .contains("localhost");

        assertThat(result.getResponse()
                .getLocationId())
                .isEqualTo("01680");
        wireMock.verify(
                1,
                postRequestedFor(anyUrl())
                        .withHeader(
                                "Content-Type",
                                equalTo("application/ipp"))
                        .withHeader(
                                "Accept",
                                equalTo("application/ipp")));
    }

    @Test
    @DisplayName("doStatusCheck succeeds when server returns successful IPP response")
    void doStatusCheck_success() {

        wireMock.stubFor(
                post(anyUrl())
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withBody(
                                                ippResponse(
                                                        0x0000,
                                                        7))));

        ApiResponse<PrintStatusResponse> result =
                service.doStatusCheck(
                        7,
                        "Laser1",
                        100,
                        "localhost:" + wireMock.getPort());

        assertThat(result.isSuccess())
                .isTrue();

        assertThat(result.getResponse())
                .isNotNull();

        assertThat(result.getResponse()
                .getPrinterName())
                .isEqualTo("Laser1");

        assertThat(result.getResponse()
                .getPrinterIp())
                .contains("localhost");
    }

    @Test
    @DisplayName("CURRENT BEHAVIOUR: doPrint throws NPE when printer server is unavailable")
    void doPrint_serverUnavailable_currentlyThrowsNpe() {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("Laser1");
        printer.setLocation("01680");
        printer.setIpAddress("127.0.0.1:1");

        assertThatThrownBy(() ->
                service.doPrint(
                        7,
                        "DOCUMENT",
                        "PDF",
                        "TRACK1",
                        "CONTENT",
                        List.of(printer)))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    @DisplayName("doStatusCheck fails when server is unavailable")
    void doStatusCheck_serverUnavailable() {

        ApiResponse<PrintStatusResponse> result =
                service.doStatusCheck(
                        7,
                        "Laser1",
                        100,
                        "localhost:1");

        assertThat(result).isNotNull();

        assertThat(result).isNotNull();
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getResponse()).isNotNull();
    }
    @Test
    @DisplayName("CURRENT BEHAVIOUR: rejected IPP print response results in NPE")
    void doPrint_ippRejected_currentlyThrowsNpe() {

        wireMock.stubFor(
                post(anyUrl())
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withHeader(
                                                "Content-Type",
                                                "application/ipp")
                                        .withBody(
                                                ippResponse(
                                                        0x0406,
                                                        7))));

        assertThatThrownBy(() ->
                service.doPrint(
                        7,
                        "DOCUMENT",
                        "PDF",
                        "TRACK1",
                        "CONTENT",
                        List.of(printer())))
                .isInstanceOf(NullPointerException.class);
    }
    @Test
    @DisplayName("CURRENT BEHAVIOUR: HTTP 500 print response results in NPE")
    void doPrint_http500_currentlyThrowsNpe() {

        wireMock.stubFor(
                post(anyUrl())
                        .willReturn(
                                aResponse()
                                        .withStatus(500)
                                        .withBody("Printer unavailable")));

        assertThatThrownBy(() ->
                service.doPrint(
                        7,
                        "DOCUMENT",
                        "PDF",
                        "TRACK1",
                        "CONTENT",
                        List.of(printer())))
                .isInstanceOf(NullPointerException.class);
    }
}