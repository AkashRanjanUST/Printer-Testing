package com.costco.replatform.foundation.printrouter.service;

import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterDiscoveryResponse;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.Authenticator;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

import static org.assertj.core.api.Assertions.assertThat;

class PrinterDiscoveryServiceTest {

    private static final String PRINTER_PATH =
            "/printers/TestPrinter/.printer";

    private PrinterDiscoveryService service;
    private HttpServer server;

    @BeforeEach
    void setUp() {

        service = new PrinterDiscoveryService();

        ReflectionTestUtils.setField(
                service,
                "targetUrl",
                "http://test-server");

        ReflectionTestUtils.setField(
                service,
                "printerPath",
                "/printer");

        ReflectionTestUtils.setField(
                service,
                "printerName",
                "TestPrinter");

        ReflectionTestUtils.setField(
                service,
                "authUsername",
                "TEST\\test-user");

        ReflectionTestUtils.setField(
                service,
                "authPassword",
                "test-password");

        ReflectionTestUtils.setField(
                service,
                "authDomain",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "connectTimeout",
                2000);

        ReflectionTestUtils.setField(
                service,
                "readTimeout",
                2000);
    }

    @AfterEach
    void tearDown() {

        if (server != null) {
            server.stop(0);
        }

        /*
         * PrinterDiscoveryService installs a JVM-wide Authenticator,
         * so reset it after every test.
         */
        Authenticator.setDefault(null);
    }

    private String startServer(
            int status,
            byte[] responseBody)
            throws Exception {

        server = HttpServer.create(
                new InetSocketAddress(
                        InetAddress.getLoopbackAddress(),
                        0),
                0);

        server.createContext("/", exchange -> {

            exchange.getRequestBody().readAllBytes();

            if (responseBody == null
                    || responseBody.length == 0) {

                exchange.sendResponseHeaders(
                        status,
                        -1);

            } else {

                exchange.sendResponseHeaders(
                        status,
                        responseBody.length);

                try (OutputStream output =
                             exchange.getResponseBody()) {

                    output.write(responseBody);
                }
            }

            exchange.close();
        });

        server.start();

        return "http://127.0.0.1:"
                + server.getAddress().getPort();
    }

    private void configureForServer(
            String baseUrl) {

        ReflectionTestUtils.setField(
                service,
                "targetUrl",
                baseUrl);

        ReflectionTestUtils.setField(
                service,
                "printerPath",
                PRINTER_PATH);
    }

    /*
     * -------------------------------------------------------------
     * buildIppUri
     * -------------------------------------------------------------
     */

    @Test
    void buildIppUri_http() throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "buildIppUri",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        "http://server/printer");

        assertThat(result)
                .isEqualTo(
                        "ipp://server/printer");
    }

    @Test
    void buildIppUri_https() throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "buildIppUri",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        "https://server/printer");

        assertThat(result)
                .isEqualTo(
                        "ipps://server/printer");
    }

    /*
     * -------------------------------------------------------------
     * createSampleIppPayload
     * -------------------------------------------------------------
     */

    @Test
    void createSampleIppPayload_returnsExpectedBytes()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "createSampleIppPayload");

        method.setAccessible(true);

        byte[] result =
                (byte[]) method.invoke(service);

        assertThat(result)
                .containsExactly(
                        (byte) 0x02,
                        (byte) 0x00,
                        (byte) 0x00,
                        (byte) 0x02);
    }

    /*
     * -------------------------------------------------------------
     * buildTargetUrl
     * -------------------------------------------------------------
     */

    @Test
    void buildTargetUrl_returnsCombinedUrl()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "buildTargetUrl");

        method.setAccessible(true);

        String result =
                (String) method.invoke(service);

        assertThat(result)
                .isEqualTo(
                        "http://test-server/printer");
    }

    /*
     * -------------------------------------------------------------
     * handleSuccess
     * -------------------------------------------------------------
     */

    @Test
    void handleSuccess_setsSuccessStatus()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "handleSuccess",
                                PrinterDiscoveryResponse.class,
                                byte[].class);

        method.setAccessible(true);

        PrinterDiscoveryResponse response =
                new PrinterDiscoveryResponse();

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                response,
                                new byte[]{1, 2, 3});

        assertThat(result.getStatus())
                .isEqualTo("SUCCESS");

        assertThat(result.getMessage())
                .isEqualTo(
                        "IPP request transmitted successfully");
    }

    @Test
    void handleSuccess_emptyBody()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "handleSuccess",
                                PrinterDiscoveryResponse.class,
                                byte[].class);

        method.setAccessible(true);

        PrinterDiscoveryResponse response =
                new PrinterDiscoveryResponse();

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                response,
                                new byte[0]);

        assertThat(result.getStatus())
                .isEqualTo("SUCCESS");

        assertThat(result.getMessage())
                .isEqualTo(
                        "IPP request transmitted successfully");
    }

    /*
     * -------------------------------------------------------------
     * handleServerError
     * -------------------------------------------------------------
     */

    @Test
    void handleServerError_setsFailedStatus()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "handleServerError",
                                PrinterDiscoveryResponse.class,
                                byte[].class);

        method.setAccessible(true);

        PrinterDiscoveryResponse response =
                new PrinterDiscoveryResponse();

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                response,
                                "error".getBytes(
                                        StandardCharsets.UTF_8));

        assertThat(result.getStatus())
                .isEqualTo("FAILED");

        assertThat(result.getErrorType())
                .isEqualTo("SERVER_ERROR");

        assertThat(result.getMessage())
                .isEqualTo("error");
    }

    /*
     * -------------------------------------------------------------
     * handlePartialSuccess
     * -------------------------------------------------------------
     */

    @Test
    void handlePartialSuccess_errorCode()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "handlePartialSuccess",
                                PrinterDiscoveryResponse.class,
                                int.class);

        method.setAccessible(true);

        PrinterDiscoveryResponse response =
                new PrinterDiscoveryResponse();

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                response,
                                404);

        assertThat(result.getStatus())
                .isEqualTo(
                        "PARTIAL_SUCCESS");

        assertThat(result.getMessage())
                .isEqualTo(
                        "Server returned status code: 404");
    }

    @Test
    void handlePartialSuccess_nonErrorCode()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "handlePartialSuccess",
                                PrinterDiscoveryResponse.class,
                                int.class);

        method.setAccessible(true);

        PrinterDiscoveryResponse response =
                new PrinterDiscoveryResponse();

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                response,
                                302);

        assertThat(result.getStatus())
                .isEqualTo(
                        "PARTIAL_SUCCESS");

        assertThat(result.getMessage())
                .isEqualTo(
                        "Server returned status code: 302");
    }

    /*
     * -------------------------------------------------------------
     * parseResponse
     * -------------------------------------------------------------
     */

    @Test
    void parseResponse_500()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "parseResponse",
                                int.class,
                                byte[].class,
                                String.class);

        method.setAccessible(true);

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                500,
                                "failure".getBytes(
                                        StandardCharsets.UTF_8),
                                "http://test");

        assertThat(result.getStatus())
                .isEqualTo("FAILED");

        assertThat(result.getHttpStatus())
                .isEqualTo(500);

        assertThat(result.getUrl())
                .isEqualTo("http://test");
    }

    @Test
    void parseResponse_200()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "parseResponse",
                                int.class,
                                byte[].class,
                                String.class);

        method.setAccessible(true);

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                200,
                                new byte[]{1},
                                "http://test");

        assertThat(result.getStatus())
                .isEqualTo("SUCCESS");

        assertThat(result.getHttpStatus())
                .isEqualTo(200);
    }

    @Test
    void parseResponse_201()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "parseResponse",
                                int.class,
                                byte[].class,
                                String.class);

        method.setAccessible(true);

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                201,
                                new byte[]{1},
                                "http://test");

        assertThat(result.getStatus())
                .isEqualTo("SUCCESS");

        assertThat(result.getHttpStatus())
                .isEqualTo(201);
    }

    @Test
    void parseResponse_otherCode()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "parseResponse",
                                int.class,
                                byte[].class,
                                String.class);

        method.setAccessible(true);

        PrinterDiscoveryResponse result =
                (PrinterDiscoveryResponse)
                        method.invoke(
                                service,
                                302,
                                new byte[]{1},
                                "http://test");

        assertThat(result.getStatus())
                .isEqualTo(
                        "PARTIAL_SUCCESS");

        assertThat(result.getHttpStatus())
                .isEqualTo(302);
    }

    /*
     * -------------------------------------------------------------
     * createPayload
     * -------------------------------------------------------------
     */

    @Test
    void createPayload_createsIppPayload()
            throws Exception {

        Method method =
                PrinterDiscoveryService.class
                        .getDeclaredMethod(
                                "createPayload",
                                String.class);

        method.setAccessible(true);

        byte[] result =
                (byte[]) method.invoke(
                        service,
                        "ipp://server/printer");

        assertThat(result)
                .isNotNull()
                .isNotEmpty();

        assertThat(result[0])
                .isEqualTo((byte) 0x01);

        assertThat(result[1])
                .isEqualTo((byte) 0x01);
    }

    /*
     * -------------------------------------------------------------
     * Full service flow
     * -------------------------------------------------------------
     */

    @Test
    void sendDiscoveryRequest_http200()
            throws Exception {

        String baseUrl =
                startServer(
                        200,
                        new byte[]{
                                0x01,
                                0x01,
                                0x00,
                                0x00,
                                0x00,
                                0x00,
                                0x00,
                                0x01
                        });

        configureForServer(baseUrl);

        ApiResponse<PrinterDiscoveryResponse> result =
                service.sendDiscoveryRequest();

        assertThat(result.isSuccess())
                .isTrue();

        assertThat(result.getResponse())
                .isNotNull();

        assertThat(
                result.getResponse().getStatus())
                .isEqualTo("SUCCESS");

        assertThat(
                result.getResponse().getHttpStatus())
                .isEqualTo(200);

        assertThat(
                result.getResponse().getMessage())
                .isEqualTo(
                        "IPP request transmitted successfully");

        assertThat(
                result.getResponse().getUrl())
                .isEqualTo(
                        baseUrl + PRINTER_PATH);
    }

    @Test
    void sendDiscoveryRequest_http201EmptyBody()
            throws Exception {

        String baseUrl =
                startServer(
                        201,
                        new byte[0]);

        configureForServer(baseUrl);

        ApiResponse<PrinterDiscoveryResponse> result =
                service.sendDiscoveryRequest();

        assertThat(result.isSuccess())
                .isTrue();

        assertThat(result.getResponse())
                .isNotNull();

        assertThat(
                result.getResponse().getStatus())
                .isEqualTo("SUCCESS");

        assertThat(
                result.getResponse().getHttpStatus())
                .isEqualTo(201);
    }

    @Test
    void sendDiscoveryRequest_http500()
            throws Exception {

        String baseUrl =
                startServer(
                        500,
                        "Printer failure"
                                .getBytes(
                                        StandardCharsets.UTF_8));

        configureForServer(baseUrl);

        ApiResponse<PrinterDiscoveryResponse> result =
                service.sendDiscoveryRequest();

        assertThat(result.isSuccess())
                .isTrue();

        assertThat(result.getResponse())
                .isNotNull();

        assertThat(
                result.getResponse().getStatus())
                .isEqualTo("FAILED");

        assertThat(
                result.getResponse().getErrorType())
                .isEqualTo(
                        "SERVER_ERROR");

        assertThat(
                result.getResponse().getHttpStatus())
                .isEqualTo(500);

        assertThat(
                result.getResponse().getMessage())
                .isEqualTo(
                        "Printer failure");

        assertThat(
                result.getResponse().getUrl())
                .isEqualTo(
                        baseUrl + PRINTER_PATH);
    }

    @Test
    void sendDiscoveryRequest_http404()
            throws Exception {

        String baseUrl =
                startServer(
                        404,
                        "Printer not found"
                                .getBytes(
                                        StandardCharsets.UTF_8));

        configureForServer(baseUrl);

        ApiResponse<PrinterDiscoveryResponse> result =
                service.sendDiscoveryRequest();

        assertThat(result.isSuccess())
                .isTrue();

        assertThat(result.getResponse())
                .isNotNull();

        assertThat(
                result.getResponse().getStatus())
                .isEqualTo(
                        "PARTIAL_SUCCESS");

        assertThat(
                result.getResponse().getHttpStatus())
                .isEqualTo(404);

        assertThat(
                result.getResponse().getMessage())
                .isEqualTo(
                        "Server returned status code: 404");

        assertThat(
                result.getResponse().getUrl())
                .isEqualTo(
                        baseUrl + PRINTER_PATH);
    }

    /*
     * -------------------------------------------------------------
     * Exception handling
     * -------------------------------------------------------------
     */

    @Test
    void sendDiscoveryRequest_invalidUrl_returnsOkWithNull() {

        ReflectionTestUtils.setField(
                service,
                "targetUrl",
                "not-a-valid-url");

        ReflectionTestUtils.setField(
                service,
                "printerPath",
                "/printer");

        ApiResponse<PrinterDiscoveryResponse> result =
                service.sendDiscoveryRequest();

        /*
         * This verifies CURRENT production behavior:
         * sendDiscoveryRequest catches the exception and returns
         * ApiResponse.ok(null).
         */
        assertThat(result.isSuccess())
                .isTrue();

        assertThat(result.getResponse())
                .isNull();

        assertThat(result.getMessage())
                .isEqualTo(
                        "The request has been processed");
    }
}