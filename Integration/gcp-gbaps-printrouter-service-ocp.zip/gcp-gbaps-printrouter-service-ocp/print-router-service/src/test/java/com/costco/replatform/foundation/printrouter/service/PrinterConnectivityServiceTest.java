package com.costco.replatform.foundation.printrouter.service;

import com.costco.replatform.foundation.printrouter.config.PrinterIppProperties;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrintRouteResponse;
import com.costco.replatform.foundation.printrouter.model.PrintStatusResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterIppResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;
import com.sun.net.httpserver.HttpServer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.Authenticator;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class PrinterConnectivityServiceTest {

    private PrinterConnectivityService service;
    private PrinterIppProperties properties;

    @BeforeEach
    void setUp() {

        properties = new PrinterIppProperties();
        properties.setQueueUrl("http://test/printers/");
        properties.setRequestingUser("test-user");
        properties.setDomainUsername("TEST\\test-user");
        properties.setPassword("test-password");
        properties.setJobName("TEST_JOB_");
        properties.setPrintContent("Unit Test Content");
        properties.setConnectTimeoutSeconds(1);
        properties.setRequestTimeoutSeconds(1);

        service = new PrinterConnectivityService(properties);
    }

    // ============================================================
    // doPrint
    // ============================================================

    @Test
    void doPrint_nullPrinterIp_returnsError() {

        PrinterMetadata printer = new PrinterMetadata();
        printer.setPrinterName("Laser1");
        printer.setIpAddress(null);

        ApiResponse<PrintRouteResponse> result =
                service.doPrint(
                        1,
                        "DOC",
                        "PDF",
                        "TRACK",
                        "CONTENT",
                        List.of(printer));

        assertThat(result.isSuccess()).isFalse();
        assertThat(result.getMessage())
                .isEqualTo("PrinterIp is invalid");
    }

    @Test
    void doPrint_emptyPrinterIp_returnsError() {

        PrinterMetadata printer = new PrinterMetadata();
        printer.setPrinterName("Laser1");
        printer.setIpAddress("");

        ApiResponse<PrintRouteResponse> result =
                service.doPrint(
                        1,
                        "DOC",
                        "PDF",
                        "TRACK",
                        "CONTENT",
                        List.of(printer));

        assertThat(result.isSuccess()).isFalse();
        assertThat(result.getMessage())
                .isEqualTo("PrinterIp is invalid");
    }

    @Test
    void doPrint_literalEmptyPrinterIp_returnsError() {

        PrinterMetadata printer = new PrinterMetadata();
        printer.setPrinterName("Laser1");
        printer.setIpAddress("EMPTY");

        ApiResponse<PrintRouteResponse> result =
                service.doPrint(
                        1,
                        "DOC",
                        "PDF",
                        "TRACK",
                        "CONTENT",
                        List.of(printer));

        assertThat(result.isSuccess()).isFalse();
        assertThat(result.getMessage())
                .isEqualTo("PrinterIp is invalid");
    }

    @Test
    void doPrint_nullPrinterEntry_skipsEntry() {

        ApiResponse<PrintRouteResponse> result =
                service.doPrint(
                        1,
                        "DOC",
                        "PDF",
                        "TRACK",
                        "CONTENT",
                        java.util.Collections.singletonList(null));

        assertThat(result).isNotNull();
        assertThat(result.isSuccess()).isTrue();
    }

    @Test
    void doPrint_success_executesSendPrintRequest() throws Exception {

        HttpServer server = createIppServer(123, 0x0000);

        try {

            String printerIp =
                    "127.0.0.1:" + server.getAddress().getPort();

            PrinterMetadata printer = new PrinterMetadata();
            printer.setPrinterName("Laser1");
            printer.setIpAddress(printerIp);
            printer.setLocation("01680");

            ApiResponse<PrintRouteResponse> result =
                    service.doPrint(
                            123,
                            "label.pdf",
                            "PDF",
                            "TRACK-123",
                            "CONTENT",
                            List.of(printer));

            assertThat(result).isNotNull();
            assertThat(result.isSuccess()).isTrue();
            assertThat(result.getResponse()).isNotNull();

            assertThat(result.getResponse().getPrinterName())
                    .isEqualTo("Laser1");

            assertThat(result.getResponse().getPrinterIp())
                    .isEqualTo(printerIp);

            assertThat(result.getResponse().getLocationId())
                    .isEqualTo("01680");

        } finally {
            server.stop(0);
        }
    }

    @Test
    void doPrint_ippRejected_currentlyThrowsNpe() throws Exception {

        HttpServer server = createIppServer(123, 0x0406);

        try {

            String printerIp =
                    "127.0.0.1:" + server.getAddress().getPort();

            PrinterMetadata printer = new PrinterMetadata();
            printer.setPrinterName("Laser1");
            printer.setIpAddress(printerIp);

            assertThatThrownBy(() ->
                    service.doPrint(
                            123,
                            "label.pdf",
                            "PDF",
                            "TRACK-123",
                            "CONTENT",
                            List.of(printer)))
                    .isInstanceOf(NullPointerException.class);

        } finally {

            server.stop(0);
        }
    }

    @Test
    void doPrint_connectionFailure_currentlyThrowsNpe() {

        PrinterMetadata printer = new PrinterMetadata();
        printer.setPrinterName("Laser1");
        printer.setIpAddress("127.0.0.1:1");

        assertThatThrownBy(() ->
                service.doPrint(
                        123,
                        "label.pdf",
                        "PDF",
                        "TRACK-123",
                        "CONTENT",
                        List.of(printer)))
                .isInstanceOf(NullPointerException.class);
    }

    // ============================================================
    // doStatusCheck
    // ============================================================

    @Test
    void doStatusCheck_nullPrinterName_returnsInitializedResponse() {

        ApiResponse<PrintStatusResponse> result =
                service.doStatusCheck(
                        1,
                        null,
                        100,
                        "10.10.10.10");

        assertThat(result).isNotNull();
        assertThat(result.isSuccess()).isTrue();
    }

    @Test
    void doStatusCheck_success_executesSendPrintJobStatusRequest()
            throws Exception {

        HttpServer server = createIppServer(123, 0x0000);

        try {

            String printerIp =
                    "127.0.0.1:" + server.getAddress().getPort();

            ApiResponse<PrintStatusResponse> result =
                    service.doStatusCheck(
                            123,
                            "Laser1",
                            456,
                            printerIp);

            assertThat(result).isNotNull();
            assertThat(result.isSuccess()).isTrue();
            assertThat(result.getResponse()).isNotNull();

            assertThat(result.getResponse().getPrinterName())
                    .isEqualTo("Laser1");

            assertThat(result.getResponse().getPrinterIp())
                    .isEqualTo(printerIp);

            assertThat(result.getResponse().getPrintJobId())
                    .isEqualTo(456);

        } finally {
            server.stop(0);
        }
    }

    @Test
    void doStatusCheck_ippRejected_returnsInitializedResponse()
            throws Exception {

        HttpServer server = createIppServer(123, 0x0406);

        try {

            String printerIp =
                    "127.0.0.1:" + server.getAddress().getPort();

            ApiResponse<PrintStatusResponse> result =
                    service.doStatusCheck(
                            123,
                            "Laser1",
                            456,
                            printerIp);

            assertThat(result).isNotNull();
            assertThat(result.isSuccess()).isTrue();

        } finally {
            server.stop(0);
        }
    }

    @Test
    void doStatusCheck_connectionFailure_returnsInitializedResponse() {

        ApiResponse<PrintStatusResponse> result =
                service.doStatusCheck(
                        123,
                        "Laser1",
                        456,
                        "127.0.0.1:1");

        assertThat(result).isNotNull();
        assertThat(result.isSuccess()).isTrue();
    }

    // ============================================================
    // Job-state mapping
    // ============================================================

    @Test
    void getJobStateDescription_allStates() throws Exception {

        Method method =
                privateMethod(
                        "getJobStateDescription",
                        Integer.class);

        assertThat(method.invoke(service, (Object) null))
                .isNull();

        assertThat(method.invoke(service, 3))
                .isEqualTo("PENDING");

        assertThat(method.invoke(service, 4))
                .isEqualTo("PENDING_HELD");

        assertThat(method.invoke(service, 5))
                .isEqualTo("PROCESSING");

        assertThat(method.invoke(service, 6))
                .isEqualTo("STOPPED");

        assertThat(method.invoke(service, 7))
                .isEqualTo("CANCELED");

        assertThat(method.invoke(service, 8))
                .isEqualTo("ABORTED");

        assertThat(method.invoke(service, 9))
                .isEqualTo("COMPLETED");

        assertThat(method.invoke(service, 99))
                .isEqualTo("UNKNOWN(99)");
    }

    // ============================================================
    // IPP status mapping
    // ============================================================

    @Test
    void getIppStatusDescription_allStatuses() throws Exception {

        Method method =
                privateMethod(
                        "getIppStatusDescription",
                        int.class);

        assertThat(method.invoke(service, 0x0000))
                .isEqualTo("successful-ok");

        assertThat(method.invoke(service, 0x0001))
                .isEqualTo(
                        "successful-ok-ignored-or-substituted-attributes");

        assertThat(method.invoke(service, 0x0002))
                .isEqualTo(
                        "successful-ok-conflicting-attributes");

        assertThat(method.invoke(service, 0x0400))
                .isEqualTo("client-error-bad-request");

        assertThat(method.invoke(service, 0x0401))
                .isEqualTo("client-error-forbidden");

        assertThat(method.invoke(service, 0x0402))
                .isEqualTo("client-error-not-authenticated");

        assertThat(method.invoke(service, 0x0403))
                .isEqualTo("client-error-not-authorized");

        assertThat(method.invoke(service, 0x0404))
                .isEqualTo("client-error-not-possible");

        assertThat(method.invoke(service, 0x0406))
                .isEqualTo("client-error-not-found");

        assertThat(method.invoke(service, 0x040A))
                .isEqualTo(
                        "client-error-document-format-not-supported");

        assertThat(method.invoke(service, 0x0500))
                .isEqualTo("server-error-internal-error");

        assertThat(method.invoke(service, 0x0501))
                .isEqualTo(
                        "server-error-operation-not-supported");

        assertThat(method.invoke(service, 0x0502))
                .isEqualTo(
                        "server-error-service-unavailable");

        assertThat(method.invoke(service, 0x0503))
                .isEqualTo(
                        "server-error-version-not-supported");

        assertThat(method.invoke(service, 0x1234))
                .isEqualTo(
                        "unknown-ipp-status-0x1234");
    }

    // ============================================================
    // processResponse
    // ============================================================

    @Test
    void processResponse_401Unauthorized() throws Exception {

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> response =
                mock(HttpResponse.class);

        when(response.statusCode()).thenReturn(401);
        when(response.body()).thenReturn(new byte[0]);

        HttpHeaders headers =
                HttpHeaders.of(
                        Map.of(
                                "WWW-Authenticate",
                                List.of("Basic")),
                        (a, b) -> true);

        when(response.headers()).thenReturn(headers);

        PrinterIppResponse result =
                invokeProcessResponse(
                        response,
                        1);

        assertThat(result.isOk()).isFalse();
        assertThat(result.getStatus()).isEqualTo(401);

        assertThat(result.getMessage())
                .contains("authentication failed");
    }

    @Test
    void processResponse_403Forbidden() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        403,
                        new byte[0],
                        1);

        assertThat(result.isOk()).isFalse();
        assertThat(result.getMessage())
                .contains("not authorized");
    }

    @Test
    void processResponse_404NotFound() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        404,
                        new byte[0],
                        1);

        assertThat(result.isOk()).isFalse();
        assertThat(result.getMessage())
                .contains("not found");
    }

    @Test
    void processResponse_http500() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        500,
                        new byte[8],
                        123);

        assertThat(result.isOk()).isFalse();
        assertThat(result.getMessage())
                .contains("status 500");
    }

    @Test
    void processResponse_invalidIppResponse() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        200,
                        new byte[0],
                        123);

        assertThat(result.isOk()).isFalse();

        assertThat(result.getMessage())
                .contains(
                        "not a valid IPP response");
    }

    @Test
    void processResponse_requestIdMismatch()
            throws Exception {

        byte[] ipp = {
                0x01, 0x01,
                0x00, 0x00,
                0x00, 0x00, 0x03, (byte) 0xE7
        };

        PrinterIppResponse result =
                processResponse(
                        200,
                        ipp,
                        123);

        assertThat(result.isOk()).isFalse();

        assertThat(result.getMessage())
                .contains(
                        "request ID mismatch");
    }

    @Test
    void processResponse_successfulIppResponse()
            throws Exception {

        byte[] ipp =
                ippResponse(123, 0x0000);

        PrinterIppResponse result =
                processResponse(
                        200,
                        ipp,
                        123);

        assertThat(result.isOk()).isTrue();
        assertThat(result.getStatus()).isEqualTo(200);
    }

    @Test
    void processResponse_ippRejected()
            throws Exception {

        byte[] ipp =
                ippResponse(123, 0x0406);

        PrinterIppResponse result =
                processResponse(
                        200,
                        ipp,
                        123);

        assertThat(result.isOk()).isFalse();

        assertThat(result.getMessage())
                .contains(
                        "Print job rejected");
    }

    // ============================================================
    // IPP extract helpers
    // ============================================================

    @Test
    void extractJobId_returnsValue() throws Exception {

        Method method =
                privateMethod(
                        "extractJobId",
                        byte[].class);

        byte[] response = {
                0x01, 0x01, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x01,
                0x21,
                0x00, 0x06,
                'j', 'o', 'b', '-', 'i', 'd',
                0x00, 0x04,
                0x00, 0x00, 0x00, 0x7B,
                0x03
        };

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) response);

        assertThat(result).isEqualTo(123);
    }

    @Test
    void extractJobId_returnsNullWhenMissing()
            throws Exception {

        Method method =
                privateMethod(
                        "extractJobId",
                        byte[].class);

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) new byte[]{0x03});

        assertThat(result).isNull();
    }

    @Test
    void extractJobState_returnsCompletedState()
            throws Exception {

        Method method =
                privateMethod(
                        "extractJobState",
                        byte[].class);

        byte[] response = {
                0, 0, 0, 0, 0,
                0, 0, 0, 0, 0,

                0x23,
                0x00, 0x09,

                'j', 'o', 'b', '-',
                's', 't', 'a', 't', 'e',

                0x00, 0x04,
                0x00, 0x00, 0x00, 0x09,

                0, 0, 0, 0
        };

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) response);

        assertThat(result).isEqualTo(9);
    }

    @Test
    void extractJobState_invalidPayload_returnsNull()
            throws Exception {

        Method method =
                privateMethod(
                        "extractJobState",
                        byte[].class);

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) new byte[]{1, 2, 3});

        assertThat(result).isNull();
    }

    // ============================================================
    // validateInput
    // ============================================================

    @Test
    void validateInput_validConfiguration()
            throws Exception {

        invokeValidateInput();
    }

    @Test
    void validateInput_queueUrlNull() throws Exception {

        properties.setQueueUrl(null);

        assertValidationFailure(
                "Queue URL must not be empty");
    }

    @Test
    void validateInput_invalidScheme() throws Exception {

        properties.setQueueUrl(
                "ftp://printer-server");

        assertValidationFailure(
                "Queue URL must use HTTP or HTTPS");
    }

    @Test
    void validateInput_invalidHost() {

        properties.setQueueUrl(
                "http:///printer");

        assertThatThrownBy(
                this::invokeValidateInput)
                .hasCauseInstanceOf(
                        IllegalArgumentException.class);
    }

    @Test
    void validateInput_missingPath() throws Exception {

        properties.setQueueUrl(
                "http://localhost");

        assertValidationFailure(
                "Queue URL must contain an IPP queue path");
    }

    @Test
    void validateInput_missingRequestingUser()
            throws Exception {

        properties.setRequestingUser(null);

        assertValidationFailure(
                "Requesting user must not be empty");
    }

    @Test
    void validateInput_missingDomainUsername()
            throws Exception {

        properties.setDomainUsername(null);

        assertValidationFailure(
                "Authentication username must not be empty");
    }

    @Test
    void validateInput_missingPassword()
            throws Exception {

        properties.setPassword(null);

        assertValidationFailure(
                "Authentication password must not be empty");
    }

    @Test
    void validateInput_missingJobName()
            throws Exception {

        properties.setJobName(null);

        assertValidationFailure(
                "Job name must not be empty");
    }

    @Test
    void validateInput_missingPrintContent()
            throws Exception {

        properties.setPrintContent(null);

        assertValidationFailure(
                "Print content must not be empty");
    }

    @Test
    void validateInput_zeroConnectTimeout()
            throws Exception {

        properties.setConnectTimeoutSeconds(0);

        assertValidationFailure(
                "Connect timeout must be greater than zero");
    }

    @Test
    void validateInput_zeroRequestTimeout()
            throws Exception {

        properties.setRequestTimeoutSeconds(0);

        assertValidationFailure(
                "Request timeout must be greater than zero");
    }

    // ============================================================
    // IPP request builders
    // ============================================================

    @Test
    void buildIppPrintRequest_createsValidIppPayload()
            throws Exception {

        Method method =
                privateMethod(
                        "buildIppPrintRequest",
                        int.class,
                        String.class,
                        String.class,
                        String.class,
                        String.class,
                        String.class);

        byte[] result =
                (byte[]) method.invoke(
                        service,
                        123,
                        "Laser1",
                        "label.pdf",
                        "PDF",
                        "CONTENT",
                        "10.10.10.10");

        assertThat(result).isNotEmpty();

        assertThat(result[0]).isEqualTo((byte) 0x01);
        assertThat(result[1]).isEqualTo((byte) 0x01);

        int operationId =
                ((result[2] & 0xFF) << 8)
                        | (result[3] & 0xFF);

        assertThat(operationId).isEqualTo(0x0002);
    }

    @Test
    void buildIppPrintJobStatusRequest_createsValidPayload()
            throws Exception {

        Method method =
                privateMethod(
                        "buildIppPrintJobStatusRequest",
                        int.class,
                        String.class,
                        int.class,
                        String.class);

        byte[] result =
                (byte[]) method.invoke(
                        service,
                        123,
                        "Laser1",
                        456,
                        "10.10.10.10");

        assertThat(result).isNotEmpty();

        int operationId =
                ((result[2] & 0xFF) << 8)
                        | (result[3] & 0xFF);

        assertThat(operationId).isEqualTo(0x0009);
    }

    @Test
    void buildHttpRequest_setsExpectedFields()
            throws Exception {

        Method method =
                privateMethod(
                        "buildHttpRequest",
                        byte[].class,
                        String.class);

        HttpRequest request =
                (HttpRequest) method.invoke(
                        service,
                        new byte[]{1, 2, 3},
                        "10.10.10.10");

        assertThat(request.uri().toString())
                .isEqualTo(
                        "http://10.10.10.10");

        assertThat(
                request.headers()
                        .firstValue("Content-Type"))
                .contains("application/ipp");

        assertThat(
                request.headers()
                        .firstValue("Accept"))
                .contains("application/ipp");

        assertThat(request.method())
                .isEqualTo("POST");

        assertThat(request.timeout())
                .contains(Duration.ofSeconds(1));
    }

    // ============================================================
    // Remaining helpers
    // ============================================================

    @Test
    void getDocumentBytes_allBranches()
            throws Exception {

        Method method =
                privateMethod(
                        "getDocumentBytes",
                        String.class,
                        String.class);

        byte[] pdf =
                (byte[]) method.invoke(
                        service,
                        "PDF",
                        "ABC");

        byte[] zpl =
                (byte[]) method.invoke(
                        service,
                        "ZPL",
                        "^XA");

        byte[] other =
                (byte[]) method.invoke(
                        service,
                        "TEXT",
                        "HELLO");

        assertThat(pdf).isNotEmpty();
        assertThat(zpl).isNotEmpty();
        assertThat(other).isNotEmpty();
    }

    @Test
    void getFailureHttpStatus_allBranches()
            throws Exception {

        Method method =
                privateMethod(
                        "getFailureHttpStatus",
                        PrinterIppResponse.class);

        PrinterIppResponse response =
                new PrinterIppResponse();

        response.setStatus(400);
        assertThat(method.invoke(service, response))
                .isEqualTo(400);

        response.setStatus(404);
        assertThat(method.invoke(service, response))
                .isEqualTo(404);

        response.setStatus(599);
        assertThat(method.invoke(service, response))
                .isEqualTo(599);

        response.setStatus(200);
        assertThat(method.invoke(service, response))
                .isEqualTo(502);
    }

    @Test
    void buildPrinterResponse_populatesFields()
            throws Exception {

        Method method =
                privateMethod(
                        "buildPrinterResponse",
                        int.class,
                        Integer.class,
                        int.class,
                        String.class,
                        boolean.class,
                        Integer.class);

        PrinterIppResponse response =
                (PrinterIppResponse) method.invoke(
                        service,
                        200,
                        0,
                        123,
                        "Success",
                        true,
                        999);

        assertThat(response.isOk()).isTrue();
        assertThat(response.getStatus()).isEqualTo(200);
        assertThat(response.getMessage()).isEqualTo("Success");
        assertThat(response.getPrintJobId()).isEqualTo(999);
    }

    @Test
    void buildBasicAuthorizationHeader_works()
            throws Exception {

        String result =
                (String) privateMethod(
                        "buildBasicAuthorizationHeader")
                        .invoke(service);

        assertThat(result)
                .startsWith("Basic ");
    }

    @Test
    void getExceptionMessage_allBranches()
            throws Exception {

        Method method =
                privateMethod(
                        "getExceptionMessage",
                        Exception.class);

        assertThat(
                method.invoke(
                        service,
                        new RuntimeException("boom")))
                .isEqualTo("boom");

        assertThat(
                method.invoke(
                        service,
                        new RuntimeException()))
                .isEqualTo("RuntimeException");
    }

    @Test
    void isBlank_allBranches() throws Exception {

        Method method =
                privateMethod(
                        "isBlank",
                        String.class);

        assertThat(
                method.invoke(service, (Object) null))
                .isEqualTo(true);

        assertThat(
                method.invoke(service, ""))
                .isEqualTo(true);

        assertThat(
                method.invoke(service, "   "))
                .isEqualTo(true);

        assertThat(
                method.invoke(service, "abc"))
                .isEqualTo(false);
    }

    @Test
    void writeStringAttribute_writesData()
            throws Exception {

        Method method =
                privateMethod(
                        "writeStringAttribute",
                        DataOutputStream.class,
                        int.class,
                        String.class,
                        String.class);

        ByteArrayOutputStream baos =
                new ByteArrayOutputStream();

        DataOutputStream dos =
                new DataOutputStream(baos);

        method.invoke(
                service,
                dos,
                0x42,
                "job-name",
                "test");

        assertThat(baos.toByteArray())
                .isNotEmpty();
    }

    @Test
    void writeIntegerAttribute_writesData()
            throws Exception {

        Method method =
                privateMethod(
                        "writeIntegerAttribute",
                        DataOutputStream.class,
                        int.class,
                        String.class,
                        int.class);

        ByteArrayOutputStream baos =
                new ByteArrayOutputStream();

        DataOutputStream dos =
                new DataOutputStream(baos);

        method.invoke(
                service,
                dos,
                0x21,
                "job-id",
                123);

        assertThat(baos.toByteArray())
                .isNotEmpty();
    }

    @Test
    void constructor_configuresHttpClient() {

        HttpClient client =
                (HttpClient)
                        ReflectionTestUtils.getField(
                                service,
                                "httpClient");

        assertThat(client).isNotNull();

        assertThat(client.followRedirects())
                .isEqualTo(
                        HttpClient.Redirect.ALWAYS);

        assertThat(client.connectTimeout())
                .contains(
                        Duration.ofSeconds(10));
    }

    // ============================================================
    // Test helpers
    // ============================================================

    private HttpServer createIppServer(
            int requestId,
            int ippStatus)
            throws Exception {

        HttpServer server =
                HttpServer.create(
                        new InetSocketAddress(
                                InetAddress.getLoopbackAddress(),
                                0),
                        0);

        server.createContext("/", exchange -> {

            exchange.getRequestBody().readAllBytes();

            byte[] body =
                    ippResponse(
                            requestId,
                            ippStatus);

            exchange.getResponseHeaders()
                    .add(
                            "Content-Type",
                            "application/ipp");

            exchange.sendResponseHeaders(
                    200,
                    body.length);

            try (OutputStream output =
                         exchange.getResponseBody()) {

                output.write(body);
            }

            exchange.close();
        });

        server.start();

        return server;
    }

    private static byte[] ippResponse(
            int requestId,
            int ippStatus) {

        return new byte[]{
                0x01,
                0x01,
                (byte) ((ippStatus >> 8) & 0xFF),
                (byte) (ippStatus & 0xFF),
                (byte) ((requestId >> 24) & 0xFF),
                (byte) ((requestId >> 16) & 0xFF),
                (byte) ((requestId >> 8) & 0xFF),
                (byte) (requestId & 0xFF)
        };
    }

    private PrinterIppResponse processResponse(
            int httpStatus,
            byte[] body,
            int itemNo)
            throws Exception {

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> response =
                mock(HttpResponse.class);

        when(response.statusCode())
                .thenReturn(httpStatus);

        when(response.body())
                .thenReturn(body);

        return invokeProcessResponse(
                response,
                itemNo);
    }

    private PrinterIppResponse invokeProcessResponse(
            HttpResponse<byte[]> response,
            int itemNo)
            throws Exception {

        Method method =
                privateMethod(
                        "processResponse",
                        HttpResponse.class,
                        int.class);

        return (PrinterIppResponse)
                method.invoke(
                        service,
                        response,
                        itemNo);
    }

    private void invokeValidateInput()
            throws Exception {

        privateMethod(
                "validateInput")
                .invoke(service);
    }

    private void assertValidationFailure(
            String expectedMessage) {

        assertThatThrownBy(
                this::invokeValidateInput)
                .hasRootCauseMessage(
                        expectedMessage);
    }

    private static Method privateMethod(
            String name,
            Class<?>... parameterTypes)
            throws Exception {

        Method method =
                PrinterConnectivityService.class
                        .getDeclaredMethod(
                                name,
                                parameterTypes);

        method.setAccessible(true);

        return method;
    }
}