package com.costco.replatform.foundation.printrouter.controller;

import com.costco.replatform.foundation.printrouter.common.enums.DocumentType;
import com.costco.replatform.foundation.printrouter.common.enums.PrintType;
import com.costco.replatform.foundation.printrouter.common.enums.PrinterType;
import com.costco.replatform.foundation.printrouter.model.*;
import com.costco.replatform.foundation.printrouter.service.ActiveDirectoryDiscoveryService;
import com.costco.replatform.foundation.printrouter.service.PrinterConnectivityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Method;
import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.isNull;

class PrintRouterControllerTest {

    private ActiveDirectoryDiscoveryService adService;
    private PrinterConnectivityService printService;
    private PrintRouterController controller;

    @BeforeEach
    void setUp() {
        adService = mock(ActiveDirectoryDiscoveryService.class);
        printService = mock(PrinterConnectivityService.class);
        controller = new PrintRouterController(adService, printService);
    }

    // Helpers

    private static PrintMetadata metadata() {
        PrintMetadata m = new PrintMetadata();
        m.setTrackingId("TRK-1");
        m.setRequestTime("2026-11-04T10:00:00");
        m.setRequestedUser("JohnDoe");
        m.setDocumentName("label.pdf");
        m.setDocumentType(DocumentType.PDF);
        m.setPrintType(PrintType.RTLABEL);
        m.setPrinterType(PrinterType.ZEBRA);
        m.setCopies(1);
        m.setItemNo(7);
        m.setLocationId("WH-123");
        return m;
    }

    private static ApiRequest<PrintRouteRequest> apiRequest(PrintRouteRequest request) {
        ApiRequest<PrintRouteRequest> apiRequest = new ApiRequest<>();
        apiRequest.setRequestId("UI-REQ-1");
        apiRequest.setRequest(request);
        return apiRequest;
    }

    private static ApiRequest<PrintRouteRequest> apiRequest(PrintMetadata metadata) {
        PrintRouteRequest request = new PrintRouteRequest();
        request.setPrintMetadata(metadata);
        return apiRequest(request);
    }

    private static PrinterMetadata printer(String name) {
        PrinterMetadata printer = new PrinterMetadata();
        printer.setPrinterName(name);
        return printer;
    }

    /** AD returns this printer list (may contain nulls); pass null for a null list. */
    private void adReturns(List<PrinterMetadata> printers) {
        ActiveDirectoryDiscoveryResponse discovery = new ActiveDirectoryDiscoveryResponse();
        discovery.setPrinterList(printers);
        when(adService.discoverPrintersByLocation(any())).thenReturn(ApiResponse.ok(discovery));
    }

    /** CURRENT BEHAVIOUR: the 400 body is the untouched init() response (success=true). */
    private static void assertNotRouted(ResponseEntity<ApiResponse<PrintRouteResponse>> result) {
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(result.getBody().isSuccess()).isTrue();
        assertThat(result.getBody().getMessage()).isNotNull();
        assertThat(result.getBody().getResponse().getPrintStatus()).isNull();
    }

    // 1. Input shape

    @Test
    @DisplayName("Null ApiRequest -> 400; no discovery, no printing")
    void nullApiRequest_badRequest() {
        ResponseEntity<ApiResponse<PrintRouteResponse>> result =
                controller.routePrint(null);

        assertThat(result.getStatusCode())
                .isEqualTo(HttpStatus.BAD_REQUEST);

        assertThat(result.getBody().getErrorStatus())
                .isEqualTo("400");

        assertThat(result.getBody().getMessage())
                .isEqualTo("API request is null.");
        verifyNoInteractions(adService, printService);
    }

    @Test
    void getPrintStatus_nullRequest() {

        ResponseEntity<ApiResponse<PrintStatusResponse>> response =
                controller.getPrintStatus(null);

        assertThat(response.getStatusCode())
                .isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void getPrintStatus_success() {

        PrintStatusRequest request = new PrintStatusRequest();
        request.setItemNo(1);
        request.setPrinterName("Laser1");
        request.setPrintJobId(100);
        request.setPrinterIp("10.10.10.10");

        ApiRequest<PrintStatusRequest> apiRequest =
                new ApiRequest<>();
        apiRequest.setRequest(request);

        ApiResponse<PrintStatusResponse> serviceResponse =
                ApiResponse.init(new PrintStatusResponse());

        when(printService.doStatusCheck(
                anyInt(),
                any(),
                anyInt(),
                any()))
                .thenReturn(serviceResponse);

        ResponseEntity<ApiResponse<PrintStatusResponse>> response =
                controller.getPrintStatus(apiRequest);

        assertThat(response.getStatusCode())
                .isEqualTo(HttpStatus.OK);
    }

    @Test
    @DisplayName("Null inner request -> discovery with null location; no printers -> 400")
    void nullInnerRequest_discoversWithNullLocation() {
        adReturns(List.of());

        assertNotRouted(controller.routePrint(apiRequest((PrintRouteRequest) null)));

        verify(adService).discoverPrintersByLocation(isNull());
    }

    @Test
    @DisplayName("Valid request delegates to doPrint")
    void routePrint_success() {

        adReturns(List.of(printer("Laser1")));

        ApiResponse<PrintRouteResponse> printResponse =
                ApiResponse.init(new PrintRouteResponse());

        when(printService.doPrint(
                anyInt(),
                any(),
                any(),
                any(),
                any(),
                any()))
                .thenReturn(printResponse);

        ResponseEntity<ApiResponse<PrintRouteResponse>> result =
                controller.routePrint(apiRequest(metadata()));

        assertThat(result.getStatusCode())
                .isEqualTo(HttpStatus.OK);

        verify(adService)
                .discoverPrintersByLocation("WH-123");

        verify(printService)
                .doPrint(
                        eq(7),
                        eq("label.pdf"),
                        eq("PDF"),
                        eq("TRK-1"),
                        any(),
                        any());
    }

    // 2. Routing across printers



    @Test
    @DisplayName("Empty printer list -> 400, nothing printed")
    void emptyPrinterList_badRequest() {
        adReturns(List.of());

        ResponseEntity<ApiResponse<PrintRouteResponse>> result =
                controller.routePrint(apiRequest(metadata()));

        assertThat(result.getStatusCode())
                .isEqualTo(HttpStatus.BAD_REQUEST);

        assertThat(result.getBody().getErrorStatus())
                .isEqualTo("404");

        assertThat(result.getBody().getMessage())
                .isEqualTo("No Printers in requested location");

        verifyNoInteractions(printService);
    }

    @Test
    @DisplayName("Null printer list (e.g. AD failure) -> 400, nothing printed")
    void nullPrinterList_badRequest() {
        adReturns(null);
        ResponseEntity<ApiResponse<PrintRouteResponse>> result =
                controller.routePrint(apiRequest(metadata()));

        assertThat(result.getStatusCode())
                .isEqualTo(HttpStatus.BAD_REQUEST);

        assertThat(result.getBody().getErrorStatus())
                .isEqualTo("404");

        assertThat(result.getBody().getMessage())
                .isEqualTo("No Printers in requested location");
        verifyNoInteractions(printService);
    }

    // 3. Crash paths (CURRENT BEHAVIOUR - no validation on the request body)

    @Test
    @DisplayName("CURRENT BEHAVIOUR: missing documentType -> NullPointerException (would be HTTP 500)")
    void missingDocumentType_throwsNpe() {
        PrintMetadata metadata = metadata();
        metadata.setDocumentType(null);

        assertThatThrownBy(() -> controller.routePrint(apiRequest(metadata)))
                .isInstanceOf(NullPointerException.class);
        verifyNoInteractions(adService, printService);
    }

    @Test
    @DisplayName("CURRENT BEHAVIOUR: missing itemNo does not throw")
    void missingItemNo_doesNotThrow() {

        PrintMetadata metadata = metadata();
        metadata.setItemNo(null);

        adReturns(List.of(printer("Laser1")));

        ApiResponse<PrintRouteResponse> printResponse =
                ApiResponse.init(new PrintRouteResponse());

        when(printService.doPrint(
                any(),
                any(),
                any(),
                any(),
                any(),
                any()))
                .thenReturn(printResponse);

        ResponseEntity<ApiResponse<PrintRouteResponse>> result =
                controller.routePrint(apiRequest(metadata));

        assertThat(result).isNotNull();

        verify(printService).doPrint(
                isNull(),
                any(),
                any(),
                any(),
                any(),
                any());
    }

    // 4. mask() - private static helper used when logging the user id

    static Stream<Arguments> maskCases() {
        return Stream.of(
                arguments(null, null),
                arguments("", ""),
                arguments("   ", "   "),
                arguments("A", "*"),
                arguments("AB", "**"),
                arguments("ABC", "A*C"),
                arguments("JohnDoe", "J*****e"));
    }

    @ParameterizedTest(name = "mask({0}) = {1}")
    @MethodSource("maskCases")
    void mask_hidesMiddleCharacters(String input, String expected) throws Exception {
        Method mask = PrintRouterController.class.getDeclaredMethod("mask", String.class);
        mask.setAccessible(true);

        assertThat(mask.invoke(null, input)).isEqualTo(expected); // static method -> null target
    }
}