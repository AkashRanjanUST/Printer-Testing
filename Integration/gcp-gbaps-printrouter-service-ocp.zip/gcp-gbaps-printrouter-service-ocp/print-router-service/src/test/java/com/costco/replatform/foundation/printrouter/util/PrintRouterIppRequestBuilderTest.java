package com.costco.replatform.foundation.printrouter.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class PrintRouterIppRequestBuilderTest {

    private static final String PRINTER_URI =
            "ipp://print-server.test.invalid/printers/TestPrinter";

    @Test
    @DisplayName("Header: IPP 1.1, Get-Printer-Attributes (0x000B), request ID")
    void header_isIpp11GetPrinterAttributes() throws Exception {

        byte[] request =
                PrintRouterIppRequestBuilder.createGetPrinterAttributesRequest(
                        1,
                        PRINTER_URI);

        ByteBuffer buffer = ByteBuffer.wrap(request);

        assertThat(buffer.get())
                .as("major version")
                .isEqualTo((byte) 0x01);

        assertThat(buffer.get())
                .as("minor version")
                .isEqualTo((byte) 0x01);

        assertThat(buffer.getShort())
                .as("operation id")
                .isEqualTo((short) 0x000B);

        assertThat(buffer.getInt())
                .as("request id")
                .isEqualTo(1);
    }

    @Test
    @DisplayName("Body: operation group, attributes in order, end tag, nothing after")
    void body_containsAttributesInOrderAndEndTag() throws Exception {

        byte[] request =
                PrintRouterIppRequestBuilder.createGetPrinterAttributesRequest(
                        1,
                        PRINTER_URI);

        ByteBuffer buffer = ByteBuffer.wrap(request);

        buffer.position(8);

        assertThat(buffer.get())
                .as("operation-attributes group tag")
                .isEqualTo((byte) 0x01);

        assertAttribute(
                buffer,
                (byte) 0x47,
                "attributes-charset",
                "utf-8");

        assertAttribute(
                buffer,
                (byte) 0x48,
                "attributes-natural-language",
                "en-us");

        assertAttribute(
                buffer,
                (byte) 0x45,
                "printer-uri",
                PRINTER_URI);

        assertThat(buffer.get())
                .as("end-of-attributes tag")
                .isEqualTo((byte) 0x03);

        assertThat(buffer.hasRemaining())
                .as("no trailing bytes")
                .isFalse();
    }

    @Test
    @DisplayName("Total length matches expected IPP layout")
    void totalLength_matchesLayout() throws Exception {

        byte[] request =
                PrintRouterIppRequestBuilder.createGetPrinterAttributesRequest(
                        1,
                        PRINTER_URI);

        int expected =
                8
                        + 1
                        + attributeSize("attributes-charset", "utf-8")
                        + attributeSize("attributes-natural-language", "en-us")
                        + attributeSize("printer-uri", PRINTER_URI)
                        + 1;

        assertThat(request)
                .hasSize(expected);
    }

    @Test
    @DisplayName("Request ID is encoded as big-endian integer")
    void requestId_isBigEndian() throws Exception {

        byte[] request =
                PrintRouterIppRequestBuilder.createGetPrinterAttributesRequest(
                        0x01020304,
                        PRINTER_URI);

        assertThat(request[4]).isEqualTo((byte) 0x01);
        assertThat(request[5]).isEqualTo((byte) 0x02);
        assertThat(request[6]).isEqualTo((byte) 0x03);
        assertThat(request[7]).isEqualTo((byte) 0x04);
    }

    @Test
    @DisplayName("Request ID supports Integer.MAX_VALUE")
    void requestId_maxValue() throws Exception {

        byte[] request =
                PrintRouterIppRequestBuilder.createGetPrinterAttributesRequest(
                        Integer.MAX_VALUE,
                        PRINTER_URI);

        assertThat(
                ByteBuffer.wrap(request, 4, 4).getInt())
                .isEqualTo(Integer.MAX_VALUE);
    }

    @Test
    @DisplayName("Null printer URI throws NullPointerException")
    void nullUri_throwsNpe() {

        assertThatThrownBy(
                () -> PrintRouterIppRequestBuilder
                        .createGetPrinterAttributesRequest(
                                1,
                                null))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    @DisplayName("Printer URI may be blank")
    void blankUri_isEncoded() throws Exception {

        byte[] request =
                PrintRouterIppRequestBuilder
                        .createGetPrinterAttributesRequest(
                                1,
                                "");

        assertThat(request)
                .isNotEmpty();
    }

    @Test
    @DisplayName("Operation ID is Get-Printer-Attributes")
    void operationId_isGetPrinterAttributes() throws Exception {

        byte[] request =
                PrintRouterIppRequestBuilder
                        .createGetPrinterAttributesRequest(
                                1,
                                PRINTER_URI);

        int operationId =
                ((request[2] & 0xFF) << 8)
                        | (request[3] & 0xFF);

        assertThat(operationId)
                .isEqualTo(0x000B);
    }

    @Test
    @DisplayName("Implicit constructor can be invoked")
    void implicitConstructor() {

        assertThat(
                new PrintRouterIppRequestBuilder())
                .isNotNull();
    }

    private static void assertAttribute(
            ByteBuffer buffer,
            byte expectedTag,
            String expectedName,
            String expectedValue) {

        assertThat(buffer.get())
                .as("value tag of %s", expectedName)
                .isEqualTo(expectedTag);

        byte[] name = new byte[buffer.getShort()];

        buffer.get(name);

        assertThat(
                new String(
                        name,
                        StandardCharsets.US_ASCII))
                .isEqualTo(expectedName);

        byte[] value = new byte[buffer.getShort()];

        buffer.get(value);

        assertThat(
                new String(
                        value,
                        StandardCharsets.UTF_8))
                .as("value of %s", expectedName)
                .isEqualTo(expectedValue);
    }

    private static int attributeSize(
            String name,
            String value) {

        return 1
                + 2
                + name.getBytes(StandardCharsets.US_ASCII).length
                + 2
                + value.getBytes(StandardCharsets.UTF_8).length;
    }
}