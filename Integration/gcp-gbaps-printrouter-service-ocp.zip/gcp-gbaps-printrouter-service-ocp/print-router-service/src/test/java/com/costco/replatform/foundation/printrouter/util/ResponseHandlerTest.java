package com.costco.replatform.foundation.printrouter.util;

import com.costco.replatform.foundation.printrouter.model.PrinterIppResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.assertThat;

class ResponseHandlerTest {

    private static final String TRACKING_ID = "TRK-001";

    private static final String GENERIC_500_MESSAGE =
            "Internal server error while processing vendor creation";

    private ResponseHandler handler;

    @BeforeEach
    void setUp() {
        handler = new ResponseHandler();
    }

    private static PrinterIppResponse serviceResponseWith(
            Integer status,
            String message,
            boolean ok) {

        PrinterIppResponse response = new PrinterIppResponse();

        response.setStatus(status);
        response.setMessage(message);
        response.setOk(ok);

        return response;
    }

    @Nested
    @DisplayName("buildServiceErrorResponse")
    class BuildServiceErrorResponse {

        @Test
        @DisplayName("Null service response -> 500 with generic message")
        void nullResponse_returns500() {

            PrinterIppResponse result =
                    handler.buildServiceErrorResponse(
                            TRACKING_ID,
                            null);

            assertThat(result.isOk()).isFalse();
            assertThat(result.getStatus()).isEqualTo(500);
            assertThat(result.getMessage())
                    .isEqualTo(GENERIC_500_MESSAGE);
        }

        @Test
        @DisplayName("Response with status and message -> values passed through")
        void dataWithStatusAndMessage_passedThrough() {

            PrinterIppResponse serviceResponse =
                    serviceResponseWith(
                            404,
                            "Printer not found",
                            false);

            PrinterIppResponse result =
                    handler.buildServiceErrorResponse(
                            TRACKING_ID,
                            serviceResponse);

            assertThat(result.isOk()).isFalse();
            assertThat(result.getStatus()).isEqualTo(404);
            assertThat(result.getMessage())
                    .isEqualTo("Printer not found");
        }

        @Test
        @DisplayName("Status 0 falls back to HTTP 500")
        void dataWithZeroStatus_fallsBackTo500() {

            PrinterIppResponse serviceResponse =
                    serviceResponseWith(
                            0,
                            "Some failure",
                            false);

            PrinterIppResponse result =
                    handler.buildServiceErrorResponse(
                            TRACKING_ID,
                            serviceResponse);

            assertThat(result.isOk()).isFalse();
            assertThat(result.getStatus()).isEqualTo(500);
            assertThat(result.getMessage())
                    .isEqualTo("Some failure");
        }

        @Test
        @DisplayName("Null message -> default service error message")
        void dataWithNullMessage_usesDefaultMessage() {

            PrinterIppResponse serviceResponse =
                    serviceResponseWith(
                            502,
                            null,
                            false);

            PrinterIppResponse result =
                    handler.buildServiceErrorResponse(
                            TRACKING_ID,
                            serviceResponse);

            assertThat(result.isOk()).isFalse();
            assertThat(result.getStatus()).isEqualTo(502);
            assertThat(result.getMessage())
                    .isEqualTo("Service error occurred during vendor creation");
        }

        @Test
        @DisplayName("Service message is preserved")
        void buildServiceErrorResponse_preservesMessage() {

            PrinterIppResponse serviceResponse =
                    serviceResponseWith(
                            503,
                            "Gateway unavailable",
                            false);

            PrinterIppResponse result =
                    handler.buildServiceErrorResponse(
                            TRACKING_ID,
                            serviceResponse);

            assertThat(result.isOk()).isFalse();
            assertThat(result.getStatus()).isEqualTo(503);
            assertThat(result.getMessage())
                    .isEqualTo("Gateway unavailable");
        }
    }

    @Nested
    @DisplayName("resolveHttpStatus")
    class ResolveHttpStatus {

        @ParameterizedTest(name = "service status {0} -> HTTP {1}")
        @CsvSource({
                "1, 1",
                "200, 200",
                "404, 404",
                "599, 599",
                "0, 500",
                "-1, 500",
                "-500, 500"
        })
        void resolvesStatus(
                int serviceStatus,
                int expectedHttpStatus) {

            assertThat(handler.resolveHttpStatus(serviceStatus))
                    .isEqualTo(expectedHttpStatus);
        }

        @Test
        @DisplayName("Large positive values are returned unchanged")
        void resolveHttpStatus_largePositiveValue() {

            assertThat(
                    handler.resolveHttpStatus(Integer.MAX_VALUE))
                    .isEqualTo(Integer.MAX_VALUE);
        }
    }

    @Nested
    @DisplayName("buildErrorResponse")
    class BuildErrorResponse {

        @Test
        @DisplayName("Error response fields are populated correctly")
        void dataFields_areCorrect() {

            PrinterIppResponse result =
                    handler.buildErrorResponse(
                            TRACKING_ID,
                            503,
                            "Unavailable");

            assertThat(result).isNotNull();
            assertThat(result.isOk()).isFalse();
            assertThat(result.getStatus()).isEqualTo(503);
            assertThat(result.getMessage())
                    .isEqualTo("Unavailable");
        }

        @Test
        @DisplayName("Supports null message")
        void nullMessage_supported() {

            PrinterIppResponse result =
                    handler.buildErrorResponse(
                            TRACKING_ID,
                            500,
                            null);

            assertThat(result.isOk()).isFalse();
            assertThat(result.getStatus()).isEqualTo(500);
            assertThat(result.getMessage()).isNull();
        }

        @Test
        @DisplayName("Supports empty message")
        void emptyMessage_supported() {

            PrinterIppResponse result =
                    handler.buildErrorResponse(
                            TRACKING_ID,
                            500,
                            "");

            assertThat(result.isOk()).isFalse();
            assertThat(result.getStatus()).isEqualTo(500);
            assertThat(result.getMessage()).isEmpty();
        }

        @Test
        @DisplayName("Always builds failed response")
        void buildErrorResponse_marksFailure() {

            PrinterIppResponse result =
                    handler.buildErrorResponse(
                            TRACKING_ID,
                            404,
                            "Failure");

            assertThat(result.isOk()).isFalse();
        }
    }

    @Nested
    @DisplayName("buildSuccessResponse")
    class BuildSuccessResponse {

        @Test
        @DisplayName("Success response populated correctly")
        void populatesFields_correctly() throws Exception {

            Method method =
                    ResponseHandler.class.getDeclaredMethod(
                            "buildSuccessResponse",
                            String.class,
                            int.class,
                            String.class);

            method.setAccessible(true);

            PrinterIppResponse result =
                    (PrinterIppResponse) method.invoke(
                            handler,
                            TRACKING_ID,
                            200,
                            "Printed");

            assertThat(result).isNotNull();
            assertThat(result.isOk()).isTrue();
            assertThat(result.getStatus()).isEqualTo(200);
            assertThat(result.getMessage())
                    .isEqualTo("Printed");
        }
    }
}