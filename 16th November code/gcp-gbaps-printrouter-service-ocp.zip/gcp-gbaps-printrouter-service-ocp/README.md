# gcp-gbaps-printrouter-service-ocp
This repository will host printing service solution using Openshift.

## **_Unit test_**

### Command for report generation: 

mvn clean test

### Report Location:
target/site\jacoco-unit.html

## **_Integration test_**

### Command for report generation:

mvn clean verify

### Report Location:
target\site\jacoco-integration\index.html

## **_Combined Test Report_**
target\site\jacoco\index.html
 
