package com.costco.replatform.foundation.printrouter.service;

import com.costco.replatform.foundation.printrouter.config.PrinterIppProperties;
import com.costco.replatform.foundation.printrouter.exception.PrintRouteResponseInvalidException;
import com.costco.replatform.foundation.printrouter.model.ActiveDirectoryDiscoveryResponse;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrintRouteResponse;
import com.costco.replatform.foundation.printrouter.model.PrintStatusResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;
import com.costco.replatform.foundation.printrouter.exception.PrintRouteException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class PrinterConnectivityServiceIT {

    private ActiveDirectoryDiscoveryService discoveryService;

    private PrinterConnectivityService service;

    @BeforeEach
    void setUp() {

        discoveryService =
                mock(ActiveDirectoryDiscoveryService.class);

        service =
                new PrinterConnectivityService(
                        validProperties(),
                        discoveryService);

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "test-user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "test-password");
    }



    // ============================================================
    // doPrint() integration
    // ============================================================

    @Test
    void doPrint_success_integratesPrintWorkflow()
            throws Exception {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");
        printer.setLocation("STORE-101");

        /*
         * External printer HTTP response.
         *
         * Everything before and after HttpClient.send()
         * continues through the real production implementation.
         */

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(200);

        when(httpResponse.headers())
                .thenReturn(
                        HttpHeaders.of(
                                Map.of(
                                        "Content-Type",
                                        List.of("application/ipp")),
                                (name, value) -> true));

        when(httpResponse.body())
                .thenReturn(
                        successfulIppResponse(
                                123,
                                500,
                                9));

        HttpClient httpClient =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(httpClient);

        when(httpClient.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            ApiResponse<PrintRouteResponse> result =
                    service.doPrint(
                            123,
                            "shipping-label.pdf",
                            "PDF",
                            "TRACK-123",
                            "PRINT CONTENT",
                            List.of(printer),
                            2);

            assertNotNull(result);

            assertTrue(
                    result.isSuccess());

            assertNotNull(
                    result.getResponse());

            assertEquals(
                    "PRINTER1",
                    result.getResponse()
                            .getPrinterName());

            assertEquals(
                    "10.10.10.10",
                    result.getResponse()
                            .getPrinterIp());

            assertEquals(
                    "STORE-101",
                    result.getResponse()
                            .getLocationId());

            assertEquals(
                    500,
                    result.getResponse()
                            .getPrintJobId());

            assertEquals(
                    "COMPLETED",
                    result.getResponse()
                            .getPrintStatus());

            verify(httpClient)
                    .send(
                            any(HttpRequest.class),
                            any(HttpResponse.BodyHandler.class));
        }
    }

    @Test
    void doPrint_malformedIppResponse_throwsPrintRouteExceptionWithInvalidResponseCause()
            throws Exception {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");
        printer.setLocation("STORE-101");

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(200);

        when(httpResponse.headers())
                .thenReturn(
                        HttpHeaders.of(
                                Map.of(
                                        "Content-Type",
                                        List.of("application/ipp")),
                                (name, value) -> true));

        // HTTP succeeds, but body is not a valid IPP response.
        when(httpResponse.body())
                .thenReturn(new byte[0]);

        HttpClient httpClient =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(httpClient);

        when(httpClient.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            PrintRouteException exception =
                    assertThrows(
                            PrintRouteException.class,
                            () -> service.doPrint(
                                    123,
                                    "shipping-label.pdf",
                                    "PDF",
                                    "TRACK-123",
                                    "PRINT CONTENT",
                                    List.of(printer),
                                    2));

            assertNotNull(exception.getCause());

            assertInstanceOf(
                    PrintRouteResponseInvalidException.class,
                    exception.getCause());

            assertEquals(
                    "IPP Send Request failed",
                    exception.getCause().getMessage());

            verify(httpClient)
                    .send(
                            any(HttpRequest.class),
                            any(HttpResponse.BodyHandler.class));
        }
    }

    @Test
    void doStatusCheck_unapprovedPrinter_throwsIllegalArgumentException() {

        PrinterMetadata approvedPrinter =
                new PrinterMetadata();

        approvedPrinter.setPrinterName("DIFFERENT-PRINTER");
        approvedPrinter.setIpAddress("10.10.10.20");

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of(approvedPrinter));

        when(discoveryService
                .discoverPrintersByLocation(null))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        IllegalArgumentException exception =
                assertThrows(
                        IllegalArgumentException.class,
                        () -> service.doStatusCheck(
                                123,
                                "PRINTER1",
                                500,
                                "10.10.10.10"));

        assertEquals(
                "Printer name and address are not in the approved inventory",
                exception.getMessage());

        verify(discoveryService)
                .discoverPrintersByLocation(null);
    }

    @Test
    void doPrint_http500_throwsPrintRouteExceptionWithInvalidResponseCause()
            throws Exception {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");
        printer.setLocation("STORE-101");

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(500);

        when(httpResponse.headers())
                .thenReturn(
                        HttpHeaders.of(
                                Map.of(),
                                (name, value) -> true));

        when(httpResponse.body())
                .thenReturn(new byte[0]);

        HttpClient httpClient =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(httpClient);

        when(httpClient.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            PrintRouteException exception =
                    assertThrows(
                            PrintRouteException.class,
                            () -> service.doPrint(
                                    123,
                                    "shipping-label.pdf",
                                    "PDF",
                                    "TRACK-123",
                                    "PRINT CONTENT",
                                    List.of(printer),
                                    2));

            assertNotNull(exception.getCause());

            assertInstanceOf(
                    PrintRouteResponseInvalidException.class,
                    exception.getCause());

            assertEquals(
                    "IPP Send Request failed",
                    exception.getCause().getMessage());

            verify(httpClient)
                    .send(
                            any(HttpRequest.class),
                            any(HttpResponse.BodyHandler.class));
        }
    }

    @Test
    void doPrint_http401_throwsPrintRouteExceptionWithInvalidResponseCause()
            throws Exception {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");
        printer.setLocation("STORE-101");

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(401);

        when(httpResponse.headers())
                .thenReturn(
                        HttpHeaders.of(
                                Map.of(
                                        "WWW-Authenticate",
                                        List.of("Basic")),
                                (name, value) -> true));

        when(httpResponse.body())
                .thenReturn(new byte[0]);

        HttpClient httpClient =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(httpClient);

        when(httpClient.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            PrintRouteException exception =
                    assertThrows(
                            PrintRouteException.class,
                            () -> service.doPrint(
                                    123,
                                    "shipping-label.pdf",
                                    "PDF",
                                    "TRACK-123",
                                    "PRINT CONTENT",
                                    List.of(printer),
                                    2));

            assertNotNull(exception.getCause());

            assertInstanceOf(
                    PrintRouteResponseInvalidException.class,
                    exception.getCause());

            assertEquals(
                    "IPP Send Request failed",
                    exception.getCause().getMessage());

            verify(httpClient)
                    .send(
                            any(HttpRequest.class),
                            any(HttpResponse.BodyHandler.class));
        }
    }

    // ============================================================
    // doStatusCheck() integration
    // ============================================================

    @Test
    void doStatusCheck_success_integratesStatusWorkflow()
            throws Exception {

        /*
         * AD boundary.
         *
         * The printer exists in the approved inventory.
         */

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of(printer));

        when(discoveryService
                .discoverPrintersByLocation(null))
                .thenReturn(
                        ApiResponse.ok(
                                discoveryResponse));

        /*
         * External printer HTTP response.
         */

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(200);

        when(httpResponse.headers())
                .thenReturn(
                        HttpHeaders.of(
                                Map.of(
                                        "Content-Type",
                                        List.of("application/ipp")),
                                (name, value) -> true));

        when(httpResponse.body())
                .thenReturn(
                        successfulStatusIppResponse(
                                123,
                                9));

        HttpClient httpClient =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(httpClient);

        when(httpClient.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        /*
         * Execute the real production workflow.
         */

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            ApiResponse<PrintStatusResponse> result =
                    service.doStatusCheck(
                            123,
                            "PRINTER1",
                            500,
                            "10.10.10.10");

            assertNotNull(result);

            assertTrue(
                    result.isSuccess());

            assertNotNull(
                    result.getResponse());

            assertEquals(
                    "PRINTER1",
                    result.getResponse()
                            .getPrinterName());

            assertEquals(
                    "10.10.10.10",
                    result.getResponse()
                            .getPrinterIp());

            assertEquals(
                    500,
                    result.getResponse()
                            .getPrintJobId());

            assertEquals(
                    "COMPLETED",
                    result.getResponse()
                            .getPrintJobStatus());

            verify(httpClient)
                    .send(
                            any(HttpRequest.class),
                            any(HttpResponse.BodyHandler.class));

            verify(discoveryService)
                    .discoverPrintersByLocation(null);
        }
    }

    // ============================================================
    // Test configuration
    // ============================================================

    private PrinterIppProperties validProperties() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setRequestingUser(
                "integration-user");

        properties.setJobName(
                "IT_JOB_");

        properties.setPrintContent(
                "PRINT CONTENT");

        properties.setConnectTimeoutSeconds(10);

        properties.setRequestTimeoutSeconds(30);

        properties.setCredEncoded(false);

        return properties;
    }

    // ============================================================
    // Successful Print IPP response
    // ============================================================

    private static byte[] successfulIppResponse(
            int requestId,
            int jobId,
            int jobState) {

        return new byte[] {

                // ------------------------------------------
                // IPP 1.1 header
                // ------------------------------------------

                0x01,
                0x01,

                // successful-ok
                0x00,
                0x00,

                // request ID
                (byte) ((requestId >> 24) & 0xFF),
                (byte) ((requestId >> 16) & 0xFF),
                (byte) ((requestId >> 8) & 0xFF),
                (byte) (requestId & 0xFF),

                // ------------------------------------------
                // job-id
                // ------------------------------------------

                0x21,

                // name length = 6
                0x00,
                0x06,

                'j', 'o', 'b', '-', 'i', 'd',

                // value length = 4
                0x00,
                0x04,

                // job ID value
                (byte) ((jobId >> 24) & 0xFF),
                (byte) ((jobId >> 16) & 0xFF),
                (byte) ((jobId >> 8) & 0xFF),
                (byte) (jobId & 0xFF),

                // ------------------------------------------
                // job-state
                // ------------------------------------------

                0x23,

                // name length = 9
                0x00,
                0x09,

                'j', 'o', 'b', '-',
                's', 't', 'a', 't', 'e',

                // value length = 4
                0x00,
                0x04,

                // job-state = 9 = COMPLETED
                (byte) ((jobState >> 24) & 0xFF),
                (byte) ((jobState >> 16) & 0xFF),
                (byte) ((jobState >> 8) & 0xFF),
                (byte) (jobState & 0xFF),

                /*
                 * Padding required by the current
                 * extractJobStateOfPrintRequest() parser.
                 */

                0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00,

                // end-of-attributes
                0x03
        };
    }

    // ============================================================
    // Successful Status IPP response
    // ============================================================

    private static byte[] successfulStatusIppResponse(
            int requestId,
            int jobState) {

        byte[] response =
                new byte[60];

        /*
         * IPP 1.1 header
         */
        response[0] = 0x01;
        response[1] = 0x01;

        /*
         * successful-ok
         */
        response[2] = 0x00;
        response[3] = 0x00;

        /*
         * Request ID
         */
        response[4] =
                (byte) ((requestId >> 24) & 0xFF);

        response[5] =
                (byte) ((requestId >> 16) & 0xFF);

        response[6] =
                (byte) ((requestId >> 8) & 0xFF);

        response[7] =
                (byte) (requestId & 0xFF);

        /*
         * Production extractJobStateOfJobStatusRequest()
         * searches for "job-state".
         */
        byte[] jobStateName =
                "job-state".getBytes(
                        java.nio.charset.StandardCharsets.ISO_8859_1);

        int index = 10;

        System.arraycopy(
                jobStateName,
                0,
                response,
                index,
                jobStateName.length);

        index += jobStateName.length;

        /*
         * Match the exact layout expected by
         * extractJobStateOfJobStatusRequest().
         *
         * The existing unit test proves the parser
         * expects:
         *
         * job-state
         * 00 00 00
         * 04
         * <4-byte integer>
         */

        response[index++] = 0x00;
        response[index++] = 0x00;
        response[index++] = 0x00;

        response[index++] = 0x04;

        response[index++] =
                (byte) ((jobState >> 24) & 0xFF);

        response[index++] =
                (byte) ((jobState >> 16) & 0xFF);

        response[index++] =
                (byte) ((jobState >> 8) & 0xFF);

        response[index] =
                (byte) (jobState & 0xFF);

        /*
         * Remaining bytes stay zero.
         * The larger array also gives the production
         * parser enough trailing bytes to scan safely.
         */

        response[response.length - 1] = 0x03;

        return response;
    }
}