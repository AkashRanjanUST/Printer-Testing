package com.costco.replatform.foundation.printrouter.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrinterDiscoveryExceptionTest {

    @Test
    void defaultConstructorWorks() {

        PrinterDiscoveryException exception =
                new PrinterDiscoveryException();

        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void messageConstructorWorks() {

        PrinterDiscoveryException exception =
                new PrinterDiscoveryException(
                        "Printer discovery failed");

        assertEquals(
                "Printer discovery failed",
                exception.getMessage());

        assertNull(exception.getCause());
    }

    @Test
    void messageAndCauseConstructorWorks() {

        RuntimeException cause =
                new RuntimeException("LDAP failure");

        PrinterDiscoveryException exception =
                new PrinterDiscoveryException(
                        "Printer discovery failed",
                        cause);

        assertEquals(
                "Printer discovery failed",
                exception.getMessage());

        assertSame(
                cause,
                exception.getCause());
    }

    @Test
    void causeConstructorWorks() {

        RuntimeException cause =
                new RuntimeException("LDAP failure");

        PrinterDiscoveryException exception =
                new PrinterDiscoveryException(cause);

        assertSame(
                cause,
                exception.getCause());

        assertTrue(
                exception.getMessage()
                        .contains("LDAP failure"));
    }
}