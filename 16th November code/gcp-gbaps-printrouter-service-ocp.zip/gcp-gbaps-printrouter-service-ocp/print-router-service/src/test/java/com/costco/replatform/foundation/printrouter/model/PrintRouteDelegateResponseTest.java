package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintRouteDelegateResponseTest {

    @Test
    void constructor_initializesFieldsToNull() {

        PrintRouteDelegateResponse response =
                new PrintRouteDelegateResponse();

        assertNull(response.getMessage());
        assertNull(response.getStatus());
        assertNull(response.getUrl());
        assertNull(response.getHttpStatus());
        assertNull(response.getErrorType());
    }

    @Test
    void gettersAndSettersWork() {

        PrintRouteDelegateResponse response =
                new PrintRouteDelegateResponse();

        response.setMessage("Print request delegated successfully");
        response.setStatus("SUCCESS");
        response.setUrl("http://10.10.10.10");
        response.setHttpStatus(200);
        response.setErrorType("NONE");

        assertEquals(
                "Print request delegated successfully",
                response.getMessage());

        assertEquals(
                "SUCCESS",
                response.getStatus());

        assertEquals(
                "http://10.10.10.10",
                response.getUrl());

        assertEquals(
                200,
                response.getHttpStatus());

        assertEquals(
                "NONE",
                response.getErrorType());
    }
}