package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ManifestLabelPrintDataTest {

    @Test
    void constructor_initializesFieldsToNull() {

        ManifestLabelPrintData data =
                new ManifestLabelPrintData();

        assertNull(data.getTitle());
        assertNull(data.getLoader());
        assertNull(data.getLoadNumber());
        assertNull(data.getFreightBill());
        assertNull(data.getShipTo());
        assertNull(data.getPalletQuantity());
        assertNull(data.getCartboardQuantity());
        assertNull(data.getPieceQuantity());
        assertNull(data.getBinQuantity());
        assertNull(data.getWeightLb());
        assertNull(data.getManifestNumber());
        assertNull(data.getManifestBarcodeValue());
        assertNull(data.getHazmatInfo());
        assertNull(data.getTrailerId());
        assertNull(data.getSealNumber());
        assertNull(data.getDate());
        assertNull(data.getTime());
    }

    @Test
    void gettersAndSettersWork() {

        ManifestLabelPrintData data =
                new ManifestLabelPrintData();

        data.setTitle("Manifest Label");
        data.setLoader("LOADER01");
        data.setLoadNumber("LOAD1001");
        data.setFreightBill("FB1001");
        data.setShipTo("STORE101");
        data.setPalletQuantity("10");
        data.setCartboardQuantity("20");
        data.setPieceQuantity("30");
        data.setBinQuantity("40");
        data.setWeightLb("500");
        data.setManifestNumber("MAN1001");
        data.setManifestBarcodeValue("123456789");
        data.setHazmatInfo("NONE");
        data.setTrailerId("TRAILER01");
        data.setSealNumber("SEAL1001");
        data.setDate("2026-11-18");
        data.setTime("17:30");

        assertEquals(
                "Manifest Label",
                data.getTitle());

        assertEquals(
                "LOADER01",
                data.getLoader());

        assertEquals(
                "LOAD1001",
                data.getLoadNumber());

        assertEquals(
                "FB1001",
                data.getFreightBill());

        assertEquals(
                "STORE101",
                data.getShipTo());

        assertEquals(
                "10",
                data.getPalletQuantity());

        assertEquals(
                "20",
                data.getCartboardQuantity());

        assertEquals(
                "30",
                data.getPieceQuantity());

        assertEquals(
                "40",
                data.getBinQuantity());

        assertEquals(
                "500",
                data.getWeightLb());

        assertEquals(
                "MAN1001",
                data.getManifestNumber());

        assertEquals(
                "123456789",
                data.getManifestBarcodeValue());

        assertEquals(
                "NONE",
                data.getHazmatInfo());

        assertEquals(
                "TRAILER01",
                data.getTrailerId());

        assertEquals(
                "SEAL1001",
                data.getSealNumber());

        assertEquals(
                "2026-11-18",
                data.getDate());

        assertEquals(
                "17:30",
                data.getTime());
    }
}