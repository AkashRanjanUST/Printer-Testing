package com.costco.replatform.foundation.printrouter.common.enums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DocumentTypeTest {

    @Test
    void valuesShouldExist() {
        assertEquals(2, DocumentType.values().length);
    }

    @Test
    void pdfExists() {
        assertEquals(DocumentType.PDF, DocumentType.valueOf("PDF"));
    }

    @Test
    void zplExists() {
        assertEquals(DocumentType.ZPL, DocumentType.valueOf("ZPL"));
    }
}