package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ActiveDirectoryDiscoveryResponseTest {

    @Test
    void printerListGetterSetterWorks() {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("Laser1");

        ActiveDirectoryDiscoveryResponse response =
                new ActiveDirectoryDiscoveryResponse();

        response.setPrinterList(List.of(printer));

        assertEquals(1, response.getPrinterList().size());
        assertEquals(
                "Laser1",
                response.getPrinterList().get(0).getPrinterName());
    }

    @Test
    void toStringReturnsValue() {

        ActiveDirectoryDiscoveryResponse response =
                new ActiveDirectoryDiscoveryResponse();

        assertNotNull(response.toString());
    }
}