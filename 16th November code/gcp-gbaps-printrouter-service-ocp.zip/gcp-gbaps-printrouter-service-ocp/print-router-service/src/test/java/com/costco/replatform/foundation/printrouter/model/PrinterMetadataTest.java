package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrinterMetadataTest {

    @Test
    void gettersAndSettersWork() {

        PrinterMetadata metadata =
                new PrinterMetadata();

        metadata.setPrinterName("Laser1");
        metadata.setShareName("LASER1");
        metadata.setServer("SERVER1");
        metadata.setLocation("01680");
        metadata.setModel("HP LaserJet");
        metadata.setPortName("IP_10.1.1.1");
        metadata.setIpAddress("10.1.1.1");

        assertEquals("Laser1", metadata.getPrinterName());
        assertEquals("LASER1", metadata.getShareName());
        assertEquals("SERVER1", metadata.getServer());
        assertEquals("01680", metadata.getLocation());
        assertEquals("HP LaserJet", metadata.getModel());
        assertEquals("IP_10.1.1.1", metadata.getPortName());
        assertEquals("10.1.1.1", metadata.getIpAddress());
    }

    @Test
    void toStringReturnsValue() {

        PrinterMetadata metadata =
                new PrinterMetadata();

        metadata.setPrinterName("Laser1");

        assertNotNull(metadata.toString());
        assertFalse(metadata.toString().isBlank());
    }
}