package com.costco.replatform.foundation.printrouter.controller;

import com.costco.replatform.foundation.printrouter.model.*;
import com.costco.replatform.foundation.printrouter.service.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import com.costco.replatform.foundation.printrouter.common.enums.DocumentType;
import com.costco.replatform.foundation.printrouter.common.enums.PrintType;
import com.costco.replatform.foundation.printrouter.common.enums.PrinterType;


import java.lang.reflect.Method;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PrintRouterControllerTest {

    @Mock
    private ActiveDirectoryDiscoveryService activeDirectoryDiscoveryService;

    @Mock
    private PrinterConnectivityService printerConnectivityService;

    @InjectMocks
    private PrintRouterController controller;

    @Test
    void routePrint_nullRequest_returnsBadRequest()
    {
        ResponseEntity<ApiResponse<PrintRouteResponse>> response = controller.routePrint(null);
        assertEquals(400, response.getStatusCode().value());
        assertEquals("API request is null.", response.getBody().getMessage());
    }

    @Test
    void routePrint_noPrintersFound_returnsBadRequest()
    {
        ActiveDirectoryDiscoveryResponse discoveryResponse = new ActiveDirectoryDiscoveryResponse();
        discoveryResponse.setPrinterList(List.of());

        when(activeDirectoryDiscoveryService.discoverPrintersByLocation(any())).thenReturn(ApiResponse.ok(discoveryResponse));
        ApiRequest<PrintRouteRequest> request = new ApiRequest<>();
        request.setRequest(new PrintRouteRequest());
        ResponseEntity<ApiResponse<PrintRouteResponse>> response = controller.routePrint(request);
        assertEquals(400, response.getStatusCode().value());
        assertEquals("No Printers in requested location", response.getBody().getMessage());
    }

    @Test
    void getPrintStatus_nullRequest_returnsBadRequest()
    {
        ResponseEntity<ApiResponse<PrintStatusResponse>> response = controller.getPrintStatus(null);
        assertEquals(400, response.getStatusCode().value());
    }

    @Test
    void getPrintStatus_success_returnsOk()
    {
        PrintStatusRequest printStatusRequest = new PrintStatusRequest();
        printStatusRequest.setItemNo(1);
        printStatusRequest.setPrinterName("Laser1");
        printStatusRequest.setPrintJobId(100);
        printStatusRequest.setPrinterIp("10.1.1.1");

        ApiRequest<PrintStatusRequest> apiRequest = new ApiRequest<>();
        apiRequest.setRequest(printStatusRequest);
        PrintStatusResponse printStatusResponse = new PrintStatusResponse();
        ApiResponse<PrintStatusResponse> apiResponse = ApiResponse.ok(printStatusResponse);
        when(printerConnectivityService.doStatusCheck(anyInt(), anyString(), anyInt(), anyString())).thenReturn(apiResponse);

        ResponseEntity<ApiResponse<PrintStatusResponse>> response = controller.getPrintStatus(apiRequest);
        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void mask_null_returnsNull() throws Exception {

        Method method =
                PrintRouterController.class
                        .getDeclaredMethod(
                                "mask",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        null,
                        new Object[]{null});

        assertNull(result);
    }
    @Test
    void mask_blank_returnsBlank() throws Exception {

        Method method =
                PrintRouterController.class
                        .getDeclaredMethod(
                                "mask",
                                String.class);

        method.setAccessible(true);

        assertEquals(
                "",
                method.invoke(null, ""));

        assertEquals(
                "   ",
                method.invoke(null, "   "));
    }
    @Test
    void mask_oneCharacter_returnsOneStar() throws Exception {

        Method method =
                PrintRouterController.class
                        .getDeclaredMethod(
                                "mask",
                                String.class);

        method.setAccessible(true);

        assertEquals(
                "*",
                method.invoke(null, "A"));
    }
    @Test
    void mask_twoCharacters_returnsTwoStars() throws Exception {

        Method method =
                PrintRouterController.class
                        .getDeclaredMethod(
                                "mask",
                                String.class);

        method.setAccessible(true);

        assertEquals(
                "**",
                method.invoke(null, "AB"));
    }
    @Test
    void mask_longValue_masksMiddleCharacters() throws Exception {

        Method method =
                PrintRouterController.class
                        .getDeclaredMethod(
                                "mask",
                                String.class);

        method.setAccessible(true);

        assertEquals(
                "A***h",
                method.invoke(null, "Akash"));
    }
    @Test
    void routePrint_nullInnerRequest_withNoPrinters_returnsBadRequest() {

        ApiRequest<PrintRouteRequest> apiRequest =
                new ApiRequest<>();

        apiRequest.setRequestId(
                "REQ-100");

        apiRequest.setRequest(null);

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of());

        when(activeDirectoryDiscoveryService
                .discoverPrintersByLocation(null))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        ResponseEntity<ApiResponse<PrintRouteResponse>> response =
                controller.routePrint(apiRequest);

        assertEquals(
                400,
                response.getStatusCode().value());

        assertNotNull(
                response.getBody());

        assertEquals(
                "No Printers in requested location",
                response.getBody().getMessage());

        verify(activeDirectoryDiscoveryService)
                .discoverPrintersByLocation(null);
    }
    @Test
    void routePrint_nullMetadata_withNoPrinters_returnsBadRequest() {

        PrintRouteRequest printRouteRequest =
                new PrintRouteRequest();

        printRouteRequest.setPrintMetadata(null);

        ApiRequest<PrintRouteRequest> apiRequest =
                new ApiRequest<>();

        apiRequest.setRequest(
                printRouteRequest);

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of());

        when(activeDirectoryDiscoveryService
                .discoverPrintersByLocation(null))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        ResponseEntity<ApiResponse<PrintRouteResponse>> response =
                controller.routePrint(apiRequest);

        assertEquals(
                400,
                response.getStatusCode().value());

        assertEquals(
                "No Printers in requested location",
                response.getBody().getMessage());
    }
    @Test
    void getPrintStatus_nullInnerRequest_returnsOkInitializedResponse() {

        ApiRequest<PrintStatusRequest> apiRequest =
                new ApiRequest<>();

        apiRequest.setRequest(null);

        ResponseEntity<ApiResponse<PrintStatusResponse>> response =
                controller.getPrintStatus(apiRequest);

        assertEquals(
                200,
                response.getStatusCode().value());

        assertNotNull(
                response.getBody());

        assertNotNull(
                response.getBody().getResponse());

        verifyNoInteractions(
                printerConnectivityService);
    }

    @Test
    void routePrint_validRequest_returnsOk() {

        PrintMetadata metadata =
                new PrintMetadata();

        metadata.setFilecontent("PRINT CONTENT");
        metadata.setCopies(2);
        metadata.setDocumentName("shipping-label.pdf");
        metadata.setDocumentType(DocumentType.PDF);
        metadata.setItemNo(123);
        metadata.setLocationId("STORE-101");

        metadata.setPrinterType(
                PrinterType.values()[0]);

        metadata.setPrintType(
                PrintType.values()[0]);

        metadata.setRequestedUser("test-user");
        metadata.setRequestTime("2026-11-18T18:30:00");
        metadata.setTrackingId("TRACK-123");

        PrintRouteRequest printRouteRequest =
                new PrintRouteRequest();

        printRouteRequest.setPrintMetadata(metadata);

        ApiRequest<PrintRouteRequest> apiRequest =
                new ApiRequest<>();

        apiRequest.setRequestId("UI-REQ-123");
        apiRequest.setRequest(printRouteRequest);

        // Printer returned by AD discovery
        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");
        printer.setLocation("STORE-101");

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of(printer));

        when(activeDirectoryDiscoveryService
                .discoverPrintersByLocation("STORE-101"))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        // Successful print response
        PrintRouteResponse printResponse =
                new PrintRouteResponse();

        printResponse.setPrinterName("PRINTER1");
        printResponse.setPrinterIp("10.10.10.10");
        printResponse.setLocationId("STORE-101");
        printResponse.setPrintJobId(500);
        printResponse.setPrintStatus("COMPLETED");

        when(printerConnectivityService.doPrint(
                eq(123),
                eq("shipping-label.pdf"),
                eq("PDF"),
                eq("TRACK-123"),
                eq("PRINT CONTENT"),
                anyList(),
                eq(2)))
                .thenReturn(
                        ApiResponse.ok(printResponse));

        ResponseEntity<ApiResponse<PrintRouteResponse>> response =
                controller.routePrint(apiRequest);

        assertEquals(
                200,
                response.getStatusCode().value());

        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
        assertNotNull(response.getBody().getResponse());

        assertEquals(
                "PRINTER1",
                response.getBody()
                        .getResponse()
                        .getPrinterName());

        assertEquals(
                "10.10.10.10",
                response.getBody()
                        .getResponse()
                        .getPrinterIp());

        assertEquals(
                "STORE-101",
                response.getBody()
                        .getResponse()
                        .getLocationId());

        assertEquals(
                500,
                response.getBody()
                        .getResponse()
                        .getPrintJobId());

        assertEquals(
                "COMPLETED",
                response.getBody()
                        .getResponse()
                        .getPrintStatus());

        verify(activeDirectoryDiscoveryService)
                .discoverPrintersByLocation(
                        "STORE-101");

        verify(printerConnectivityService)
                .doPrint(
                        eq(123),
                        eq("shipping-label.pdf"),
                        eq("PDF"),
                        eq("TRACK-123"),
                        eq("PRINT CONTENT"),
                        anyList(),
                        eq(2));
    }
}