package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrinterIppResponseTest {

    @Test
    void gettersAndSettersWork() {

        PrinterIppResponse response =
                new PrinterIppResponse();

        response.setOk(true);
        response.setTransId("TXN1");
        response.setStatus(200);
        response.setMessage("SUCCESS");
        response.setPrinterName("Laser1");
        response.setPrinterIp("10.1.1.1");
        response.setPrintJobId(101);
        response.setPrintJobStatus("COMPLETED");

        assertTrue(response.isOk());
        assertEquals("TXN1", response.getTransId());
        assertEquals(200, response.getStatus());
        assertEquals("SUCCESS", response.getMessage());
        assertEquals("Laser1", response.getPrinterName());
        assertEquals("10.1.1.1", response.getPrinterIp());
        assertEquals(101, response.getPrintJobId());
        assertEquals("COMPLETED", response.getPrintJobStatus());
    }

    @Test
    void setStatusNullDoesNotChangeValue() {

        PrinterIppResponse response =
                new PrinterIppResponse();

        response.setStatus(200);
        response.setStatus((Integer) null);

        assertEquals(200, response.getStatus());
    }

    @Test
    void toStringReturnsValue() {

        PrinterIppResponse response =
                new PrinterIppResponse();

        assertNotNull(response.toString());
        assertFalse(response.toString().isBlank());
    }

    @Test
    void setStatusInteger_coversNullAndNonNullBranches() {

        PrinterIppResponse response =
                new PrinterIppResponse();

        // Integer overload, non-null branch
        response.setStatus(Integer.valueOf(201));

        assertEquals(
                201,
                response.getStatus());

        // Integer overload, null branch
        response.setStatus((Integer) null);

        // null must not change the previous value
        assertEquals(
                201,
                response.getStatus());
    }
}