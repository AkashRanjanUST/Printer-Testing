package com.costco.replatform.foundation.printrouter.util;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class PrintRouterIppRequestBuilderTest {

    @Test
    void createGetPrinterAttributesRequest_buildsValidIppRequest()
            throws Exception {

        int requestId = 12345;
        String printerUri =
                "ipp://192.168.1.50/ipp/print";

        byte[] result =
                PrintRouterIppRequestBuilder
                        .createGetPrinterAttributesRequest(
                                requestId,
                                printerUri);

        assertNotNull(result);
        assertTrue(result.length > 8);

        // IPP version 1.1
        assertEquals(
                0x01,
                result[0] & 0xFF);

        assertEquals(
                0x01,
                result[1] & 0xFF);

        // Get-Printer-Attributes operation = 0x000B
        int operationId =
                ((result[2] & 0xFF) << 8)
                        | (result[3] & 0xFF);

        assertEquals(
                0x000B,
                operationId);

        // Validate request ID
        int actualRequestId =
                ((result[4] & 0xFF) << 24)
                        | ((result[5] & 0xFF) << 16)
                        | ((result[6] & 0xFF) << 8)
                        | (result[7] & 0xFF);

        assertEquals(
                requestId,
                actualRequestId);

        // Operation attributes group
        assertEquals(
                0x01,
                result[8] & 0xFF);

        // End-of-attributes tag
        assertEquals(
                0x03,
                result[result.length - 1] & 0xFF);
    }

    @Test
    void createGetPrinterAttributesRequest_containsExpectedAttributes()
            throws Exception {

        String printerUri =
                "ipp://192.168.1.50/ipp/print";

        byte[] result =
                PrintRouterIppRequestBuilder
                        .createGetPrinterAttributesRequest(
                                1,
                                printerUri);

        String binaryText =
                new String(
                        result,
                        StandardCharsets.ISO_8859_1);

        assertTrue(
                binaryText.contains(
                        "attributes-charset"));

        assertTrue(
                binaryText.contains(
                        "utf-8"));

        assertTrue(
                binaryText.contains(
                        "attributes-natural-language"));

        assertTrue(
                binaryText.contains(
                        "en-us"));

        assertTrue(
                binaryText.contains(
                        "printer-uri"));

        assertTrue(
                binaryText.contains(
                        printerUri));
    }

    @Test
    void createGetPrinterAttributesRequest_preservesDifferentRequestIds()
            throws Exception {

        byte[] first =
                PrintRouterIppRequestBuilder
                        .createGetPrinterAttributesRequest(
                                1,
                                "ipp://192.168.1.50/ipp/print");

        byte[] second =
                PrintRouterIppRequestBuilder
                        .createGetPrinterAttributesRequest(
                                999,
                                "ipp://192.168.1.50/ipp/print");

        int firstRequestId =
                ((first[4] & 0xFF) << 24)
                        | ((first[5] & 0xFF) << 16)
                        | ((first[6] & 0xFF) << 8)
                        | (first[7] & 0xFF);

        int secondRequestId =
                ((second[4] & 0xFF) << 24)
                        | ((second[5] & 0xFF) << 16)
                        | ((second[6] & 0xFF) << 8)
                        | (second[7] & 0xFF);

        assertEquals(1, firstRequestId);
        assertEquals(999, secondRequestId);
        assertNotEquals(firstRequestId, secondRequestId);
    }
}