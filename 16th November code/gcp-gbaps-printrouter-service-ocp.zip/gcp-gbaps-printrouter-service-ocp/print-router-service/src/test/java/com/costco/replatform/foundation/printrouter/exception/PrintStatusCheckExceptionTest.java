package com.costco.replatform.foundation.printrouter.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import javax.net.ssl.SSLHandshakeException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PrintStatusCheckExceptionTest {

    @Test
    void socketTimeoutReturnsGatewayTimeout() {
        assertEquals(
                HttpStatus.GATEWAY_TIMEOUT,
                PrintStatusCheckException.getHttpStatus(
                        new SocketTimeoutException()));
    }

    @Test
    void connectExceptionReturnsServiceUnavailable() {
        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                PrintStatusCheckException.getHttpStatus(
                        new ConnectException()));
    }

    @Test
    void socketExceptionReturnsServiceUnavailable() {
        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                PrintStatusCheckException.getHttpStatus(
                        new SocketException()));
    }

    @Test
    void sslExceptionReturnsBadGateway() {
        assertEquals(
                HttpStatus.BAD_GATEWAY,
                PrintStatusCheckException.getHttpStatus(
                        new SSLHandshakeException("ssl")));
    }

    @Test
    void illegalArgumentReturnsBadRequest() {
        assertEquals(
                HttpStatus.BAD_REQUEST,
                PrintStatusCheckException.getHttpStatus(
                        new IllegalArgumentException()));
    }

    @Test
    void genericExceptionReturnsInternalServerError() {
        assertEquals(
                HttpStatus.INTERNAL_SERVER_ERROR,
                PrintStatusCheckException.getHttpStatus(
                        new RuntimeException()));
    }
}