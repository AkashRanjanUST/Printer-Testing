package com.costco.replatform.foundation.printrouter.util;

import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class UtilityTest {

    public static void main(String[] args) {

        String username = "NP\\"+"COSTCO_NP_USERNAME";
        String password = "COSTCO_NP_PWD";
        String url = "http://10.20.70.68";//Laser1

        try {
            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .followRedirects(HttpClient.Redirect.ALWAYS)
                    .authenticator(new Authenticator() {
                        @Override
                        protected PasswordAuthentication getPasswordAuthentication() {
                            System.out.println("Authentication requested:");
                            System.out.println("  Host   : " + getRequestingHost());
                            System.out.println("  Scheme : " + getRequestingScheme());
                            System.out.println("  Prompt : " + getRequestingPrompt());

                            return new PasswordAuthentication(
                                    username,
                                    password.toCharArray());
                        }
                    })
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .timeout(Duration.ofSeconds(10))
                    .GET()
                    .build();

            System.out.println("Sending request to: " + url);

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("\n===== RESPONSE =====");
            System.out.println("Final URI          : " + response.uri());
            System.out.println("Status Code        : " + response.statusCode());

            System.out.println("\n===== HEADERS =====");
            response.headers().map().forEach((k, v) ->
                    System.out.println(k + " = " + v));

            System.out.println("\n===== BODY INFO =====");
            System.out.println("Response Length    : " + response.body().length());

            String body = response.body();
            if (body.length() > 500) {
                System.out.println("First 500 chars:");
                System.out.println(body.substring(0, 500));
            } else {
                System.out.println(body);
            }

        } catch (Exception e) {
            System.err.println("\n===== ERROR =====");
            System.err.println("Connection failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}