package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ShippingDocPrintDataTest {

    @Test
    void gettersAndSettersWork() {

        ShippingDocPrintData data =
                new ShippingDocPrintData();

        data.setTitle("Shipping Document");
        data.setPackageId("PKG-1001");
        data.setPackageType("CASE");
        data.setVendorName("Vendor");
        data.setDate("2026-11-18");
        data.setDocumentNumber("DOC-1001");
        data.setLocation("STORE-101");
        data.setAccountNumber("ACC-1001");
        data.setRaNumber("RA-1001");
        data.setItemNumber("ITEM-1001");
        data.setItemDescription("Test Item");
        data.setSellUnits("10");
        data.setShippingCharge("25.50");
        data.setExtendedWeight("100.5");
        data.setItemBarcode("123456789");
        data.setProductStatus("ACTIVE");
        data.setAction("RETURN");
        data.setRtv("RTV-100");
        data.setManager("Manager");
        data.setLogLine("Log Line");
        data.setCaseCount("5");
        data.setBoff("BOFF");
        data.setTotalWeightCases("500");
        data.setTotalSell("1000");
        data.setControlTotal("1500");
        data.setTotalDate("2026-11-18");
        data.setPageNumber("1");

        assertEquals(
                "Shipping Document",
                data.getTitle());

        assertEquals(
                "PKG-1001",
                data.getPackageId());

        assertEquals(
                "CASE",
                data.getPackageType());

        assertEquals(
                "Vendor",
                data.getVendorName());

        assertEquals(
                "2026-11-18",
                data.getDate());

        assertEquals(
                "DOC-1001",
                data.getDocumentNumber());

        assertEquals(
                "STORE-101",
                data.getLocation());

        assertEquals(
                "ACC-1001",
                data.getAccountNumber());

        assertEquals(
                "RA-1001",
                data.getRaNumber());

        assertEquals(
                "ITEM-1001",
                data.getItemNumber());

        assertEquals(
                "Test Item",
                data.getItemDescription());

        assertEquals(
                "10",
                data.getSellUnits());

        assertEquals(
                "25.50",
                data.getShippingCharge());

        assertEquals(
                "100.5",
                data.getExtendedWeight());

        assertEquals(
                "123456789",
                data.getItemBarcode());

        assertEquals(
                "ACTIVE",
                data.getProductStatus());

        assertEquals(
                "RETURN",
                data.getAction());

        assertEquals(
                "RTV-100",
                data.getRtv());

        assertEquals(
                "Manager",
                data.getManager());

        assertEquals(
                "Log Line",
                data.getLogLine());

        assertEquals(
                "5",
                data.getCaseCount());

        assertEquals(
                "BOFF",
                data.getBoff());

        assertEquals(
                "500",
                data.getTotalWeightCases());

        assertEquals(
                "1000",
                data.getTotalSell());

        assertEquals(
                "1500",
                data.getControlTotal());

        assertEquals(
                "2026-11-18",
                data.getTotalDate());

        assertEquals(
                "1",
                data.getPageNumber());
    }
}