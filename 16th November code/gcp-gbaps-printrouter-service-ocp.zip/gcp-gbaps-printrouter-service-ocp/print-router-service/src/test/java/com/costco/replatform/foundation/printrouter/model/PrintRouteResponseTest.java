package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintRouteResponseTest {

    @Test
    void gettersAndSettersWork() {

        PrintRouteResponse response =
                new PrintRouteResponse();

        response.setLocationId("STORE-101");
        response.setPrinterName("PRINTER01");
        response.setPrinterIp("10.10.10.10");
        response.setPrintJobId(12345);
        response.setPrintStatus("COMPLETED");

        assertEquals(
                "STORE-101",
                response.getLocationId());

        assertEquals(
                "PRINTER01",
                response.getPrinterName());

        assertEquals(
                "10.10.10.10",
                response.getPrinterIp());

        assertEquals(
                12345,
                response.getPrintJobId());

        assertEquals(
                "COMPLETED",
                response.getPrintStatus());
    }

    @Test
    void toStringReturnsValue() {

        PrintRouteResponse response =
                new PrintRouteResponse();

        response.setLocationId("STORE-101");
        response.setPrinterName("PRINTER01");
        response.setPrintJobId(12345);
        response.setPrintStatus("COMPLETED");

        String result = response.toString();

        assertNotNull(result);
        assertFalse(result.isBlank());
    }
}