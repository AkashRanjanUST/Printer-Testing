package com.costco.replatform.foundation.printrouter.service;

import com.costco.replatform.foundation.printrouter.config.PrinterIppProperties;
import com.costco.replatform.foundation.printrouter.model.ActiveDirectoryDiscoveryResponse;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import javax.naming.ldap.Control;
import javax.naming.ldap.PagedResultsResponseControl;

import static org.mockito.Mockito.mock;

import javax.naming.PartialResultException;
import javax.naming.directory.*;
import javax.naming.ldap.InitialLdapContext;
import org.mockito.MockedConstruction;
import javax.naming.NamingException;

import static org.mockito.Mockito.*;

import java.util.Base64;

import static org.mockito.Mockito.mockConstruction;
import javax.naming.directory.Attribute;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import javax.naming.ldap.LdapContext;

import static org.mockito.Mockito.*;
import java.lang.reflect.Method;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ActiveDirectoryDiscoveryServiceTest {

    private ActiveDirectoryDiscoveryService service;

    @BeforeEach
    void setup() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setCredEncoded(false);

        service =
                new ActiveDirectoryDiscoveryService(properties);

        ReflectionTestUtils.setField(
                service,
                "bindUser",
                "user");

        ReflectionTestUtils.setField(
                service,
                "bindPassword",
                "password");
    }

    @Test
    void extractIpAddress_returnsIpAddress()
            throws Exception {

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "extractIpAddress",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        "IP_10.20.30.40");

        assertEquals(
                "10.20.30.40",
                result);
    }

    @Test
    void extractIpAddress_returnsNullWhenNoIpExists()
            throws Exception {

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "extractIpAddress",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        "INVALID");

        assertNull(result);
    }

    @Test
    void extractIpAddress_returnsNullForNull()
            throws Exception {

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "extractIpAddress",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        new Object[]{null});

        assertNull(result);
    }

    @Test
    void extractIpAddress_findsIpInsidePortName()
            throws Exception {

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "extractIpAddress",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        "IP_192.168.1.50_Printer");

        assertEquals(
                "192.168.1.50",
                result);
    }

    @Test
    void escapeFilter_escapeCharacters()
            throws Exception {

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "escapeLDAPSearchFilter",
                                String.class);

        method.setAccessible(true);

        String escaped =
                (String) method.invoke(
                        null,
                        "test*(abc)");

        assertTrue(escaped.contains("\\2a"));
        assertTrue(escaped.contains("\\28"));
        assertTrue(escaped.contains("\\29"));
    }

    @Test
    void escapeFilter_returnsSameValueForNormalText()
            throws Exception {

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "escapeLDAPSearchFilter",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        null,
                        "ABC123");

        assertEquals(
                "ABC123",
                result);
    }

    @Test
    void escapeFilter_allSpecialCharacters()
            throws Exception {

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "escapeLDAPSearchFilter",
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        null,
                        "\\*()\0");

        assertEquals(
                "\\5c\\2a\\28\\29\\00",
                result);
    }

    @Test
    void getFirstValue_returnsAttributeValue()
            throws Exception {

        BasicAttributes attributes =
                new BasicAttributes();

        Attribute attribute =
                new BasicAttribute(
                        "cn",
                        "Printer1");

        attributes.put(attribute);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "getFirstValue",
                                Attributes.class,
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        attributes,
                        "cn");

        assertEquals(
                "Printer1",
                result);
    }

    @Test
    void getFirstValue_returnsEmptyStringForMissingAttribute()
            throws Exception {

        BasicAttributes attributes =
                new BasicAttributes();

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "getFirstValue",
                                Attributes.class,
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        attributes,
                        "missing");

        assertEquals(
                "",
                result);
    }

    @Test
    void getFirstValue_returnsEmptyStringForUnknownAttribute()
            throws Exception {

        BasicAttributes attributes =
                new BasicAttributes();

        attributes.put(
                new BasicAttribute(
                        "printer",
                        "LaserJet"));

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "getFirstValue",
                                Attributes.class,
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        attributes,
                        "location");

        assertEquals(
                "",
                result);
    }

    @Test
    void searchPrintQueues_returnsPrinterMetadata()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        SearchResult result =
                mock(SearchResult.class);

        Attributes attributes =
                new BasicAttributes();

        attributes.put(
                new BasicAttribute(
                        "cn",
                        "PRINTER01"));

        attributes.put(
                new BasicAttribute(
                        "printsharename",
                        "SHARE01"));

        attributes.put(
                new BasicAttribute(
                        "shortservername",
                        "SERVER01"));

        attributes.put(
                new BasicAttribute(
                        "location",
                        "STORE01"));

        attributes.put(
                new BasicAttribute(
                        "drivername",
                        "HP"));

        attributes.put(
                new BasicAttribute(
                        "portname",
                        "IP_10.20.30.40"));

        when(result.getAttributes())
                .thenReturn(attributes);

        when(enumeration.hasMore())
                .thenReturn(true)
                .thenReturn(false);

        when(enumeration.next())
                .thenReturn(result);

        when(ctx.search(
                anyString(),
                anyString(),
                any()))
                .thenReturn(enumeration);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<?> printers =
                (List<?>) method.invoke(
                        service,
                        ctx,
                        "DC=test",
                        null);

        assertEquals(1, printers.size());

        verify(enumeration)
                .close();
    }
    @Test
    void searchPrintQueues_emptyResult()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        when(enumeration.hasMore())
                .thenReturn(false);

        when(ctx.search(
                anyString(),
                anyString(),
                any()))
                .thenReturn(enumeration);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class,
                                String.class);

        method.setAccessible(true);

        List<?> result =
                (List<?>) method.invoke(
                        service,
                        ctx,
                        "DC=test",
                        "01680");

        assertTrue(result.isEmpty());

        verify(enumeration)
                .close();
    }
    @Test
    void discoverPrintersByLocation_handlesConnectionFailure() {

        ReflectionTestUtils.setField(
                service,
                "dcHost",
                "invalid-host");

        ApiResponse<?> response =
                service.discoverPrintersByLocation(
                        "01680");

        assertNotNull(response);
        assertTrue(response.isSuccess());
    }

    @Test
    void searchPrintQueues_withoutLocation_returnsMappedPrinter()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        SearchResult searchResult =
                mock(SearchResult.class);

        BasicAttributes attributes =
                new BasicAttributes();

        attributes.put(
                new BasicAttribute(
                        "cn",
                        "PRINTER01"));

        attributes.put(
                new BasicAttribute(
                        "printsharename",
                        "SHARE01"));

        attributes.put(
                new BasicAttribute(
                        "shortservername",
                        "SERVER01"));

        attributes.put(
                new BasicAttribute(
                        "location",
                        "STORE01"));

        attributes.put(
                new BasicAttribute(
                        "drivername",
                        "HP LaserJet"));

        when(searchResult.getAttributes())
                .thenReturn(attributes);

        when(enumeration.hasMore())
                .thenReturn(true, false);

        when(enumeration.next())
                .thenReturn(searchResult);

        when(ctx.search(
                anyString(),
                anyString(),
                any(javax.naming.directory.SearchControls.class)))
                .thenReturn(enumeration);

        when(ctx.getResponseControls())
                .thenReturn(null);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<PrinterMetadata> result =
                (List<PrinterMetadata>)
                        method.invoke(
                                service,
                                ctx,
                                "DC=test,DC=com");

        assertNotNull(result);
        assertEquals(1, result.size());

        PrinterMetadata printer =
                result.get(0);

        assertEquals(
                "PRINTER01",
                printer.getPrinterName());

        assertEquals(
                "SHARE01",
                printer.getShareName());

        assertEquals(
                "SERVER01",
                printer.getServer());

        assertEquals(
                "STORE01",
                printer.getLocation());

        assertEquals(
                "HP LaserJet",
                printer.getModel());

        verify(enumeration).close();
        verify(ctx).setRequestControls(any());
    }

    @Test
    void searchPrintQueues_withoutLocation_emptyResult()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        when(enumeration.hasMore())
                .thenReturn(false);

        when(ctx.search(
                anyString(),
                anyString(),
                any(javax.naming.directory.SearchControls.class)))
                .thenReturn(enumeration);

        when(ctx.getResponseControls())
                .thenReturn(null);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<PrinterMetadata> result =
                (List<PrinterMetadata>)
                        method.invoke(
                                service,
                                ctx,
                                "DC=test,DC=com");

        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(enumeration).close();
    }

    @Test
    void connect_plainCredentials_returnsLdapContext()
            throws Exception {

        ReflectionTestUtils.setField(
                service,
                "dcProtocol",
                "ldap://");

        ReflectionTestUtils.setField(
                service,
                "dcHost",
                "localhost");

        ReflectionTestUtils.setField(
                service,
                "dcPort",
                ":389");

        ReflectionTestUtils.setField(
                service,
                "bindUser",
                "test-user");

        ReflectionTestUtils.setField(
                service,
                "bindPassword",
                "test-password");

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod("connect");

        method.setAccessible(true);

        try (MockedConstruction<InitialLdapContext> mocked =
                     mockConstruction(InitialLdapContext.class)) {

            Object result =
                    method.invoke(service);

            assertNotNull(result);
            assertEquals(1, mocked.constructed().size());
            assertSame(
                    mocked.constructed().get(0),
                    result);
        }
    }

    @Test
    void connect_encodedCredentials_returnsLdapContext()
            throws Exception {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setCredEncoded(true);

        ActiveDirectoryDiscoveryService encodedService =
                new ActiveDirectoryDiscoveryService(properties);

        ReflectionTestUtils.setField(
                encodedService,
                "dcProtocol",
                "ldap://");

        ReflectionTestUtils.setField(
                encodedService,
                "dcHost",
                "localhost");

        ReflectionTestUtils.setField(
                encodedService,
                "dcPort",
                ":389");

        ReflectionTestUtils.setField(
                encodedService,
                "bindUser",
                Base64.getEncoder()
                        .encodeToString(
                                "test-user".getBytes()));

        ReflectionTestUtils.setField(
                encodedService,
                "bindPassword",
                Base64.getEncoder()
                        .encodeToString(
                                "test-password".getBytes()));

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod("connect");

        method.setAccessible(true);

        try (MockedConstruction<InitialLdapContext> mocked =
                     mockConstruction(
                             InitialLdapContext.class)) {

            Object result =
                    method.invoke(encodedService);

            assertNotNull(result);
            assertEquals(1, mocked.constructed().size());
        }
    }

    @Test
    void getFirstValue_whenAttributeThrowsNamingException_returnsEmptyString()
            throws Exception {

        Attributes attributes = mock(Attributes.class);
        Attribute attribute = mock(Attribute.class);

        when(attributes.get("cn"))
                .thenReturn(attribute);

        when(attribute.get())
                .thenThrow(new NamingException("LDAP attribute error"));

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "getFirstValue",
                                Attributes.class,
                                String.class);

        method.setAccessible(true);

        String result =
                (String) method.invoke(
                        service,
                        attributes,
                        "cn");

        assertEquals("", result);
    }
    @Test
    void discoverPrintersByLocation_success_returnsPrintersAndClosesContext()
            throws Exception {

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        SearchResult searchResult =
                mock(SearchResult.class);

        BasicAttributes attributes =
                new BasicAttributes();

        attributes.put(new BasicAttribute("cn", "PRINTER01"));
        attributes.put(new BasicAttribute("printsharename", "SHARE01"));
        attributes.put(new BasicAttribute("shortservername", "SERVER01"));
        attributes.put(new BasicAttribute("location", "STORE01"));
        attributes.put(new BasicAttribute("drivername", "HP"));
        attributes.put(new BasicAttribute("portname", "IP_10.20.30.40"));

        when(searchResult.getAttributes())
                .thenReturn(attributes);

        when(enumeration.hasMore())
                .thenReturn(true, false);

        when(enumeration.next())
                .thenReturn(searchResult);

        try (MockedConstruction<InitialLdapContext> mocked =
                     mockConstruction(
                             InitialLdapContext.class,
                             (mock, context) -> {

                                 when(mock.search(
                                         anyString(),
                                         anyString(),
                                         any(SearchControls.class)))
                                         .thenReturn(enumeration);

                                 when(mock.getResponseControls())
                                         .thenReturn(null);
                             })) {

            ReflectionTestUtils.setField(
                    service,
                    "dcProtocol",
                    "ldap://");

            ReflectionTestUtils.setField(
                    service,
                    "dcHost",
                    "localhost");

            ReflectionTestUtils.setField(
                    service,
                    "dcPort",
                    ":389");

            ReflectionTestUtils.setField(
                    service,
                    "domainDn",
                    "DC=test,DC=com");

            ApiResponse<ActiveDirectoryDiscoveryResponse> result =
                    service.discoverPrintersByLocation("STORE01");

            assertNotNull(result);
            assertTrue(result.isSuccess());
            assertNotNull(result.getResponse());
            assertNotNull(result.getResponse().getPrinterList());

            assertEquals(
                    1,
                    result.getResponse()
                            .getPrinterList()
                            .size());

            PrinterMetadata printer =
                    result.getResponse()
                            .getPrinterList()
                            .get(0);

            assertEquals("PRINTER01", printer.getPrinterName());
            assertEquals("STORE01", printer.getLocation());
            assertEquals("10.20.30.40", printer.getIpAddress());

            InitialLdapContext context =
                    mocked.constructed().get(0);

            verify(context).close();
            verify(enumeration).close();
        }
    }

    @Test
    void searchPrintQueues_withLocation_handlesPartialResultException()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        when(ctx.search(
                anyString(),
                anyString(),
                any(SearchControls.class)))
                .thenReturn(enumeration);

        when(enumeration.hasMore())
                .thenThrow(
                        new PartialResultException("Referral"));

        when(ctx.getResponseControls())
                .thenReturn(null);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<PrinterMetadata> result =
                (List<PrinterMetadata>) method.invoke(
                        service,
                        ctx,
                        "DC=test,DC=com",
                        "STORE01");

        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(enumeration).close();
    }
    @Test
    void searchPrintQueues_withoutLocation_handlesPartialResultException()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        when(ctx.search(
                anyString(),
                anyString(),
                any(SearchControls.class)))
                .thenReturn(enumeration);

        when(enumeration.hasMore())
                .thenThrow(
                        new PartialResultException("Referral"));

        when(ctx.getResponseControls())
                .thenReturn(null);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<PrinterMetadata> result =
                (List<PrinterMetadata>) method.invoke(
                        service,
                        ctx,
                        "DC=test,DC=com");

        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(enumeration).close();
    }
    @Test
    void searchPrintQueues_blankLocation_usesDefaultFilter()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        when(enumeration.hasMore())
                .thenReturn(false);

        when(ctx.search(
                anyString(),
                eq("(objectCategory=printQueue)"),
                any(SearchControls.class)))
                .thenReturn(enumeration);

        when(ctx.getResponseControls())
                .thenReturn(null);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<PrinterMetadata> result =
                (List<PrinterMetadata>) method.invoke(
                        service,
                        ctx,
                        "DC=test,DC=com",
                        "   ");

        assertTrue(result.isEmpty());

        verify(ctx).search(
                eq("DC=test,DC=com"),
                eq("(objectCategory=printQueue)"),
                any(SearchControls.class));

        verify(enumeration).close();
    }
    @Test
    void searchPrintQueues_withLocation_handlesPagedResults()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> firstPage =
                mock(NamingEnumeration.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> secondPage =
                mock(NamingEnumeration.class);

        when(firstPage.hasMore())
                .thenReturn(false);

        when(secondPage.hasMore())
                .thenReturn(false);

        when(ctx.search(
                anyString(),
                anyString(),
                any(SearchControls.class)))
                .thenReturn(firstPage)
                .thenReturn(secondPage);

        PagedResultsResponseControl pageControl =
                mock(PagedResultsResponseControl.class);

        when(pageControl.getCookie())
                .thenReturn(new byte[]{1, 2, 3});

        when(ctx.getResponseControls())
                .thenReturn(
                        new Control[]{pageControl})
                .thenReturn(null);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<PrinterMetadata> result =
                (List<PrinterMetadata>) method.invoke(
                        service,
                        ctx,
                        "DC=test,DC=com",
                        "STORE01");

        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(firstPage).close();
        verify(secondPage).close();

        verify(
                ctx,
                times(2))
                .search(
                        anyString(),
                        anyString(),
                        any(SearchControls.class));
    }
    @Test
    void searchPrintQueues_withoutLocation_handlesPagedResults()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> firstPage =
                mock(NamingEnumeration.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> secondPage =
                mock(NamingEnumeration.class);

        when(firstPage.hasMore())
                .thenReturn(false);

        when(secondPage.hasMore())
                .thenReturn(false);

        when(ctx.search(
                anyString(),
                anyString(),
                any(SearchControls.class)))
                .thenReturn(firstPage)
                .thenReturn(secondPage);

        PagedResultsResponseControl pageControl =
                mock(PagedResultsResponseControl.class);

        when(pageControl.getCookie())
                .thenReturn(new byte[]{1});

        when(ctx.getResponseControls())
                .thenReturn(
                        new Control[]{pageControl})
                .thenReturn(null);

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<PrinterMetadata> result =
                (List<PrinterMetadata>) method.invoke(
                        service,
                        ctx,
                        "DC=test,DC=com");

        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(firstPage).close();
        verify(secondPage).close();

        verify(
                ctx,
                times(2))
                .search(
                        anyString(),
                        anyString(),
                        any(SearchControls.class));
    }

    @Test
    void searchPrintQueues_ignoresNonPagingResponseControl()
            throws Exception {

        LdapContext ctx =
                mock(LdapContext.class);

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        when(enumeration.hasMore())
                .thenReturn(false);

        when(ctx.search(
                anyString(),
                anyString(),
                any(SearchControls.class)))
                .thenReturn(enumeration);

        Control unrelatedControl =
                mock(Control.class);

        when(ctx.getResponseControls())
                .thenReturn(
                        new Control[]{unrelatedControl});

        Method method =
                ActiveDirectoryDiscoveryService.class
                        .getDeclaredMethod(
                                "searchPrintQueues",
                                LdapContext.class,
                                String.class,
                                String.class);

        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<PrinterMetadata> result =
                (List<PrinterMetadata>) method.invoke(
                        service,
                        ctx,
                        "DC=test,DC=com",
                        "STORE01");

        assertTrue(result.isEmpty());

        verify(enumeration).close();
    }

}