package com.costco.replatform.foundation.printrouter.util;

import org.junit.jupiter.api.Test;

import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.URI;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.PasswordAuthentication;
import java.net.URL;

import static org.junit.jupiter.api.Assertions.*;

class PrinterEndpointPolicyTest {

    // ============================================================
    // printerUri()
    // ============================================================

    @Test
    void printerUri_validAddress_returnsUri() {

        URI result =
                PrinterEndpointPolicy.printerUri(
                        "10.10.10.10");

        assertEquals(
                "http://10.10.10.10",
                result.toString());
    }

    @Test
    void printerUri_nullAddress_throwsException() {

        IllegalArgumentException exception =
                assertThrows(
                        IllegalArgumentException.class,
                        () -> PrinterEndpointPolicy.printerUri(null));

        assertEquals(
                "Printer address must be an IPv4 literal",
                exception.getMessage());
    }

    @Test
    void printerUri_nonIpAddress_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.printerUri(
                        "printer.example.com"));
    }

    @Test
    void printerUri_ipv6Address_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.printerUri(
                        "::1"));
    }

    @Test
    void printerUri_octetGreaterThan255_throwsException() {

        IllegalArgumentException exception =
                assertThrows(
                        IllegalArgumentException.class,
                        () -> PrinterEndpointPolicy.printerUri(
                                "256.10.10.10"));

        assertEquals(
                "Invalid printer IPv4 address",
                exception.getMessage());
    }

    @Test
    void printerUri_loopbackAddress_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.printerUri(
                        "127.0.0.1"));
    }

    @Test
    void printerUri_anyLocalAddress_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.printerUri(
                        "0.0.0.0"));
    }



    @Test
    void printerUri_linkLocalAddress_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.printerUri(
                        "169.254.1.1"));
    }

    @Test
    void printerUri_multicastAddress_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.printerUri(
                        "224.0.0.1"));
    }

    @Test
    void effectivePort_returnsDefaultHttpPort()
            throws Exception {

        Method method =
                PrinterEndpointPolicy.class
                        .getDeclaredMethod(
                                "effectivePort",
                                URI.class);

        method.setAccessible(true);

        int result =
                (Integer) method.invoke(
                        null,
                        URI.create("http://example.com"));

        assertEquals(80, result);
    }

    @Test
    void effectivePort_returnsDefaultHttpsPort()
            throws Exception {

        Method method =
                PrinterEndpointPolicy.class
                        .getDeclaredMethod(
                                "effectivePort",
                                URI.class);

        method.setAccessible(true);

        int result =
                (Integer) method.invoke(
                        null,
                        URI.create("https://example.com"));

        assertEquals(443, result);
    }

    @Test
    void effectivePort_returnsExplicitPort()
            throws Exception {

        Method method =
                PrinterEndpointPolicy.class
                        .getDeclaredMethod(
                                "effectivePort",
                                URI.class);

        method.setAccessible(true);

        int result =
                (Integer) method.invoke(
                        null,
                        URI.create("http://example.com:631"));

        assertEquals(631, result);
    }

    @Test
    void isHttp_coversSupportedAndUnsupportedSchemes()
            throws Exception {

        Method method =
                PrinterEndpointPolicy.class
                        .getDeclaredMethod(
                                "isHttp",
                                URI.class);

        method.setAccessible(true);

        assertEquals(
                true,
                method.invoke(
                        null,
                        URI.create("http://example.com")));

        assertEquals(
                true,
                method.invoke(
                        null,
                        URI.create("https://example.com")));

        assertEquals(
                false,
                method.invoke(
                        null,
                        URI.create("ftp://example.com")));
    }

    @Test
    void authenticator_matchingServerRequest_returnsCredentials()
            throws Exception {

        Authenticator authenticator =
                PrinterEndpointPolicy.authenticator(
                        URI.create("http://example.com"),
                        "test-user",
                        "test-password");

        PasswordAuthentication authentication =
                Authenticator.requestPasswordAuthentication(
                        "example.com",
                        null,
                        80,
                        "http",
                        "Basic Authentication",
                        "Basic",
                        new URL("http://example.com"),
                        Authenticator.RequestorType.SERVER);

        /*
         * The static requestPasswordAuthentication method uses
         * the default Authenticator, so install our policy
         * authenticator temporarily.
         */
    }

    @Test
    void authenticator_wrongHost_returnsNull()
            throws Exception {

        Authenticator authenticator =
                PrinterEndpointPolicy.authenticator(
                        URI.create("http://example.com"),
                        "user",
                        "password");

        Authenticator.setDefault(authenticator);

        try {

            PasswordAuthentication authentication =
                    Authenticator.requestPasswordAuthentication(
                            "other.example.com",
                            null,
                            80,
                            "http",
                            "Basic",
                            "Basic",
                            new URL("http://other.example.com"),
                            Authenticator.RequestorType.SERVER);

            assertNull(authentication);

        } finally {
            Authenticator.setDefault(null);
        }
    }

    @Test
    void authenticator_wrongScheme_returnsNull()
            throws Exception {

        Authenticator authenticator =
                PrinterEndpointPolicy.authenticator(
                        URI.create("https://example.com"),
                        "user",
                        "password");

        Authenticator.setDefault(authenticator);

        try {

            PasswordAuthentication authentication =
                    Authenticator.requestPasswordAuthentication(
                            "example.com",
                            null,
                            80,
                            "http",
                            "Basic",
                            "Basic",
                            new URL("http://example.com"),
                            Authenticator.RequestorType.SERVER);

            assertNull(authentication);

        } finally {
            Authenticator.setDefault(null);
        }
    }

    @Test
    void authenticator_wrongPort_returnsNull()
            throws Exception {

        Authenticator authenticator =
                PrinterEndpointPolicy.authenticator(
                        URI.create("http://example.com:631"),
                        "user",
                        "password");

        Authenticator.setDefault(authenticator);

        try {

            PasswordAuthentication authentication =
                    Authenticator.requestPasswordAuthentication(
                            "example.com",
                            null,
                            80,
                            "http",
                            "Basic",
                            "Basic",
                            new URL("http://example.com:80"),
                            Authenticator.RequestorType.SERVER);

            assertNull(authentication);

        } finally {
            Authenticator.setDefault(null);
        }
    }

    @Test
    void authenticator_proxyRequest_returnsNull()
            throws Exception {

        Authenticator authenticator =
                PrinterEndpointPolicy.authenticator(
                        URI.create("http://example.com"),
                        "user",
                        "password");

        Authenticator.setDefault(authenticator);

        try {

            PasswordAuthentication authentication =
                    Authenticator.requestPasswordAuthentication(
                            "example.com",
                            null,
                            80,
                            "http",
                            "Basic",
                            "Basic",
                            new URL("http://example.com"),
                            Authenticator.RequestorType.PROXY);

            assertNull(authentication);

        } finally {
            Authenticator.setDefault(null);
        }
    }



    @Test
    void printerUri_reservedAddress_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.printerUri(
                        "240.0.0.1"));
    }

    // ============================================================
    // discoveryUri() valid origins
    // ============================================================

    @Test
    void discoveryUri_validHttpOrigin_returnsUri() {

        URI result =
                PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/printers/Laser1",
                        "printserver.example.com");

        assertEquals(
                "http://printserver.example.com/printers/Laser1",
                result.toString());
    }

    @Test
    void discoveryUri_validHttpsOrigin_returnsUri() {

        URI result =
                PrinterEndpointPolicy.discoveryUri(
                        "https://printserver.example.com",
                        "/printers/Laser1",
                        "printserver.example.com");

        assertEquals(
                "https://printserver.example.com/printers/Laser1",
                result.toString());
    }

    @Test
    void discoveryUri_allowedHostComparison_isCaseInsensitive() {

        URI result =
                PrinterEndpointPolicy.discoveryUri(
                        "https://PrintServer.Example.com",
                        "/printers/Laser1",
                        "other.example.com, printserver.example.com");

        assertNotNull(result);
    }

    @Test
    void discoveryUri_allowedPort80_returnsUri() {

        URI result =
                PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com:80",
                        "/printers/Laser1",
                        "printserver.example.com");

        assertNotNull(result);
    }

    @Test
    void discoveryUri_allowedPort443_returnsUri() {

        URI result =
                PrinterEndpointPolicy.discoveryUri(
                        "https://printserver.example.com:443",
                        "/printers/Laser1",
                        "printserver.example.com");

        assertNotNull(result);
    }

    @Test
    void discoveryUri_port631_isAllowed() {

        URI result =
                PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com:631",
                        "/printers/Laser1",
                        "printserver.example.com");

        assertNotNull(result);
    }

    // ============================================================
    // discoveryUri() invalid origins
    // ============================================================

    @Test
    void discoveryUri_nonHttpProtocol_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "ftp://printserver.example.com",
                        "/printers/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_missingHost_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http:///printers",
                        "/printers/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_userInfo_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://user:pass@printserver.example.com",
                        "/printers/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_query_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com?x=1",
                        "/printers/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_fragment_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com#fragment",
                        "/printers/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_existingBasePath_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com/test",
                        "/printers/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_disallowedPort_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com:8080",
                        "/printers/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_missingAllowedHosts_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/printers/Laser1",
                        null));
    }

    @Test
    void discoveryUri_hostNotApproved_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/printers/Laser1",
                        "other.example.com"));
    }

    // ============================================================
    // discoveryUri() invalid paths
    // ============================================================

    @Test
    void discoveryUri_wrongPathPrefix_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/queues/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_absolutePrinterPath_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "http://evil.example.com/printers/Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_pathWithQuery_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/printers/Laser1?x=1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_pathWithFragment_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/printers/Laser1#test",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_doubleSlashInPath_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/printers//Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_dotSegment_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/printers/./Laser1",
                        "printserver.example.com"));
    }

    @Test
    void discoveryUri_parentSegment_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.discoveryUri(
                        "http://printserver.example.com",
                        "/printers/../Laser1",
                        "printserver.example.com"));
    }

    // ============================================================
    // openDiscoveryConnection()
    // ============================================================

    @Test
    void openDiscoveryConnection_returnsConfiguredConnection()
            throws Exception {

        HttpURLConnection connection =
                PrinterEndpointPolicy.openDiscoveryConnection(
                        "http://example.com",
                        "/printers/Laser1",
                        "example.com",
                        "user",
                        "password");

        assertNotNull(connection);

        assertFalse(
                connection.getInstanceFollowRedirects());

        assertEquals(
                "http://example.com/printers/Laser1",
                connection.getURL().toString());

        connection.disconnect();
    }

    @Test
    void openDiscoveryConnection_invalidHost_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrinterEndpointPolicy.openDiscoveryConnection(
                        "http://example.com",
                        "/printers/Laser1",
                        "different.example.com",
                        "user",
                        "password"));
    }

    // ============================================================
    // authenticator()
    // ============================================================

    @Test
    void authenticator_returnsAuthenticator() {

        Authenticator authenticator =
                PrinterEndpointPolicy.authenticator(
                        URI.create("http://example.com"),
                        "user",
                        "password");

        assertNotNull(authenticator);
    }

    @Test
    void authenticator_https_returnsAuthenticator() {

        Authenticator authenticator =
                PrinterEndpointPolicy.authenticator(
                        URI.create("https://example.com"),
                        "secure-user",
                        "secure-password");

        assertNotNull(authenticator);
    }

    @Test
    void authenticator_customPort_returnsAuthenticator() {

        Authenticator authenticator =
                PrinterEndpointPolicy.authenticator(
                        URI.create("http://example.com:631"),
                        "user",
                        "password");

        assertNotNull(authenticator);
    }
}