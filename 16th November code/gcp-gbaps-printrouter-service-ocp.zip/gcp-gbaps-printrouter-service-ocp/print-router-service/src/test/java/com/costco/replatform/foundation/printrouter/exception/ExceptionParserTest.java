package com.costco.replatform.foundation.printrouter.exception;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.NamingException;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeoutException;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ExceptionParserTest {

    // ============================================================
    // getHttpStatus()
    // ============================================================

    @Test
    void getHttpStatus_null_returnsInternalServerError() {

        assertEquals(
                HttpStatus.INTERNAL_SERVER_ERROR,
                ExceptionParser.getHttpStatus(null));
    }

    @Test
    void getHttpStatus_illegalArgument_returnsBadRequest() {

        assertEquals(
                HttpStatus.BAD_REQUEST,
                ExceptionParser.getHttpStatus(
                        new IllegalArgumentException()));
    }

    @Test
    void getHttpStatus_numberFormat_returnsBadRequest() {

        assertEquals(
                HttpStatus.BAD_REQUEST,
                ExceptionParser.getHttpStatus(
                        new NumberFormatException()));
    }

    @Test
    void getHttpStatus_authentication_returnsUnauthorized()
            throws Exception {

        assertEquals(
                HttpStatus.UNAUTHORIZED,
                ExceptionParser.getHttpStatus(
                        new AuthenticationException()));
    }

    @Test
    void getHttpStatus_security_returnsForbidden() {

        assertEquals(
                HttpStatus.FORBIDDEN,
                ExceptionParser.getHttpStatus(
                        new SecurityException()));
    }

    @Test
    void getHttpStatus_sslHandshake_returnsBadGateway() {

        assertEquals(
                HttpStatus.BAD_GATEWAY,
                ExceptionParser.getHttpStatus(
                        new SSLHandshakeException("SSL")));
    }

    @Test
    void getHttpStatus_sslException_returnsBadGateway() {

        assertEquals(
                HttpStatus.BAD_GATEWAY,
                ExceptionParser.getHttpStatus(
                        new SSLException("SSL")));
    }

    @Test
    void getHttpStatus_certificate_returnsBadGateway() {

        assertEquals(
                HttpStatus.BAD_GATEWAY,
                ExceptionParser.getHttpStatus(
                        new CertificateException()));
    }

    @Test
    void getHttpStatus_connectException_returnsServiceUnavailable() {

        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                ExceptionParser.getHttpStatus(
                        new ConnectException()));
    }

    @Test
    void getHttpStatus_socketException_returnsServiceUnavailable() {

        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                ExceptionParser.getHttpStatus(
                        new SocketException()));
    }

    @Test
    void getHttpStatus_communicationException_returnsServiceUnavailable()
            throws Exception {

        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                ExceptionParser.getHttpStatus(
                        new CommunicationException()));
    }

    @Test
    void getHttpStatus_namingException_returnsServiceUnavailable()
            throws Exception {

        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                ExceptionParser.getHttpStatus(
                        new NamingException()));
    }

    @Test
    void getHttpStatus_socketTimeout_returnsGatewayTimeout() {

        assertEquals(
                HttpStatus.GATEWAY_TIMEOUT,
                ExceptionParser.getHttpStatus(
                        new SocketTimeoutException()));
    }

    @Test
    void getHttpStatus_timeoutException_returnsGatewayTimeout() {

        assertEquals(
                HttpStatus.GATEWAY_TIMEOUT,
                ExceptionParser.getHttpStatus(
                        new TimeoutException()));
    }

    @Test
    void getHttpStatus_httpBadRequest_returnsBadRequest() {

        HttpClientErrorException exception =
                HttpClientErrorException.create(
                        HttpStatus.BAD_REQUEST,
                        "Bad Request",
                        null,
                        null,
                        null);

        assertEquals(
                HttpStatus.BAD_REQUEST,
                ExceptionParser.getHttpStatus(exception));
    }

    @Test
    void getHttpStatus_httpNotFound_returnsNotFound() {

        HttpClientErrorException exception =
                HttpClientErrorException.create(
                        HttpStatus.NOT_FOUND,
                        "Not Found",
                        null,
                        null,
                        null);

        assertEquals(
                HttpStatus.NOT_FOUND,
                ExceptionParser.getHttpStatus(exception));
    }

    @Test
    void getHttpStatus_httpUnauthorized_returnsUnauthorized() {

        HttpClientErrorException exception =
                HttpClientErrorException.create(
                        HttpStatus.UNAUTHORIZED,
                        "Unauthorized",
                        null,
                        null,
                        null);

        assertEquals(
                HttpStatus.UNAUTHORIZED,
                ExceptionParser.getHttpStatus(exception));
    }

    @Test
    void getHttpStatus_httpServerError_returnsBadGateway() {

        HttpServerErrorException exception =
                HttpServerErrorException.create(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Server Error",
                        null,
                        null,
                        null);

        assertEquals(
                HttpStatus.BAD_GATEWAY,
                ExceptionParser.getHttpStatus(exception));
    }

    @Test
    void getHttpStatus_resourceAccess_returnsServiceUnavailable() {

        ResourceAccessException exception =
                new ResourceAccessException(
                        "Connection unavailable");

        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                ExceptionParser.getHttpStatus(exception));
    }

    @Test
    void getHttpStatus_jsonParse_returnsBadRequest() {

        JsonParseException exception =
                new JsonParseException(
                        null,
                        "Invalid JSON");

        assertEquals(
                HttpStatus.BAD_REQUEST,
                ExceptionParser.getHttpStatus(exception));
    }

    @Test
    void getHttpStatus_jsonMapping_returnsBadRequest() {

        JsonMappingException exception =
                new JsonMappingException(
                        null,
                        "Invalid JSON mapping");

        assertEquals(
                HttpStatus.BAD_REQUEST,
                ExceptionParser.getHttpStatus(exception));
    }

    @Test
    void getHttpStatus_unsupportedOperation_returnsNotImplemented() {

        assertEquals(
                HttpStatus.NOT_IMPLEMENTED,
                ExceptionParser.getHttpStatus(
                        new UnsupportedOperationException()));
    }

    @Test
    void getHttpStatus_unknown_returnsInternalServerError() {

        assertEquals(
                HttpStatus.INTERNAL_SERVER_ERROR,
                ExceptionParser.getHttpStatus(
                        new RuntimeException()));
    }

    // ============================================================
    // getErrorCode()
    // ============================================================

    @Test
    void getErrorCode_null_returnsInternalServerError() {

        assertEquals(
                ErrorCode.INTERNAL_SERVER_ERROR,
                ExceptionParser.getErrorCode(null));
    }

    @Test
    void getErrorCode_illegalArgument() {

        assertEquals(
                ErrorCode.ILLEGAL_ARGUMENT,
                ExceptionParser.getErrorCode(
                        new IllegalArgumentException()));
    }

    @Test
    void getErrorCode_connectException() {

        assertEquals(
                ErrorCode.PRINTER_UNREACHABLE,
                ExceptionParser.getErrorCode(
                        new ConnectException()));
    }

    @Test
    void getErrorCode_socketTimeout() {

        assertEquals(
                ErrorCode.CONNECTION_TIMEOUT,
                ExceptionParser.getErrorCode(
                        new SocketTimeoutException()));
    }

    @Test
    void getErrorCode_socketException() {

        assertEquals(
                ErrorCode.SERVICE_UNAVAILABLE,
                ExceptionParser.getErrorCode(
                        new SocketException()));
    }

    @Test
    void getErrorCode_sslHandshake() {

        assertEquals(
                ErrorCode.SSL_HANDSHAKE_FAILED,
                ExceptionParser.getErrorCode(
                        new SSLHandshakeException("SSL")));
    }

    @Test
    void getErrorCode_certificateException() {

        assertEquals(
                ErrorCode.CERTIFICATE_VALIDATION_FAILED,
                ExceptionParser.getErrorCode(
                        new CertificateException()));
    }

    @Test
    void getErrorCode_sslException() {

        assertEquals(
                ErrorCode.SSL_HANDSHAKE_FAILED,
                ExceptionParser.getErrorCode(
                        new SSLException("SSL")));
    }

    @Test
    void getErrorCode_ldapAuthentication()
            throws Exception {

        assertEquals(
                ErrorCode.LDAP_AUTHENTICATION_FAILED,
                ExceptionParser.getErrorCode(
                        new AuthenticationException()));
    }

    @Test
    void getErrorCode_ldapCommunication()
            throws Exception {

        assertEquals(
                ErrorCode.LDAP_CONNECTION_FAILED,
                ExceptionParser.getErrorCode(
                        new CommunicationException()));
    }

    @Test
    void getErrorCode_namingException()
            throws Exception {

        assertEquals(
                ErrorCode.LDAP_CONNECTION_FAILED,
                ExceptionParser.getErrorCode(
                        new NamingException()));
    }

    @Test
    void getErrorCode_httpClientError() {

        HttpClientErrorException exception =
                HttpClientErrorException.create(
                        HttpStatus.BAD_REQUEST,
                        "Bad Request",
                        null,
                        null,
                        null);

        assertEquals(
                ErrorCode.INVALID_REQUEST,
                ExceptionParser.getErrorCode(exception));
    }

    @Test
    void getErrorCode_httpServerError() {

        HttpServerErrorException exception =
                HttpServerErrorException.create(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Server Error",
                        null,
                        null,
                        null);

        assertEquals(
                ErrorCode.DOWNSTREAM_SERVICE_FAILURE,
                ExceptionParser.getErrorCode(exception));
    }

    @Test
    void getErrorCode_resourceAccess() {

        assertEquals(
                ErrorCode.SERVICE_UNAVAILABLE,
                ExceptionParser.getErrorCode(
                        new ResourceAccessException(
                                "Connection failed")));
    }

    @Test
    void getErrorCode_jsonParse() {

        JsonParseException exception =
                new JsonParseException(
                        null,
                        "Invalid JSON");

        assertEquals(
                ErrorCode.INVALID_INPUT_FORMAT,
                ExceptionParser.getErrorCode(exception));
    }

    @Test
    void getErrorCode_jsonMapping() {

        JsonMappingException exception =
                new JsonMappingException(
                        null,
                        "Invalid mapping");

        assertEquals(
                ErrorCode.INVALID_INPUT_FORMAT,
                ExceptionParser.getErrorCode(exception));
    }

    @Test
    void getErrorCode_unknown_returnsInternalServerError() {

        assertEquals(
                ErrorCode.INTERNAL_SERVER_ERROR,
                ExceptionParser.getErrorCode(
                        new RuntimeException()));
    }
}