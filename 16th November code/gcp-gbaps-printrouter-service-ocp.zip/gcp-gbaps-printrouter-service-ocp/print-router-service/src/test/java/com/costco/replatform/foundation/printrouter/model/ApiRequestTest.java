package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ApiRequestTest {

    @Test
    void constructor_initializesFieldsToNull() {

        ApiRequest<String> request =
                new ApiRequest<>();

        assertNull(request.getRequest());
        assertNull(request.getRequestId());
        assertNull(request.getSource());
        assertNull(request.getTimestamp());
    }

    @Test
    void gettersAndSettersWork() {

        ApiRequest<String> request =
                new ApiRequest<>();

        request.setRequest("PRINT_REQUEST");
        request.setRequestId("REQ-1001");
        request.setSource("OCP");
        request.setTimestamp("2026-11-18T18:00:00");

        assertEquals(
                "PRINT_REQUEST",
                request.getRequest());

        assertEquals(
                "REQ-1001",
                request.getRequestId());

        assertEquals(
                "OCP",
                request.getSource());

        assertEquals(
                "2026-11-18T18:00:00",
                request.getTimestamp());
    }

    @Test
    void genericRequestSupportsComplexObject() {

        PrintRouteRequest printRouteRequest =
                new PrintRouteRequest();

        ApiRequest<PrintRouteRequest> request =
                new ApiRequest<>();

        request.setRequest(printRouteRequest);

        assertSame(
                printRouteRequest,
                request.getRequest());
    }
}