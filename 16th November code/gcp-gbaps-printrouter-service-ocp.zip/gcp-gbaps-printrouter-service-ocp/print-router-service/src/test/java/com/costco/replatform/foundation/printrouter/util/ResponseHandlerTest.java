package com.costco.replatform.foundation.printrouter.util;

import com.costco.replatform.foundation.printrouter.model.PrinterIppResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

class ResponseHandlerTest {

    private ResponseHandler responseHandler;

    @BeforeEach
    void setUp() {
        responseHandler = new ResponseHandler();
    }

    // ============================================================
    // resolveHttpStatus
    // ============================================================

    @Test
    void resolveHttpStatus_positiveStatus_returnsSameStatus() {

        assertEquals(
                400,
                responseHandler.resolveHttpStatus(400));

        assertEquals(
                404,
                responseHandler.resolveHttpStatus(404));

        assertEquals(
                500,
                responseHandler.resolveHttpStatus(500));
    }

    @Test
    void resolveHttpStatus_zero_returns500() {

        assertEquals(
                500,
                responseHandler.resolveHttpStatus(0));
    }

    @Test
    void resolveHttpStatus_negative_returns500() {

        assertEquals(
                500,
                responseHandler.resolveHttpStatus(-1));
    }

    // ============================================================
    // buildErrorResponse
    // ============================================================

    @Test
    void buildErrorResponse_buildsExpectedResponse() {

        PrinterIppResponse response =
                responseHandler.buildErrorResponse(
                        "TRACK-1001",
                        400,
                        "Bad request");

        assertNotNull(response);
        assertFalse(response.isOk());
        assertEquals(400, response.getStatus());
        assertEquals(
                "Bad request",
                response.getMessage());
    }

    @Test
    void buildErrorResponse_serverError() {

        PrinterIppResponse response =
                responseHandler.buildErrorResponse(
                        "TRACK-1002",
                        500,
                        "Internal error");

        assertNotNull(response);
        assertFalse(response.isOk());
        assertEquals(500, response.getStatus());
        assertEquals(
                "Internal error",
                response.getMessage());
    }

    // ============================================================
    // buildServiceErrorResponse
    // ============================================================

    @Test
    void buildServiceErrorResponse_nullResponse_returns500() {

        PrinterIppResponse response =
                responseHandler.buildServiceErrorResponse(
                        "TRACK-1001",
                        null);

        assertNotNull(response);
        assertFalse(response.isOk());

        assertEquals(
                500,
                response.getStatus());

        assertEquals(
                "Internal server error while processing vendor creation",
                response.getMessage());
    }

    @Test
    void buildServiceErrorResponse_preservesServiceStatusAndMessage() {

        PrinterIppResponse serviceResponse =
                new PrinterIppResponse();

        serviceResponse.setOk(false);
        serviceResponse.setStatus(404);
        serviceResponse.setMessage(
                "Printer not found");

        PrinterIppResponse response =
                responseHandler.buildServiceErrorResponse(
                        "TRACK-1002",
                        serviceResponse);

        assertNotNull(response);
        assertFalse(response.isOk());

        assertEquals(
                404,
                response.getStatus());

        assertEquals(
                "Printer not found",
                response.getMessage());
    }

    @Test
    void buildServiceErrorResponse_nullMessage_usesFallback() {

        PrinterIppResponse serviceResponse =
                new PrinterIppResponse();

        serviceResponse.setOk(false);
        serviceResponse.setStatus(503);
        serviceResponse.setMessage(null);

        PrinterIppResponse response =
                responseHandler.buildServiceErrorResponse(
                        "TRACK-1003",
                        serviceResponse);

        assertNotNull(response);
        assertFalse(response.isOk());

        assertEquals(
                503,
                response.getStatus());

        assertEquals(
                "Service error occurred during vendor creation",
                response.getMessage());
    }

    @Test
    void buildServiceErrorResponse_zeroStatus_fallsBackTo500() {

        PrinterIppResponse serviceResponse =
                new PrinterIppResponse();

        serviceResponse.setStatus(0);
        serviceResponse.setMessage(
                "Service failed");

        PrinterIppResponse response =
                responseHandler.buildServiceErrorResponse(
                        "TRACK-1004",
                        serviceResponse);

        assertNotNull(response);

        assertEquals(
                500,
                response.getStatus());

        assertEquals(
                "Service failed",
                response.getMessage());
    }

    // ============================================================
    // Private buildSuccessResponse
    // ============================================================

    @Test
    void buildSuccessResponse_buildsSuccessfulResponse()
            throws Exception {

        Method method =
                ResponseHandler.class
                        .getDeclaredMethod(
                                "buildSuccessResponse",
                                String.class,
                                int.class,
                                String.class);

        method.setAccessible(true);

        PrinterIppResponse response =
                (PrinterIppResponse) method.invoke(
                        responseHandler,
                        "TRACK-1005",
                        200,
                        "Success");

        assertNotNull(response);

        assertTrue(response.isOk());

        assertEquals(
                200,
                response.getStatus());

        assertEquals(
                "Success",
                response.getMessage());
    }
}