package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrinterDiscoveryResponseTest {

    @Test
    void constructor_initializesFieldsToNull() {

        PrinterDiscoveryResponse response =
                new PrinterDiscoveryResponse();

        assertNull(response.getMessage());
        assertNull(response.getStatus());
        assertNull(response.getUrl());
        assertNull(response.getHttpStatus());
        assertNull(response.getErrorType());
    }

    @Test
    void gettersAndSettersWork() {

        PrinterDiscoveryResponse response =
                new PrinterDiscoveryResponse();

        response.setMessage("Printer discovered successfully");
        response.setStatus("SUCCESS");
        response.setUrl("http://10.10.10.10");
        response.setHttpStatus(200);
        response.setErrorType("NONE");

        assertEquals(
                "Printer discovered successfully",
                response.getMessage());

        assertEquals(
                "SUCCESS",
                response.getStatus());

        assertEquals(
                "http://10.10.10.10",
                response.getUrl());

        assertEquals(
                200,
                response.getHttpStatus());

        assertEquals(
                "NONE",
                response.getErrorType());
    }
}