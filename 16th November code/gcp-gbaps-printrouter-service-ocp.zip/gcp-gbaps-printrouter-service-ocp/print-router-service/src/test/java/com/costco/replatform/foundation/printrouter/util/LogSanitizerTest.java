package com.costco.replatform.foundation.printrouter.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LogSanitizerTest {

    @Test
    void sanitize_normalText_returnsSameText() {

        assertEquals(
                "HELLO",
                LogSanitizer.sanitize("HELLO"));
    }

    @Test
    void sanitize_controlCharacter_replacesCharacter() {

        String result =
                LogSanitizer.sanitize("ABC\nDEF");

        assertTrue(result.contains("\\u000a"));
    }

    @Test
    void mask_null_returnsMaskedValue() {

        assertEquals(
                "****",
                LogSanitizer.mask(null));
    }

    @Test
    void mask_empty_returnsMaskedValue() {

        assertEquals(
                "****",
                LogSanitizer.mask(""));
    }

    @Test
    void mask_shortValue_masksEverything() {

        assertEquals(
                "***",
                LogSanitizer.mask("abc"));
    }

    @Test
    void mask_longValue_masksFirstFourCharacters() {

        assertEquals(
                "****efgh",
                LogSanitizer.mask("abcdefgh"));
    }
}