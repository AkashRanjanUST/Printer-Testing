package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ApiResponseTest {

    @Test
    void ok_createsSuccessResponse() {

        ApiResponse<String> response =
                ApiResponse.ok("SUCCESS");

        assertTrue(response.isSuccess());
        assertEquals("SUCCESS", response.getResponse());
        assertEquals(
                "The request has been processed",
                response.getMessage());
    }

    @Test
    void init_createsInitializedResponse() {

        ApiResponse<String> response =
                ApiResponse.init("DATA");

        assertTrue(response.isSuccess());
        assertEquals("DATA", response.getResponse());
        assertEquals(
                "The request has been initiated.",
                response.getMessage());
    }

    @Test
    void okWithCustomMessage_createsSuccessResponse() {

        ApiResponse<String> response =
                ApiResponse.ok("DATA", "CUSTOM");

        assertTrue(response.isSuccess());
        assertEquals("DATA", response.getResponse());
        assertEquals("CUSTOM", response.getMessage());
    }

    @Test
    void error_createsFailureResponse() {

        ApiResponse<String> response =
                ApiResponse.error("FAILED");

        assertFalse(response.isSuccess());
        assertNull(response.getResponse());
        assertEquals("FAILED", response.getMessage());
    }

    @Test
    void failures_createsFailureResponseWithErrorData() {

        ApiResponse<String> response =
                ApiResponse.failures(
                        "PRT_001",
                        "Failure",
                        400);

        assertFalse(response.isSuccess());
        assertNull(response.getResponse());
        assertEquals("PRT_001", response.getErrorCode());
        assertEquals("400", response.getErrorStatus());
        assertEquals("Failure", response.getMessage());
    }

    @Test
    void settersAndGettersWork() {

        ApiResponse<String> response =
                new ApiResponse<>(
                        true,
                        "ABC",
                        "MESSAGE");

        response.setSuccess(false);
        response.setResponse("XYZ");
        response.setMessage("UPDATED");
        response.setErrorCode("PRT_999");
        response.setErrorStatus("500");

        assertFalse(response.isSuccess());
        assertEquals("XYZ", response.getResponse());
        assertEquals("UPDATED", response.getMessage());
        assertEquals("PRT_999", response.getErrorCode());
        assertEquals("500", response.getErrorStatus());
    }

    @Test
    void toStringReturnsNonNullValue() {

        ApiResponse<String> response =
                ApiResponse.ok("DATA");

        assertNotNull(response.toString());
        assertFalse(response.toString().isBlank());
    }
}