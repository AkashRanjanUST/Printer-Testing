package com.costco.replatform.foundation.printrouter.common.enums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintDiscoveryStatusTest {

    @Test
    void values_containsAllExpectedStatuses() {

        PrintDiscoveryStatus[] values =
                PrintDiscoveryStatus.values();

        assertEquals(5, values.length);

        assertArrayEquals(
                new PrintDiscoveryStatus[]{
                        PrintDiscoveryStatus.SUCCESS,
                        PrintDiscoveryStatus.FAILED,
                        PrintDiscoveryStatus.NOT_FOUND,
                        PrintDiscoveryStatus.CONNECTION_ERROR,
                        PrintDiscoveryStatus.AUTHENTICATION_FAILED
                },
                values);
    }

    @Test
    void valueOf_returnsExpectedStatuses() {

        assertEquals(
                PrintDiscoveryStatus.SUCCESS,
                PrintDiscoveryStatus.valueOf("SUCCESS"));

        assertEquals(
                PrintDiscoveryStatus.FAILED,
                PrintDiscoveryStatus.valueOf("FAILED"));

        assertEquals(
                PrintDiscoveryStatus.NOT_FOUND,
                PrintDiscoveryStatus.valueOf("NOT_FOUND"));

        assertEquals(
                PrintDiscoveryStatus.CONNECTION_ERROR,
                PrintDiscoveryStatus.valueOf("CONNECTION_ERROR"));

        assertEquals(
                PrintDiscoveryStatus.AUTHENTICATION_FAILED,
                PrintDiscoveryStatus.valueOf(
                        "AUTHENTICATION_FAILED"));
    }

    @Test
    void valueOf_invalidStatus_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrintDiscoveryStatus.valueOf("INVALID"));
    }
}