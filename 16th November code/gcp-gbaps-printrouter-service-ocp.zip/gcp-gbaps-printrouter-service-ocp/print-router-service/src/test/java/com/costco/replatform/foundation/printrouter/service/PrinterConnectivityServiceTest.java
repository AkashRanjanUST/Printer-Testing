package com.costco.replatform.foundation.printrouter.service;

import com.costco.replatform.foundation.printrouter.config.PrinterIppProperties;
import com.costco.replatform.foundation.printrouter.exception.PrintRouteException;
import com.costco.replatform.foundation.printrouter.exception.PrintRouteInvalidArgumentException;
import com.costco.replatform.foundation.printrouter.model.PrinterIppResponse;
import com.costco.replatform.foundation.printrouter.exception.PrintRouteException;
import com.costco.replatform.foundation.printrouter.model.PrintStatusResponse;
import com.costco.replatform.foundation.printrouter.model.PrintRouteResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import java.net.http.HttpClient;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;

import java.lang.reflect.Method;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.net.http.HttpClient;

import org.springframework.test.util.ReflectionTestUtils;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.costco.replatform.foundation.printrouter.model.ActiveDirectoryDiscoveryResponse;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;
import com.costco.replatform.foundation.printrouter.exception.PrintStatusCheckException;

import java.util.Collections;

class PrinterConnectivityServiceTest {

    private PrinterConnectivityService service;

    private ActiveDirectoryDiscoveryService discoveryService;


    @BeforeEach
    void setUp() {

        PrinterIppProperties properties = validProperties();

        discoveryService =
                mock(ActiveDirectoryDiscoveryService.class);

        service =
                new PrinterConnectivityService(
                        properties,
                        discoveryService);
    }

    // ============================================================
    // IPP status mapping
    // ============================================================

    @Test
    void getIppStatusDescription_allStatuses() throws Exception {

        Method method =
                privateMethod(
                        "getIppStatusDescription",
                        int.class);

        assertEquals(
                "successful-ok",
                method.invoke(service, 0x0000));

        assertEquals(
                "successful-ok-ignored-or-substituted-attributes",
                method.invoke(service, 0x0001));

        assertEquals(
                "successful-ok-conflicting-attributes",
                method.invoke(service, 0x0002));

        assertEquals(
                "client-error-bad-request",
                method.invoke(service, 0x0400));

        assertEquals(
                "client-error-forbidden",
                method.invoke(service, 0x0401));

        assertEquals(
                "client-error-not-authenticated",
                method.invoke(service, 0x0402));

        assertEquals(
                "client-error-not-authorized",
                method.invoke(service, 0x0403));

        assertEquals(
                "client-error-not-possible",
                method.invoke(service, 0x0404));

        assertEquals(
                "client-error-not-found",
                method.invoke(service, 0x0406));

        assertEquals(
                "client-error-document-format-not-supported",
                method.invoke(service, 0x040A));

        assertEquals(
                "server-error-internal-error",
                method.invoke(service, 0x0500));

        assertEquals(
                "server-error-operation-not-supported",
                method.invoke(service, 0x0501));

        assertEquals(
                "server-error-service-unavailable",
                method.invoke(service, 0x0502));

        assertEquals(
                "server-error-version-not-supported",
                method.invoke(service, 0x0503));

        assertEquals(
                "unknown-ipp-status-0x1234",
                method.invoke(service, 0x1234));
    }

    // ============================================================
    // Job state mapping
    // ============================================================

    @Test
    void getJobStateDescription_allStates() throws Exception {

        Method method =
                privateMethod(
                        "getJobStateDescription",
                        Integer.class);

        assertNull(
                method.invoke(
                        service,
                        (Object) null));

        assertEquals(
                "PENDING",
                method.invoke(service, 3));

        assertEquals(
                "PENDING_HELD",
                method.invoke(service, 4));

        assertEquals(
                "PROCESSING",
                method.invoke(service, 5));

        assertEquals(
                "STOPPED",
                method.invoke(service, 6));

        assertEquals(
                "CANCELED",
                method.invoke(service, 7));

        assertEquals(
                "ABORTED",
                method.invoke(service, 8));

        assertEquals(
                "COMPLETED",
                method.invoke(service, 9));

        assertEquals(
                "UNKNOWN(99)",
                method.invoke(service, 99));
    }

    // ============================================================
    // Document bytes
    // ============================================================

    @Test
    void getDocumentBytes_pdf() throws Exception {

        Method method =
                privateMethod(
                        "getDocumentBytes",
                        String.class,
                        String.class);

        byte[] result =
                (byte[]) method.invoke(
                        service,
                        "PDF",
                        "TEST");

        assertArrayEquals(
                "TEST".getBytes(StandardCharsets.ISO_8859_1),
                result);
    }

    @Test
    void getDocumentBytes_zpl() throws Exception {

        Method method =
                privateMethod(
                        "getDocumentBytes",
                        String.class,
                        String.class);

        byte[] result =
                (byte[]) method.invoke(
                        service,
                        "ZPL",
                        "^XA^XZ");

        assertArrayEquals(
                "^XA^XZ".getBytes(StandardCharsets.UTF_8),
                result);
    }

    @Test
    void getDocumentBytes_other_usesUtf8() throws Exception {

        Method method =
                privateMethod(
                        "getDocumentBytes",
                        String.class,
                        String.class);

        byte[] result =
                (byte[]) method.invoke(
                        service,
                        "TEXT",
                        "HELLO");

        assertArrayEquals(
                "HELLO".getBytes(StandardCharsets.UTF_8),
                result);
    }

    // ============================================================
    // PrinterIppResponse creation
    // ============================================================

    @Test
    void buildPrinterResponse_populatesFields() throws Exception {

        Method method =
                privateMethod(
                        "buildPrinterResponse",
                        int.class,
                        Integer.class,
                        int.class,
                        String.class,
                        boolean.class,
                        Integer.class);

        PrinterIppResponse response =
                (PrinterIppResponse) method.invoke(
                        service,
                        200,
                        0,
                        123,
                        "SUCCESS",
                        true,
                        100);

        assertTrue(response.isOk());
        assertEquals(200, response.getStatus());
        assertEquals("SUCCESS", response.getMessage());
        assertEquals(100, response.getPrintJobId());
    }

    // ============================================================
    // Failure status mapping
    // ============================================================

    @Test
    void getFailureHttpStatus_returns4xxStatus() throws Exception {

        Method method =
                privateMethod(
                        "getFailureHttpStatus",
                        PrinterIppResponse.class);

        PrinterIppResponse response =
                new PrinterIppResponse();

        response.setStatus(404);

        assertEquals(
                404,
                method.invoke(service, response));
    }

    @Test
    void getFailureHttpStatus_returns5xxStatus() throws Exception {

        Method method =
                privateMethod(
                        "getFailureHttpStatus",
                        PrinterIppResponse.class);

        PrinterIppResponse response =
                new PrinterIppResponse();

        response.setStatus(503);

        assertEquals(
                503,
                method.invoke(service, response));
    }

    @Test
    void getFailureHttpStatus_nonFailureStatus_returns502()
            throws Exception {

        Method method =
                privateMethod(
                        "getFailureHttpStatus",
                        PrinterIppResponse.class);

        PrinterIppResponse response =
                new PrinterIppResponse();



        response.setStatus(200);

        assertEquals(
                502,
                method.invoke(service, response));
    }

    // ============================================================
    // validateInput
    // ============================================================

    @Test
    void validateInput_validConfiguration() throws Exception {

        PrinterConnectivityService svc =
                new PrinterConnectivityService(
                        validProperties(),
                        mock(ActiveDirectoryDiscoveryService.class));

        Method method =
                privateMethod("validateInput");

        assertDoesNotThrow(
                () -> method.invoke(svc));
    }

    @Test
    void validateInput_missingRequestingUser() throws Exception {

        PrinterIppProperties properties = validProperties();
        properties.setRequestingUser(null);

        assertValidationFailure(
                properties,
                "Requesting user must not be empty");
    }

    @Test
    void validateInput_blankRequestingUser() throws Exception {

        PrinterIppProperties properties = validProperties();
        properties.setRequestingUser("   ");

        assertValidationFailure(
                properties,
                "Requesting user must not be empty");
    }

    @Test
    void validateInput_missingJobName() throws Exception {

        PrinterIppProperties properties = validProperties();
        properties.setJobName(null);

        assertValidationFailure(
                properties,
                "Job name must not be empty");
    }

    @Test
    void validateInput_missingPrintContent() throws Exception {

        PrinterIppProperties properties = validProperties();
        properties.setPrintContent(null);

        assertValidationFailure(
                properties,
                "Print content must not be empty");
    }

    @Test
    void validateInput_zeroConnectTimeout() throws Exception {

        PrinterIppProperties properties = validProperties();
        properties.setConnectTimeoutSeconds(0);

        assertValidationFailure(
                properties,
                "Connect timeout must be greater than zero");
    }

    @Test
    void validateInput_negativeConnectTimeout() throws Exception {

        PrinterIppProperties properties = validProperties();
        properties.setConnectTimeoutSeconds(-1);

        assertValidationFailure(
                properties,
                "Connect timeout must be greater than zero");
    }

    @Test
    void validateInput_zeroRequestTimeout() throws Exception {

        PrinterIppProperties properties = validProperties();
        properties.setRequestTimeoutSeconds(0);

        assertValidationFailure(
                properties,
                "Request timeout must be greater than zero");
    }

    // ============================================================
    // HTTP request builder
    // ============================================================

    @Test
    void buildHttpRequest_setsExpectedFields() throws Exception {

        Method method =
                privateMethod(
                        "buildHttpRequest",
                        byte[].class,
                        String.class);

        HttpRequest request =
                (HttpRequest) method.invoke(
                        service,
                        new byte[]{1, 2, 3},
                        "10.10.10.10");

        assertEquals(
                "http://10.10.10.10",
                request.uri().toString());

        assertEquals(
                "POST",
                request.method());

        assertEquals(
                "application/ipp",
                request.headers()
                        .firstValue("Content-Type")
                        .orElseThrow());

        assertEquals(
                "application/ipp",
                request.headers()
                        .firstValue("Accept")
                        .orElseThrow());

        assertEquals(
                Duration.ofSeconds(30),
                request.timeout().orElseThrow());
    }

    // ============================================================
    // IPP request creation
    // ============================================================

    @Test
    void buildIppPrintRequest_createsPrintJobRequest()
            throws Exception {

        Method method =
                privateMethod(
                        "buildIppPrintRequest",
                        int.class,
                        String.class,
                        String.class,
                        String.class,
                        String.class,
                        String.class,
                        int.class);

        byte[] result =
                (byte[]) method.invoke(
                        service,
                        123,
                        "Laser1",
                        "label.pdf",
                        "PDF",
                        "CONTENT",
                        "10.10.10.10",
                        2);

        assertNotNull(result);
        assertTrue(result.length > 8);

        assertEquals(
                (byte) 0x01,
                result[0]);

        assertEquals(
                (byte) 0x01,
                result[1]);

        int operationId =
                ((result[2] & 0xFF) << 8)
                        | (result[3] & 0xFF);

        assertEquals(
                0x0002,
                operationId);
    }

    @Test
    void buildIppStatusRequest_createsGetJobAttributesRequest()
            throws Exception {

        Method method =
                privateMethod(
                        "buildIppPrintJobStatusRequest",
                        int.class,
                        String.class,
                        int.class,
                        String.class);

        byte[] result =
                (byte[]) method.invoke(
                        service,
                        123,
                        "Laser1",
                        456,
                        "10.10.10.10");

        assertNotNull(result);

        int operationId =
                ((result[2] & 0xFF) << 8)
                        | (result[3] & 0xFF);

        assertEquals(
                0x0009,
                operationId);
    }

    // ============================================================
    // Job ID extraction
    // ============================================================

    @Test
    void extractJobId_returnsValue() throws Exception {

        Method method =
                privateMethod(
                        "extractJobId",
                        byte[].class);

        byte[] response = {
                0x01, 0x01, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x01,

                0x21,
                0x00, 0x06,
                'j', 'o', 'b', '-', 'i', 'd',
                0x00, 0x04,
                0x00, 0x00, 0x00, 0x7B,

                0x03
        };

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) response);

        assertEquals(123, result);
    }

    @Test
    void extractJobId_missing_returnsNull() throws Exception {

        Method method =
                privateMethod(
                        "extractJobId",
                        byte[].class);

        byte[] response = {
                0x01, 0x01, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x01,
                0x03
        };

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) response);

        assertNull(result);
    }

    // ============================================================
    // Print-request job state extraction
    // ============================================================

    @Test
    void extractJobStateOfPrintRequest_returnsCompleted()
            throws Exception {

        Method method =
                privateMethod(
                        "extractJobStateOfPrintRequest",
                        byte[].class);

        byte[] response = {
                0, 0, 0, 0, 0,
                0, 0, 0, 0, 0,

                0x23,
                0x00, 0x09,
                'j', 'o', 'b', '-',
                's', 't', 'a', 't', 'e',

                0x00, 0x04,
                0x00, 0x00, 0x00, 0x09,

                0, 0, 0, 0
        };

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) response);

        assertEquals(9, result);
    }

    @Test
    void extractJobStateOfPrintRequest_missing_returnsNull()
            throws Exception {

        Method method =
                privateMethod(
                        "extractJobStateOfPrintRequest",
                        byte[].class);

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) new byte[30]);

        assertNull(result);
    }

    // ============================================================
    // Status-request job state extraction
    // ============================================================

    @Test
    void extractJobStateOfJobStatusRequest_missing_returnsNull()
            throws Exception {

        Method method =
                privateMethod(
                        "extractJobStateOfJobStatusRequest",
                        byte[].class);

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) "NO STATE"
                                .getBytes(StandardCharsets.ISO_8859_1));

        assertNull(result);
    }

    // ============================================================
    // processResponse
    // ============================================================

    @Test
    void processResponse_401Unauthorized() throws Exception {

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> response =
                mock(HttpResponse.class);

        when(response.statusCode())
                .thenReturn(401);

        when(response.body())
                .thenReturn(new byte[0]);

        HttpHeaders headers =
                HttpHeaders.of(
                        Map.of(
                                "WWW-Authenticate",
                                List.of("Basic")),
                        (a, b) -> true);

        when(response.headers())
                .thenReturn(headers);

        PrinterIppResponse result =
                invokeProcessResponse(
                        response,
                        123,
                        "PRINT_REQUEST");

        assertFalse(result.isOk());
        assertEquals(401, result.getStatus());

        assertTrue(
                result.getMessage()
                        .contains("authentication failed"));
    }

    @Test
    void processResponse_403Forbidden() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        403,
                        new byte[0],
                        123,
                        "PRINT_REQUEST");

        assertFalse(result.isOk());

        assertTrue(
                result.getMessage()
                        .contains("not authorized"));
    }

    @Test
    void processResponse_404NotFound() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        404,
                        new byte[0],
                        123,
                        "PRINT_REQUEST");

        assertFalse(result.isOk());

        assertTrue(
                result.getMessage()
                        .contains("not found"));
    }

    @Test
    void processResponse_http500() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        500,
                        new byte[8],
                        123,
                        "PRINT_REQUEST");

        assertFalse(result.isOk());

        assertTrue(
                result.getMessage()
                        .contains("status 500"));
    }

    @Test
    void processResponse_invalidBody() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        200,
                        new byte[0],
                        123,
                        "PRINT_REQUEST");

        assertFalse(result.isOk());

        assertTrue(
                result.getMessage()
                        .contains("not a valid IPP response"));
    }

    @Test
    void processResponse_nullBody() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        200,
                        null,
                        123,
                        "PRINT_REQUEST");

        assertFalse(result.isOk());

        assertTrue(
                result.getMessage()
                        .contains("not a valid IPP response"));
    }

    @Test
    void processResponse_requestIdMismatch() throws Exception {

        byte[] response = {
                0x01, 0x01,
                0x00, 0x00,
                0x00, 0x00, 0x03, (byte) 0xE7
        };

        PrinterIppResponse result =
                processResponse(
                        200,
                        response,
                        123,
                        "PRINT_REQUEST");

        assertFalse(result.isOk());

        assertTrue(
                result.getMessage()
                        .contains("request ID mismatch"));
    }

    @Test
    void processResponse_successfulPrintResponse()
            throws Exception {

        PrinterIppResponse result =
                processResponse(
                        200,
                        ippResponse(123, 0x0000),
                        123,
                        "PRINT_REQUEST");

        assertTrue(result.isOk());
        assertEquals(200, result.getStatus());

        assertTrue(
                result.getMessage()
                        .contains("Print job accepted"));
    }

    @Test
    void processResponse_successfulStatusResponse()
            throws Exception {

        PrinterIppResponse result =
                processResponse(
                        200,
                        ippResponse(123, 0x0000),
                        123,
                        "STATUS_REQUEST");

        assertTrue(result.isOk());
        assertEquals(200, result.getStatus());
    }

    @Test
    void approvedPrinterIp_returnsMatchingIp()
            throws Exception {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        ActiveDirectoryDiscoveryService discoveryService =
                mock(ActiveDirectoryDiscoveryService.class);

        PrinterConnectivityService service =
                new PrinterConnectivityService(
                        validProperties(),
                        discoveryService);

        discoveryResponse.setPrinterList(
                List.of(printer));

        when(discoveryService.discoverPrintersByLocation(null))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        Method method =
                privateMethod(
                        "approvedPrinterIp",
                        String.class,
                        String.class);

        String result =
                (String) method.invoke(
                        service,
                        "PRINTER1",
                        "10.10.10.10");

        assertEquals(
                "10.10.10.10",
                result);
    }

    @Test
    void approvedPrinterIp_inventoryUnavailable()
            throws Exception {

        ActiveDirectoryDiscoveryService discoveryService =
                mock(ActiveDirectoryDiscoveryService.class);

        PrinterConnectivityService service =
                new PrinterConnectivityService(
                        validProperties(),
                        discoveryService);

        when(discoveryService.discoverPrintersByLocation(null))
                .thenReturn(null);

        Method method =
                privateMethod(
                        "approvedPrinterIp",
                        String.class,
                        String.class);

        Exception exception =
                assertThrows(
                        Exception.class,
                        () -> method.invoke(
                                service,
                                "PRINTER1",
                                "10.10.10.10"));

        assertTrue(
                exception.getCause()
                        instanceof PrintStatusCheckException);
    }

    @Test
    void approvedPrinterIp_printerNotFound()
            throws Exception {

        ActiveDirectoryDiscoveryResponse response =
                new ActiveDirectoryDiscoveryResponse();

        ActiveDirectoryDiscoveryService discoveryService =
                mock(ActiveDirectoryDiscoveryService.class);

        PrinterConnectivityService service =
                new PrinterConnectivityService(
                        validProperties(),
                        discoveryService);

        response.setPrinterList(
                Collections.emptyList());

        when(discoveryService.discoverPrintersByLocation(null))
                .thenReturn(
                        ApiResponse.ok(response));

        Method method =
                privateMethod(
                        "approvedPrinterIp",
                        String.class,
                        String.class);

        Exception exception =
                assertThrows(
                        Exception.class,
                        () -> method.invoke(
                                service,
                                "PRINTER1",
                                "10.10.10.10"));

        assertTrue(
                exception.getCause()
                        instanceof IllegalArgumentException);
    }

    @Test
    void approvedPrinterIp_invalidIp()
            throws Exception {

        Method method =
                privateMethod(
                        "approvedPrinterIp",
                        String.class,
                        String.class);

        assertThrows(
                Exception.class,
                () -> method.invoke(
                        service,
                        "PRINTER1",
                        "INVALID-IP"));
    }

    @Test
    void extractJobStateOfJobStatusRequest_completed()
            throws Exception {

        Method method =
                privateMethod(
                        "extractJobStateOfJobStatusRequest",
                        byte[].class);

        byte[] response =
                ("job-state"
                        + "\0\0\0"
                        + (char) 0x04
                        + "\0\0\0\t")
                        .getBytes(
                                StandardCharsets.ISO_8859_1);

        Integer result =
                (Integer) method.invoke(
                        service,
                        (Object) response);

        assertEquals(
                9,
                result);
    }

    @Test
    void doPrint_invalidPrinterIp_throwsException() {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress(null);

        List<PrinterMetadata> printers =
                List.of(printer);

        assertThrows(
                PrintRouteInvalidArgumentException.class,
                () -> service.doPrint(
                        1,
                        "doc",
                        "PDF",
                        "track",
                        "content",
                        printers,
                        1));
    }
    @Test
    void doStatusCheck_inventoryUnavailable() {

        ActiveDirectoryDiscoveryService discoveryService =
                mock(ActiveDirectoryDiscoveryService.class);

        PrinterConnectivityService service =
                new PrinterConnectivityService(
                        validProperties(),
                        discoveryService);

        when(discoveryService.discoverPrintersByLocation(null))
                .thenReturn(null);

        assertThrows(
                PrintStatusCheckException.class,
                () -> service.doStatusCheck(
                        1,
                        "PRINTER1",
                        100,
                        "10.10.10.10"));
    }

    @Test
    void doStatusCheck_printerNotApproved() {

        ActiveDirectoryDiscoveryResponse response =
                new ActiveDirectoryDiscoveryResponse();

        response.setPrinterList(
                List.of());

        ActiveDirectoryDiscoveryService discoveryService =
                mock(ActiveDirectoryDiscoveryService.class);

        PrinterConnectivityService service =
                new PrinterConnectivityService(
                        validProperties(),
                        discoveryService);

        when(discoveryService.discoverPrintersByLocation(null))
                .thenReturn(
                        ApiResponse.ok(response));

        assertThrows(
                IllegalArgumentException.class,
                () -> service.doStatusCheck(
                        1,
                        "PRINTER1",
                        100,
                        "10.10.10.10"));
    }

    @Test
    void doPrint_emptyPrinterList() {

        ApiResponse<?> response =
                service.doPrint(
                        1,
                        "DOC",
                        "PDF",
                        "TRACK",
                        "CONTENT",
                        List.of(),
                        1);

        assertNotNull(response);
    }

    @Test
    void doStatusCheck_invalidIp() {

        assertThrows(
                Exception.class,
                () -> service.doStatusCheck(
                        1,
                        "PRINTER1",
                        100,
                        "INVALID-IP"));
    }

    @Test
    void httpClient_plainCredentials_returnsClient() throws Exception {

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "test-user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "test-password");

        Method method =
                privateMethod(
                        "httpClient",
                        URI.class);

        HttpClient client =
                (HttpClient) method.invoke(
                        service,
                        URI.create("http://10.10.10.10"));

        assertNotNull(client);

        client.close();
    }

    @Test
    void httpClient_encodedCredentials_returnsClient() throws Exception {

        PrinterIppProperties properties =
                validProperties();

        properties.setCredEncoded(true);

        PrinterConnectivityService svc =
                new PrinterConnectivityService(
                        properties,
                        discoveryService);

        ReflectionTestUtils.setField(
                svc,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                svc,
                "printerAuthUserName",
                "dGVzdC11c2Vy");

        ReflectionTestUtils.setField(
                svc,
                "printerAuthPassword",
                "dGVzdC1wYXNzd29yZA==");

        Method method =
                privateMethod(
                        "httpClient",
                        URI.class);

        HttpClient client =
                (HttpClient) method.invoke(
                        svc,
                        URI.create("http://10.10.10.10"));

        assertNotNull(client);

        client.close();
    }

    @Test
    void doPrint_emptyPrinterIp_throwsException() {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("");

        assertThrows(
                PrintRouteInvalidArgumentException.class,
                () -> service.doPrint(
                        1,
                        "doc",
                        "PDF",
                        "track",
                        "content",
                        List.of(printer),
                        1));
    }

    @Test
    void doPrint_emptyLiteralPrinterIp_throwsException() {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("EMPTY");

        assertThrows(
                PrintRouteInvalidArgumentException.class,
                () -> service.doPrint(
                        1,
                        "doc",
                        "PDF",
                        "track",
                        "content",
                        List.of(printer),
                        1));
    }

    @Test
    void doPrint_emptyPrinterList_returnsInitializedResponse() {

        ApiResponse<?> result =
                service.doPrint(
                        1,
                        "doc",
                        "PDF",
                        "track",
                        "content",
                        List.of(),
                        1);

        assertNotNull(result);
        assertTrue(result.isSuccess());
    }

    @Test
    void doPrint_nullPrinterEntry_returnsInitializedResponse() {

        List<PrinterMetadata> printers =
                new java.util.ArrayList<>();

        printers.add(null);

        ApiResponse<?> result =
                service.doPrint(
                        1,
                        "doc",
                        "PDF",
                        "track",
                        "content",
                        printers,
                        1);

        assertNotNull(result);
    }

    @Test
    void sendPrintRequest_success() throws Exception {

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        HttpHeaders headers =
                HttpHeaders.of(
                        Map.of(
                                "Content-Type",
                                List.of("application/ipp"),
                                "Server",
                                List.of("Test-Printer")),
                        (name, value) -> true);

        when(httpResponse.headers())
                .thenReturn(headers);

        when(httpResponse.statusCode())
                .thenReturn(200);

        when(httpResponse.headers())
                .thenReturn(headers);

        /*
         * Valid minimal IPP response:
         * version   = 1.1
         * status    = successful-ok
         * requestId = 123
         */
        when(httpResponse.body())
                .thenReturn(
                        ippResponse(
                                123,
                                0x0000));

        HttpClient client =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(client);

        when(client.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "password");

        try (MockedStatic<HttpClient> mocked =
                     mockStatic(HttpClient.class)) {

            mocked.when(HttpClient::newBuilder)
                    .thenReturn(builder);

            Method method =
                    privateMethod(
                            "sendPrintRequest",
                            int.class,
                            String.class,
                            String.class,
                            String.class,
                            String.class,
                            String.class,
                            int.class);

            @SuppressWarnings("unchecked")
            ApiResponse<PrinterIppResponse> result =
                    (ApiResponse<PrinterIppResponse>)
                            method.invoke(
                                    service,
                                    123,
                                    "PRINTER1",
                                    "test.pdf",
                                    "PDF",
                                    "CONTENT",
                                    "10.10.10.10",
                                    1);

            assertNotNull(result);
            assertTrue(result.isSuccess());

            assertNotNull(
                    result.getResponse());

            assertEquals(
                    200,
                    result.getResponse().getStatus());
        }
    }
    @Test
    void sendPrintRequest_http401_returnsFailure()
            throws Exception {

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        HttpHeaders headers =
                HttpHeaders.of(
                        Map.of(),
                        (a, b) -> true);

        when(httpResponse.statusCode())
                .thenReturn(401);

        when(httpResponse.headers())
                .thenReturn(headers);

        when(httpResponse.body())
                .thenReturn(
                        "Unauthorized"
                                .getBytes(StandardCharsets.UTF_8));

        HttpClient client =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(client);

        when(client.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "password");

        try (MockedStatic<HttpClient> mocked =
                     mockStatic(HttpClient.class)) {

            mocked.when(HttpClient::newBuilder)
                    .thenReturn(builder);

            Method method =
                    privateMethod(
                            "sendPrintRequest",
                            int.class,
                            String.class,
                            String.class,
                            String.class,
                            String.class,
                            String.class,
                            int.class);

            @SuppressWarnings("unchecked")
            ApiResponse<PrinterIppResponse> result =
                    (ApiResponse<PrinterIppResponse>)
                            method.invoke(
                                    service,
                                    123,
                                    "PRINTER1",
                                    "test.pdf",
                                    "PDF",
                                    "CONTENT",
                                    "10.10.10.10",
                                    1);

            assertNotNull(result);
            assertFalse(result.isSuccess());
            assertEquals("401", result.getErrorStatus());
        }
    }

    @Test
    void doStatusCheck_invalidIp_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> service.doStatusCheck(
                        1,
                        "PRINTER1",
                        100,
                        "INVALID-IP"));
    }

    @Test
    void doStatusCheck_nullPrinterName_throwsIllegalArgumentException() {

        PrinterMetadata printer = new PrinterMetadata();
        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");

        ActiveDirectoryDiscoveryResponse response =
                new ActiveDirectoryDiscoveryResponse();

        response.setPrinterList(List.of(printer));

        when(discoveryService.discoverPrintersByLocation(null))
                .thenReturn(ApiResponse.ok(response));

        assertThrows(
                IllegalArgumentException.class,
                () -> service.doStatusCheck(
                        1,
                        null,
                        100,
                        "10.10.10.10"));
    }

    @Test
    void sendPrintJobStatusRequest_success() throws Exception {

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(200);

        when(httpResponse.body())
                .thenReturn(
                        ippResponse(
                                123,
                                0x0000));

        HttpClient client =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(client);

        when(client.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "password");

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            Method method =
                    privateMethod(
                            "sendPrintJobStatusRequest",
                            int.class,
                            String.class,
                            int.class,
                            String.class);

            @SuppressWarnings("unchecked")
            ApiResponse<PrinterIppResponse> result =
                    (ApiResponse<PrinterIppResponse>)
                            method.invoke(
                                    service,
                                    123,
                                    "PRINTER1",
                                    500,
                                    "10.10.10.10");

            assertNotNull(result);
            assertTrue(result.isSuccess());

            assertNotNull(result.getResponse());

            assertEquals(
                    200,
                    result.getResponse().getStatus());
        }
    }

    @Test
    void doPrint_failedPrinterResponse_throwsPrintRouteException()
            throws Exception {

        PrinterMetadata printer = new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(500);

        when(httpResponse.headers())
                .thenReturn(
                        HttpHeaders.of(
                                Map.of(),
                                (a, b) -> true));

        when(httpResponse.body())
                .thenReturn(new byte[0]);

        HttpClient client =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(client);

        when(client.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "password");

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            assertThrows(
                    PrintRouteException.class,
                    () -> service.doPrint(
                            123,
                            "test.pdf",
                            "PDF",
                            "TRACK-123",
                            "CONTENT",
                            List.of(printer),
                            1));
        }
    }



    @Test
    void doPrint_success_returnsPrintRouteResponse()
            throws Exception {

        PrinterMetadata printer = new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");
        printer.setLocation("STORE01");

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(200);

        when(httpResponse.headers())
                .thenReturn(
                        HttpHeaders.of(
                                Map.of(),
                                (a, b) -> true));

        when(httpResponse.body())
                .thenReturn(
                        ippResponse(
                                123,
                                0x0000));

        HttpClient client =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(client);

        when(client.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "password");

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            ApiResponse<PrintRouteResponse> result =
                    service.doPrint(
                            123,
                            "test.pdf",
                            "PDF",
                            "TRACK-123",
                            "CONTENT",
                            List.of(printer),
                            1);

            assertNotNull(result);
            assertTrue(result.isSuccess());
            assertNotNull(result.getResponse());

            assertEquals(
                    "PRINTER1",
                    result.getResponse().getPrinterName());

            assertEquals(
                    "10.10.10.10",
                    result.getResponse().getPrinterIp());

            assertEquals(
                    "STORE01",
                    result.getResponse().getLocationId());
        }
    }

    @Test
    void sendPrintJobStatusRequest_failureResponse()
            throws Exception {

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(404);

        when(httpResponse.body())
                .thenReturn(new byte[0]);

        HttpClient client =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(client);

        when(client.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "password");

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            Method method =
                    privateMethod(
                            "sendPrintJobStatusRequest",
                            int.class,
                            String.class,
                            int.class,
                            String.class);

            @SuppressWarnings("unchecked")
            ApiResponse<PrinterIppResponse> result =
                    (ApiResponse<PrinterIppResponse>)
                            method.invoke(
                                    service,
                                    123,
                                    "PRINTER1",
                                    500,
                                    "10.10.10.10");

            assertNotNull(result);
            assertFalse(result.isSuccess());

            assertEquals(
                    "404",
                    result.getErrorStatus());
        }
    }
    private static byte[] ippStatusResponse(
            int requestId,
            int jobState) {

        byte[] name =
                "job-state"
                        .getBytes(StandardCharsets.ISO_8859_1);

        byte[] response =
                new byte[8 + name.length + 8];

        /*
         * IPP header
         */

        response[0] = 0x01;
        response[1] = 0x01;

        // successful-ok
        response[2] = 0x00;
        response[3] = 0x00;

        response[4] =
                (byte) ((requestId >> 24) & 0xFF);

        response[5] =
                (byte) ((requestId >> 16) & 0xFF);

        response[6] =
                (byte) ((requestId >> 8) & 0xFF);

        response[7] =
                (byte) (requestId & 0xFF);

        /*
         * Put "job-state" into response.
         */

        System.arraycopy(
                name,
                0,
                response,
                8,
                name.length);

        /*
         * extractJobStateOfJobStatusRequest() searches
         * for byte 0x04 after "job-state".
         */

        int index =
                8 + name.length;

        response[index] = 0x04;

        response[index + 1] =
                (byte) ((jobState >> 24) & 0xFF);

        response[index + 2] =
                (byte) ((jobState >> 16) & 0xFF);

        response[index + 3] =
                (byte) ((jobState >> 8) & 0xFF);

        response[index + 4] =
                (byte) (jobState & 0xFF);

        return response;
    }
    @Test
    void doStatusCheck_success_returnsPrintStatus()
            throws Exception {

        // -----------------------------
        // Approved printer inventory
        // -----------------------------

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of(printer));

        when(discoveryService.discoverPrintersByLocation(null))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        // -----------------------------
        // Mock printer HTTP response
        // -----------------------------

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> httpResponse =
                mock(HttpResponse.class);

        when(httpResponse.statusCode())
                .thenReturn(200);

        when(httpResponse.body())
                .thenReturn(
                        ippStatusResponse(
                                123,
                                9));

        // -----------------------------
        // Mock HttpClient
        // -----------------------------

        HttpClient client =
                mock(HttpClient.class);

        HttpClient.Builder builder =
                mock(HttpClient.Builder.class);

        when(builder.followRedirects(any()))
                .thenReturn(builder);

        when(builder.connectTimeout(any()))
                .thenReturn(builder);

        when(builder.authenticator(any()))
                .thenReturn(builder);

        when(builder.build())
                .thenReturn(client);

        when(client.send(
                any(HttpRequest.class),
                any(HttpResponse.BodyHandler.class)))
                .thenReturn(httpResponse);

        // -----------------------------
        // Authentication fields
        // -----------------------------

        ReflectionTestUtils.setField(
                service,
                "domainName",
                "TEST");

        ReflectionTestUtils.setField(
                service,
                "printerAuthUserName",
                "user");

        ReflectionTestUtils.setField(
                service,
                "printerAuthPassword",
                "password");

        // -----------------------------
        // Execute
        // -----------------------------

        try (MockedStatic<HttpClient> mockedHttpClient =
                     mockStatic(HttpClient.class)) {

            mockedHttpClient
                    .when(HttpClient::newBuilder)
                    .thenReturn(builder);

            ApiResponse<PrintStatusResponse> result =
                    service.doStatusCheck(
                            123,
                            "PRINTER1",
                            500,
                            "10.10.10.10");

            // -----------------------------
            // Assertions
            // -----------------------------

            assertNotNull(result);

            assertTrue(result.isSuccess());

            assertNotNull(
                    result.getResponse());

            assertEquals(
                    "PRINTER1",
                    result.getResponse().getPrinterName());

            assertEquals(
                    "10.10.10.10",
                    result.getResponse().getPrinterIp());

            assertEquals(
                    500,
                    result.getResponse().getPrintJobId());

            assertEquals(
                    "COMPLETED",
                    result.getResponse().getPrintJobStatus());
        }
    }



    @Test
    void processResponse_ippRejected() throws Exception {

        PrinterIppResponse result =
                processResponse(
                        200,
                        ippResponse(123, 0x0406),
                        123,
                        "PRINT_REQUEST");

        assertFalse(result.isOk());

        assertTrue(
                result.getMessage()
                        .contains("Print job rejected"));
    }

    // ============================================================
    // Test helpers
    // ============================================================

    private PrinterIppProperties validProperties() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setRequestingUser("test-user");
        properties.setJobName("TEST_JOB_");
        properties.setPrintContent("TEST CONTENT");
        properties.setConnectTimeoutSeconds(10);
        properties.setRequestTimeoutSeconds(30);
        properties.setCredEncoded(false);

        return properties;
    }

    private void assertValidationFailure(
            PrinterIppProperties properties,
            String expectedMessage) throws Exception {

        PrinterConnectivityService svc =
                new PrinterConnectivityService(
                        properties,
                        mock(ActiveDirectoryDiscoveryService.class));

        Method method =
                privateMethod("validateInput");

        Exception exception =
                assertThrows(
                        Exception.class,
                        () -> method.invoke(svc));

        assertNotNull(exception.getCause());

        assertEquals(
                expectedMessage,
                exception.getCause().getMessage());
    }

    private Method privateMethod(
            String name,
            Class<?>... parameterTypes)
            throws Exception {

        Method method =
                PrinterConnectivityService.class
                        .getDeclaredMethod(
                                name,
                                parameterTypes);

        method.setAccessible(true);

        return method;
    }

    private PrinterIppResponse processResponse(
            int httpStatus,
            byte[] body,
            int itemNo,
            String requestType) throws Exception {

        @SuppressWarnings("unchecked")
        HttpResponse<byte[]> response =
                mock(HttpResponse.class);

        when(response.statusCode())
                .thenReturn(httpStatus);

        when(response.body())
                .thenReturn(body);

        return invokeProcessResponse(
                response,
                itemNo,
                requestType);
    }

    private PrinterIppResponse invokeProcessResponse(
            HttpResponse<byte[]> response,
            int itemNo,
            String requestType) throws Exception {

        Method method =
                privateMethod(
                        "processResponse",
                        HttpResponse.class,
                        int.class,
                        String.class);

        return (PrinterIppResponse)
                method.invoke(
                        service,
                        response,
                        itemNo,
                        requestType);
    }

    private static byte[] ippResponse(
            int requestId,
            int ippStatus) {

        return new byte[]{
                0x01,
                0x01,
                (byte) ((ippStatus >> 8) & 0xFF),
                (byte) (ippStatus & 0xFF),
                (byte) ((requestId >> 24) & 0xFF),
                (byte) ((requestId >> 16) & 0xFF),
                (byte) ((requestId >> 8) & 0xFF),
                (byte) (requestId & 0xFF)
        };
    }


}