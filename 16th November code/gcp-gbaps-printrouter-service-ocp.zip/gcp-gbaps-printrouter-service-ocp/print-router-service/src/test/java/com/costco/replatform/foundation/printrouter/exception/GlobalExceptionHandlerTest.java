package com.costco.replatform.foundation.printrouter.exception;

import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler handler;
    private MessageSource messageSource;

    @BeforeEach
    void setUp() {

        handler = new GlobalExceptionHandler();

        messageSource =
                mock(MessageSource.class);

        ReflectionTestUtils.setField(
                handler,
                "messageSource",
                messageSource);

        when(messageSource.getMessage(
                anyString(),
                any(),
                any(Locale.class)))
                .thenReturn("Test error message");
    }

    // ============================================================
    // IllegalArgumentException
    // ============================================================

    @Test
    void handleIllegalArgument_returnsBadRequest() {

        ResponseEntity<ApiResponse<Void>> result =
                handler.handlIllegalArgValidxceptions(
                        new IllegalArgumentException(
                                "Invalid argument"));

        assertEquals(
                HttpStatus.BAD_REQUEST,
                result.getStatusCode());

        assertNotNull(result.getBody());

        assertFalse(
                result.getBody().isSuccess());

        assertEquals(
                "400",
                result.getBody().getErrorStatus());

        assertEquals(
                "Test error message",
                result.getBody().getMessage());
    }

    // ============================================================
    // PrintRouteException
    // ============================================================

    @Test
    void handlePrintRouteException_connectFailure_returns503() {

        PrintRouteException exception =
                new PrintRouteException(
                        "Print failed",
                        new ConnectException(
                                "Connection refused"));

        ResponseEntity<ApiResponse<Void>> result =
                handler.handlePrintRoutetException(
                        exception);

        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                result.getStatusCode());

        assertNotNull(result.getBody());

        assertFalse(
                result.getBody().isSuccess());

        assertEquals(
                "503",
                result.getBody().getErrorStatus());

        assertEquals(
                ErrorCode.PRINTER_UNREACHABLE.getCode(),
                result.getBody().getErrorCode());
    }

    @Test
    void handlePrintRouteException_unknownFailure_returns500() {

        PrintRouteException exception =
                new PrintRouteException(
                        "Print failed",
                        new RuntimeException(
                                "Unknown"));

        ResponseEntity<ApiResponse<Void>> result =
                handler.handlePrintRoutetException(
                        exception);

        assertEquals(
                HttpStatus.INTERNAL_SERVER_ERROR,
                result.getStatusCode());

        assertNotNull(result.getBody());
    }

    // ============================================================
    // PrintStatusCheckException
    // ============================================================

    @Test
    void handlePrintStatusCheckException_timeoutReturnsExpectedStatus() {

        PrintStatusCheckException exception =
                new PrintStatusCheckException(
                        "Status check failed",
                        new SocketTimeoutException(
                                "Timeout"));

        ResponseEntity<ApiResponse<Void>> result =
                handler.handlePrintStatusCheckException(
                        exception);

        assertNotNull(result);
        assertNotNull(result.getBody());

        /*
         * With the current ExceptionParser ordering,
         * SocketTimeoutException may be classified through
         * SocketException first.
         *
         * Assert against ExceptionParser directly so this test
         * follows the actual production behavior.
         */
        HttpStatus expected =
                ExceptionParser.getHttpStatus(
                        exception.getCause());

        assertEquals(
                expected,
                result.getStatusCode());

        assertEquals(
                String.valueOf(expected.value()),
                result.getBody().getErrorStatus());
    }

    // ============================================================
    // PrintStatusCheckInvalidResponseException
    // ============================================================

    @Test
    void handlePrintStatusCheckInvalidResponse_returns422() {

        PrintStatusCheckInvalidResponseException exception =
                new PrintStatusCheckInvalidResponseException(
                        "Invalid printer response",
                        new IllegalArgumentException(
                                "Invalid response"));

        ResponseEntity<ApiResponse<Void>> result =
                handler.handlePrintStatusCheckRespInvalidException(
                        exception);

        assertEquals(
                HttpStatus.UNPROCESSABLE_CONTENT,
                result.getStatusCode());

        assertNotNull(result.getBody());

        assertFalse(
                result.getBody().isSuccess());

        assertEquals(
                "422",
                result.getBody().getErrorStatus());

        assertEquals(
                ErrorCode.ILLEGAL_ARGUMENT.getCode(),
                result.getBody().getErrorCode());
    }

    // ============================================================
    // PrintRouteResponseInvalidException
    // ============================================================

    @Test
    void handlePrintRouteResponseInvalid_returns422() {

        PrintRouteResponseInvalidException exception =
                new PrintRouteResponseInvalidException(
                        "Invalid print response",
                        new IllegalArgumentException(
                                "Invalid response"));

        ResponseEntity<ApiResponse<Void>> result =
                handler.handlePrintRouteResponseInvalidException(
                        exception);

        assertEquals(
                HttpStatus.UNPROCESSABLE_CONTENT,
                result.getStatusCode());

        assertNotNull(result.getBody());

        assertFalse(
                result.getBody().isSuccess());

        assertEquals(
                "422",
                result.getBody().getErrorStatus());
    }

    // ============================================================
    // PrintRouteInvalidArgumentException
    // ============================================================

    @Test
    void handlePrintRouteInvalidArgument_returns400() {

        PrintRouteInvalidArgumentException exception =
                new PrintRouteInvalidArgumentException(
                        "Printer IP is invalid",
                        new IllegalArgumentException(
                                "Invalid IP"));

        ResponseEntity<ApiResponse<Void>> result =
                handler.handlePrintRouteInvalidArgumentException(
                        exception);

        assertEquals(
                HttpStatus.BAD_REQUEST,
                result.getStatusCode());

        assertNotNull(result.getBody());

        assertFalse(
                result.getBody().isSuccess());

        assertEquals(
                "400",
                result.getBody().getErrorStatus());

        assertEquals(
                ErrorCode.ILLEGAL_ARGUMENT.getCode(),
                result.getBody().getErrorCode());
    }

    // ============================================================
    // PrinterDiscoveryException
    // ============================================================

    @Test
    void handlePrinterDiscoveryException_connectionFailure_returns503() {

        PrinterDiscoveryException exception =
                new PrinterDiscoveryException(
                        "Discovery failed",
                        new ConnectException(
                                "LDAP unavailable"));

        ResponseEntity<ApiResponse<Void>> result =
                handler.handlePrinterDiscoveryException(
                        exception);

        assertEquals(
                HttpStatus.SERVICE_UNAVAILABLE,
                result.getStatusCode());

        assertNotNull(result.getBody());

        assertEquals(
                "503",
                result.getBody().getErrorStatus());

        assertEquals(
                ErrorCode.PRINTER_UNREACHABLE.getCode(),
                result.getBody().getErrorCode());
    }

    // ============================================================
    // Unhandled Exception
    // ============================================================

    @Test
    void handleUnhandledException_returns500() {

        HttpServletRequest request =
                mock(HttpServletRequest.class);

        when(request.getMethod())
                .thenReturn("POST");

        when(request.getRequestURI())
                .thenReturn("/api/v1/printroute/send");

        ResponseEntity<ApiResponse<Void>> result =
                handler.handleUnhandledException(
                        new RuntimeException(
                                "Unexpected failure"),
                        request);

        assertEquals(
                HttpStatus.INTERNAL_SERVER_ERROR,
                result.getStatusCode());

        assertNotNull(result.getBody());

        assertFalse(
                result.getBody().isSuccess());

        assertEquals(
                "500",
                result.getBody().getErrorStatus());

        assertEquals(
                ErrorCode.INTERNAL_SERVER_ERROR.getCode(),
                result.getBody().getErrorCode());

        assertEquals(
                "Test error message",
                result.getBody().getMessage());
    }

    @Test
    void handleUnhandledException_nullRequest_returns500() {

        ResponseEntity<ApiResponse<Void>> result =
                handler.handleUnhandledException(
                        new RuntimeException(
                                "Unexpected failure"),
                        null);

        assertEquals(
                HttpStatus.INTERNAL_SERVER_ERROR,
                result.getStatusCode());

        assertNotNull(result.getBody());
    }

    // ============================================================
    // MessageSource interaction
    // ============================================================

    @Test
    void illegalArgumentHandler_usesMessageSource() {

        handler.handlIllegalArgValidxceptions(
                new IllegalArgumentException(
                        "Bad input"));

        verify(messageSource).getMessage(
                eq("costco.replatform.printroute.illegalarg.message"),
                any(),
                any(Locale.class));
    }
}