package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class RtLabelPrintDataTest {

    @Test
    void constructor_initializesFieldsToNull() {

        RtLabelPrintData data =
                new RtLabelPrintData();

        assertNull(data.getItemDescription());
        assertNull(data.getItemNumber());
        assertNull(data.getBarcode());
        assertNull(data.getBarcodeLabel());
        assertNull(data.getBarcodeValue());
        assertNull(data.getQuantity());
        assertNull(data.getDepartmentNumber());
        assertNull(data.getVendorNumber());
        assertNull(data.getRtd());
        assertNull(data.getShipLocation());
        assertNull(data.getShipId());
        assertNull(data.getWorkOrder());
        assertNull(data.getWorkOrderBarcode());
        assertNull(data.getWorkOrderBarcodeValue());
    }

    @Test
    void gettersAndSettersWork() {

        RtLabelPrintData data =
                new RtLabelPrintData();

        data.setItemDescription("Test Item");
        data.setItemNumber("ITEM-1001");
        data.setBarcode("BARCODE");
        data.setBarcodeLabel("ITEM BARCODE");
        data.setBarcodeValue("123456789");
        data.setQuantity("10");
        data.setDepartmentNumber("100");
        data.setVendorNumber("VENDOR-001");
        data.setRtd("RTD-001");
        data.setShipLocation("STORE-101");
        data.setShipId("SHIP-1001");
        data.setWorkOrder("WO-1001");
        data.setWorkOrderBarcode("WO-BARCODE");
        data.setWorkOrderBarcodeValue("987654321");

        assertEquals(
                "Test Item",
                data.getItemDescription());

        assertEquals(
                "ITEM-1001",
                data.getItemNumber());

        assertEquals(
                "BARCODE",
                data.getBarcode());

        assertEquals(
                "ITEM BARCODE",
                data.getBarcodeLabel());

        assertEquals(
                "123456789",
                data.getBarcodeValue());

        assertEquals(
                "10",
                data.getQuantity());

        assertEquals(
                "100",
                data.getDepartmentNumber());

        assertEquals(
                "VENDOR-001",
                data.getVendorNumber());

        assertEquals(
                "RTD-001",
                data.getRtd());

        assertEquals(
                "STORE-101",
                data.getShipLocation());

        assertEquals(
                "SHIP-1001",
                data.getShipId());

        assertEquals(
                "WO-1001",
                data.getWorkOrder());

        assertEquals(
                "WO-BARCODE",
                data.getWorkOrderBarcode());

        assertEquals(
                "987654321",
                data.getWorkOrderBarcodeValue());
    }
}