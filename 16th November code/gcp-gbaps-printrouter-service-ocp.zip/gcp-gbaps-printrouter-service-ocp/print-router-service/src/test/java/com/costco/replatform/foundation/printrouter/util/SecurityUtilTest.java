package com.costco.replatform.foundation.printrouter.util;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.*;

class SecurityUtilTest {

    @Test
    void decodeBase64_null_returnsNull() {
        assertNull(SecurityUtil.decodeBase64(null));
    }

    @Test
    void decodeBase64_empty_returnsEmpty() {
        assertEquals("", SecurityUtil.decodeBase64(""));
    }

    @Test
    void decodeBase64_blank_returnsBlank() {
        assertEquals(" ", SecurityUtil.decodeBase64(" "));
    }

    @Test
    void decodeBase64_validValue_decodesSuccessfully() {

        String encoded =
                Base64.getEncoder()
                        .encodeToString(
                                "password123"
                                        .getBytes(StandardCharsets.UTF_8));

        assertEquals(
                "password123",
                SecurityUtil.decodeBase64(encoded));
    }

    @Test
    void decodeBase64_invalidValue_returnsOriginal() {

        String invalid = "%%%INVALID%%%";

        assertEquals(
                invalid,
                SecurityUtil.decodeBase64(invalid));
    }
}