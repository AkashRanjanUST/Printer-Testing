package com.costco.replatform.foundation.printrouter.controller;

import com.costco.replatform.foundation.printrouter.common.enums.DocumentType;
import com.costco.replatform.foundation.printrouter.common.enums.PrintType;
import com.costco.replatform.foundation.printrouter.common.enums.PrinterType;
import com.costco.replatform.foundation.printrouter.model.*;
import com.costco.replatform.foundation.printrouter.service.ActiveDirectoryDiscoveryService;
import com.costco.replatform.foundation.printrouter.service.PrinterConnectivityService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.MediaType;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(
        properties = {
                "app.url.api.name=api"
        })
@AutoConfigureMockMvc
class PrintRouterControllerIT {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper =
            new ObjectMapper();

    @MockitoBean
    private ActiveDirectoryDiscoveryService discoveryService;

    @MockitoBean
    private PrinterConnectivityService printerConnectivityService;

    // ============================================================
    // /send success
    // ============================================================

    @Test
    void routePrint_validRequest_returns200()
            throws Exception {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");
        printer.setLocation("STORE-101");

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of(printer));

        when(discoveryService
                .discoverPrintersByLocation("STORE-101"))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        PrintRouteResponse printResponse =
                new PrintRouteResponse();

        printResponse.setPrinterName("PRINTER1");
        printResponse.setPrinterIp("10.10.10.10");
        printResponse.setLocationId("STORE-101");
        printResponse.setPrintJobId(500);
        printResponse.setPrintStatus("COMPLETED");

        when(printerConnectivityService.doPrint(
                eq(123),
                eq("test.pdf"),
                eq("PDF"),
                eq("TRACK-123"),
                eq("PRINT CONTENT"),
                anyList(),
                eq(2)))
                .thenReturn(
                        ApiResponse.ok(printResponse));

        PrintRouteRequest request =
                new PrintRouteRequest();

        request.setPrintMetadata(
                validPrintMetadata());

        ApiRequest<PrintRouteRequest> apiRequest =
                new ApiRequest<>();

        apiRequest.setRequestId("UI-REQ-123");
        apiRequest.setSource("INTEGRATION-TEST");
        apiRequest.setRequest(request);

        mockMvc.perform(
                        post("/api/v1/printroute/send")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                apiRequest)))
                .andExpect(status().isOk())
                .andExpect(
                        jsonPath("$.success")
                                .value(true))
                .andExpect(
                        jsonPath("$.response.printerName")
                                .value("PRINTER1"))
                .andExpect(
                        jsonPath("$.response.printerIp")
                                .value("10.10.10.10"))
                .andExpect(
                        jsonPath("$.response.locationId")
                                .value("STORE-101"))
                .andExpect(
                        jsonPath("$.response.printJobId")
                                .value(500))
                .andExpect(
                        jsonPath("$.response.printStatus")
                                .value("COMPLETED"));
    }

    // ============================================================
    // /send no printers
    // ============================================================

    @Test
    void routePrint_noPrinters_returns400()
            throws Exception {

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of());

        when(discoveryService
                .discoverPrintersByLocation("STORE-101"))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        PrintRouteRequest request =
                new PrintRouteRequest();

        request.setPrintMetadata(
                validPrintMetadata());

        ApiRequest<PrintRouteRequest> apiRequest =
                new ApiRequest<>();

        apiRequest.setRequest(request);

        mockMvc.perform(
                        post("/api/v1/printroute/send")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                apiRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(
                        jsonPath("$.errorStatus")
                                .value("404"))
                .andExpect(
                        jsonPath("$.message")
                                .value(
                                        "No Printers in requested location"));
    }

    // ============================================================
    // /send malformed JSON
    // ============================================================

    @Test
    void routePrint_invalidJson_returns500()
            throws Exception {

        mockMvc.perform(
                        post("/api/v1/printroute/send")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content("{invalid-json"))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.errorStatus").value("500"))
                .andExpect(jsonPath("$.errorCode").value("PRT_999"))
                .andExpect(
                        jsonPath("$.message")
                                .value("Unexpected Exception occurred."));
    }

    // ============================================================
    // /status success
    // ============================================================

    @Test
    void getPrintStatus_validRequest_returns200()
            throws Exception {

        PrintStatusResponse serviceResponse =
                new PrintStatusResponse();

        serviceResponse.setPrinterName("PRINTER1");
        serviceResponse.setPrinterIp("10.10.10.10");
        serviceResponse.setPrintJobId(500);
        serviceResponse.setPrintJobStatus("COMPLETED");

        when(printerConnectivityService.doStatusCheck(
                123,
                "PRINTER1",
                500,
                "10.10.10.10"))
                .thenReturn(
                        ApiResponse.ok(serviceResponse));

        PrintStatusRequest request =
                new PrintStatusRequest();

        request.setItemNo(123);
        request.setPrinterName("PRINTER1");
        request.setPrinterIp("10.10.10.10");
        request.setPrintJobId(500);

        ApiRequest<PrintStatusRequest> apiRequest =
                new ApiRequest<>();

        apiRequest.setRequestId("STATUS-REQ-123");
        apiRequest.setRequest(request);

        mockMvc.perform(
                        post("/api/v1/printroute/status")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                apiRequest)))
                .andExpect(status().isOk())
                .andExpect(
                        jsonPath("$.success")
                                .value(true))
                .andExpect(
                        jsonPath("$.response.printerName")
                                .value("PRINTER1"))
                .andExpect(
                        jsonPath("$.response.printerIp")
                                .value("10.10.10.10"))
                .andExpect(
                        jsonPath("$.response.printJobId")
                                .value(500))
                .andExpect(
                        jsonPath("$.response.printJobStatus")
                                .value("COMPLETED"));
    }

    // ============================================================
    // GlobalExceptionHandler integration
    // ============================================================

    @Test
    void routePrint_illegalArgument_returns400()
            throws Exception {

        PrinterMetadata printer =
                new PrinterMetadata();

        printer.setPrinterName("PRINTER1");
        printer.setIpAddress("10.10.10.10");

        ActiveDirectoryDiscoveryResponse discoveryResponse =
                new ActiveDirectoryDiscoveryResponse();

        discoveryResponse.setPrinterList(
                List.of(printer));

        when(discoveryService
                .discoverPrintersByLocation("STORE-101"))
                .thenReturn(
                        ApiResponse.ok(discoveryResponse));

        when(printerConnectivityService.doPrint(
                anyInt(),
                anyString(),
                anyString(),
                anyString(),
                anyString(),
                anyList(),
                anyInt()))
                .thenThrow(
                        new IllegalArgumentException(
                                "Invalid printer"));

        PrintRouteRequest request =
                new PrintRouteRequest();

        request.setPrintMetadata(
                validPrintMetadata());

        ApiRequest<PrintRouteRequest> apiRequest =
                new ApiRequest<>();

        apiRequest.setRequest(request);

        mockMvc.perform(
                        post("/api/v1/printroute/send")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                apiRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(
                        jsonPath("$.success")
                                .value(false));
    }

    // ============================================================
    // Helper
    // ============================================================

    private PrintMetadata validPrintMetadata() {

        PrintMetadata metadata =
                new PrintMetadata();

        metadata.setTrackingId("TRACK-123");
        metadata.setRequestTime(
                "2026-11-19T11:30:00");

        metadata.setRequestedUser(
                "integration-user");

        metadata.setDocumentName(
                "test.pdf");

        metadata.setDocumentType(
                DocumentType.PDF);

        metadata.setPrintType(
                PrintType.values()[0]);

        metadata.setPrintPreview(false);

        metadata.setPrinterType(
                PrinterType.values()[0]);

        metadata.setCopies(2);
        metadata.setItemNo(123);

        metadata.setLocationId(
                "STORE-101");

        metadata.setWarehouseId(
                "WAREHOUSE-101");

        metadata.setFilecontent(
                "PRINT CONTENT");

        return metadata;
    }
}