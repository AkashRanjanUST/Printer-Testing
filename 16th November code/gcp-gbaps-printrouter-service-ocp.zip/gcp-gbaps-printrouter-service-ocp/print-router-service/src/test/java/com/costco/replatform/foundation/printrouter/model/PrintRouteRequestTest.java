package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintRouteRequestTest {

    @Test
    void constructor_initializesPrintMetadataToNull() {

        PrintRouteRequest request =
                new PrintRouteRequest();

        assertNull(request.getPrintMetadata());
    }

    @Test
    void setPrintMetadata_andGetPrintMetadata_work() {

        PrintMetadata metadata =
                new PrintMetadata();

        metadata.setItemNo(123);
        metadata.setDocumentName("test.pdf");
        metadata.setLocationId("STORE-101");

        PrintRouteRequest request =
                new PrintRouteRequest();

        request.setPrintMetadata(metadata);

        assertNotNull(request.getPrintMetadata());

        assertSame(
                metadata,
                request.getPrintMetadata());

        assertEquals(
                123,
                request.getPrintMetadata().getItemNo());

        assertEquals(
                "test.pdf",
                request.getPrintMetadata().getDocumentName());

        assertEquals(
                "STORE-101",
                request.getPrintMetadata().getLocationId());
    }
}