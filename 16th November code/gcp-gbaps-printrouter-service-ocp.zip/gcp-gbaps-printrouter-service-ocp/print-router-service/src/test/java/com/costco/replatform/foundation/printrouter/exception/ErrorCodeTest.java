package com.costco.replatform.foundation.printrouter.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ErrorCodeTest {

    @Test
    void invalidRequestCodeIsCorrect() {

        assertEquals(
                "PRT_001",
                ErrorCode.INVALID_REQUEST.getCode());

        assertEquals(
                "The request is invalid.",
                ErrorCode.INVALID_REQUEST.getDescription());
    }

    @Test
    void printerNotFoundCodeIsCorrect() {

        assertEquals(
                "PRT_100",
                ErrorCode.PRINTER_NOT_FOUND.getCode());
    }

    @Test
    void internalServerErrorCodeIsCorrect() {

        assertEquals(
                "PRT_999",
                ErrorCode.INTERNAL_SERVER_ERROR.getCode());
    }

    @Test
    void valuesAndValueOfWork() {

        assertTrue(ErrorCode.values().length > 0);

        ErrorCode errorCode =
                ErrorCode.valueOf("INVALID_REQUEST");

        assertEquals(
                ErrorCode.INVALID_REQUEST,
                errorCode);
    }
}