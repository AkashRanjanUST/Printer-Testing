package com.costco.replatform.foundation.printrouter.model;

import com.costco.replatform.foundation.printrouter.common.enums.DocumentType;
import com.costco.replatform.foundation.printrouter.common.enums.PrintType;
import com.costco.replatform.foundation.printrouter.common.enums.PrinterType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintMetadataTest {

    @Test
    void constructor_initializesFieldsToNull() {

        PrintMetadata metadata =
                new PrintMetadata();

        assertNull(metadata.getTrackingId());
        assertNull(metadata.getRequestTime());
        assertNull(metadata.getRequestedUser());
        assertNull(metadata.getDocumentName());
        assertNull(metadata.getDocumentType());
        assertNull(metadata.getPrintType());
        assertNull(metadata.getPrintPreview());
        assertNull(metadata.getPrinterType());
        assertNull(metadata.getCopies());
        assertNull(metadata.getItemNo());
        assertNull(metadata.getLocationId());
        assertNull(metadata.getWarehouseId());
        assertNull(metadata.getFilecontent());
    }

    @Test
    void gettersAndSettersWork() {

        PrintMetadata metadata =
                new PrintMetadata();

        metadata.setTrackingId("TRACK-1001");
        metadata.setRequestTime("2026-11-18T17:30:00");
        metadata.setRequestedUser("test-user");
        metadata.setDocumentName("shipping-label.pdf");

        metadata.setDocumentType(
                DocumentType.PDF);

        /*
         * Use existing enum values instead of guessing
         * the names defined in PrintType and PrinterType.
         */
        PrintType printType =
                PrintType.values()[0];

        PrinterType printerType =
                PrinterType.values()[0];

        metadata.setPrintType(printType);
        metadata.setPrinterType(printerType);

        metadata.setPrintPreview(true);
        metadata.setCopies(2);
        metadata.setItemNo(12345);
        metadata.setLocationId("STORE-101");
        metadata.setWarehouseId("WHS-101");
        metadata.setFilecontent("TEST CONTENT");

        assertEquals(
                "TRACK-1001",
                metadata.getTrackingId());

        assertEquals(
                "2026-11-18T17:30:00",
                metadata.getRequestTime());

        assertEquals(
                "test-user",
                metadata.getRequestedUser());

        assertEquals(
                "shipping-label.pdf",
                metadata.getDocumentName());

        assertEquals(
                DocumentType.PDF,
                metadata.getDocumentType());

        assertEquals(
                printType,
                metadata.getPrintType());

        assertTrue(
                metadata.getPrintPreview());

        assertEquals(
                printerType,
                metadata.getPrinterType());

        assertEquals(
                2,
                metadata.getCopies());

        assertEquals(
                12345,
                metadata.getItemNo());

        assertEquals(
                "STORE-101",
                metadata.getLocationId());

        assertEquals(
                "WHS-101",
                metadata.getWarehouseId());

        assertEquals(
                "TEST CONTENT",
                metadata.getFilecontent());
    }
}