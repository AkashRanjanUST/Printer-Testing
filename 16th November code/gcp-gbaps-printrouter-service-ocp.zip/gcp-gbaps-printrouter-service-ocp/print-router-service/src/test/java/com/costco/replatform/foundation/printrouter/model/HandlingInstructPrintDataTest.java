package com.costco.replatform.foundation.printrouter.model;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class HandlingInstructPrintDataTest {

    @Test
    void constructor_initializesFieldsToNull() {

        HandlingInstructPrintData data =
                new HandlingInstructPrintData();

        assertNull(data.getPrintDate());
        assertNull(data.getPrintTime());
        assertNull(data.getTitle());
        assertNull(data.getItemNumber());
        assertNull(data.getReportNumber());
        assertNull(data.getPageNumber());
        assertNull(data.getReviewMessage());
        assertNull(data.getNote());
        assertNull(data.getInstructions());
        assertNull(data.getContactLabel());
        assertNull(data.getContactPhone());
        assertNull(data.getContactEmail());
        assertNull(data.getFooterText());
    }

    @Test
    void gettersAndSettersWork() {

        HandlingInstructPrintData data =
                new HandlingInstructPrintData();

        List<String> instructions =
                List.of(
                        "Keep upright",
                        "Handle with care",
                        "Store in dry area");

        data.setPrintDate("2026-11-18");
        data.setPrintTime("18:00");
        data.setTitle("Handling Instructions");
        data.setItemNumber("ITEM-1001");
        data.setReportNumber("REPORT-1001");
        data.setPageNumber("1");
        data.setReviewMessage("Please review");
        data.setNote("Special handling required");
        data.setInstructions(instructions);
        data.setContactLabel("Contact");
        data.setContactPhone("1234567890");
        data.setContactEmail("test@example.com");
        data.setFooterText("End of Instructions");

        assertEquals(
                "2026-11-18",
                data.getPrintDate());

        assertEquals(
                "18:00",
                data.getPrintTime());

        assertEquals(
                "Handling Instructions",
                data.getTitle());

        assertEquals(
                "ITEM-1001",
                data.getItemNumber());

        assertEquals(
                "REPORT-1001",
                data.getReportNumber());

        assertEquals(
                "1",
                data.getPageNumber());

        assertEquals(
                "Please review",
                data.getReviewMessage());

        assertEquals(
                "Special handling required",
                data.getNote());

        assertEquals(
                instructions,
                data.getInstructions());

        assertEquals(
                3,
                data.getInstructions().size());

        assertEquals(
                "Keep upright",
                data.getInstructions().get(0));

        assertEquals(
                "Contact",
                data.getContactLabel());

        assertEquals(
                "1234567890",
                data.getContactPhone());

        assertEquals(
                "test@example.com",
                data.getContactEmail());

        assertEquals(
                "End of Instructions",
                data.getFooterText());
    }
}