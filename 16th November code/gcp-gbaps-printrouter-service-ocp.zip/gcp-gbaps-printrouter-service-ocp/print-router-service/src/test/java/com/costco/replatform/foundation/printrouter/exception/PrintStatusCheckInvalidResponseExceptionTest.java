package com.costco.replatform.foundation.printrouter.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintStatusCheckInvalidResponseExceptionTest {

    @Test
    void defaultConstructorWorks() {

        PrintStatusCheckInvalidResponseException exception =
                new PrintStatusCheckInvalidResponseException();

        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void messageConstructorWorks() {

        PrintStatusCheckInvalidResponseException exception =
                new PrintStatusCheckInvalidResponseException(
                        "Invalid response");

        assertEquals(
                "Invalid response",
                exception.getMessage());

        assertNull(exception.getCause());
    }

    @Test
    void messageAndCauseConstructorWorks() {

        RuntimeException cause =
                new RuntimeException("Root cause");

        PrintStatusCheckInvalidResponseException exception =
                new PrintStatusCheckInvalidResponseException(
                        "Invalid response",
                        cause);

        assertEquals(
                "Invalid response",
                exception.getMessage());

        assertSame(
                cause,
                exception.getCause());
    }

    @Test
    void causeConstructorWorks() {

        RuntimeException cause =
                new RuntimeException("Root cause");

        PrintStatusCheckInvalidResponseException exception =
                new PrintStatusCheckInvalidResponseException(
                        cause);

        assertSame(
                cause,
                exception.getCause());
    }
}