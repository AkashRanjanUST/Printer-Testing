package com.costco.replatform.foundation.printrouter;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PrintRouterApplicationTest {

    @Test
    void constructor_createsApplicationInstance() {

        PrintRouterApplication application =
                new PrintRouterApplication();

        assertNotNull(application);
    }

    @Test
    void main_startsSpringApplication() {

        String[] args = {
                "--spring.main.web-application-type=none"
        };

        ConfigurableApplicationContext context =
                mock(ConfigurableApplicationContext.class);

        try (MockedStatic<SpringApplication> springApplication =
                     mockStatic(SpringApplication.class)) {

            springApplication
                    .when(() ->
                            SpringApplication.run(
                                    PrintRouterApplication.class,
                                    args))
                    .thenReturn(context);

            assertDoesNotThrow(
                    () ->
                            PrintRouterApplication.main(args));

            springApplication.verify(
                    () ->
                            SpringApplication.run(
                                    PrintRouterApplication.class,
                                    args),
                    times(1));
        }
    }
}