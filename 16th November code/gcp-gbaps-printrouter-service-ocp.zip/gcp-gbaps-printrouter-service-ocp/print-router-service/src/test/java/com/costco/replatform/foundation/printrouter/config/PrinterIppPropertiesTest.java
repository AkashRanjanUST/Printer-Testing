package com.costco.replatform.foundation.printrouter.config;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrinterIppPropertiesTest {

    @Test
    void defaultValuesAreCorrect() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        assertEquals(
                10,
                properties.getConnectTimeoutSeconds());

        assertEquals(
                30,
                properties.getRequestTimeoutSeconds());

        assertFalse(properties.isCredEncoded());
    }

    @Test
    void requestingUserGetterSetterWorks() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setRequestingUser("testUser");

        assertEquals(
                "testUser",
                properties.getRequestingUser());
    }

    @Test
    void jobNameGetterSetterWorks() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setJobName("PRINT_JOB");

        assertEquals(
                "PRINT_JOB",
                properties.getJobName());
    }

    @Test
    void printContentGetterSetterWorks() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setPrintContent("HELLO WORLD");

        assertEquals(
                "HELLO WORLD",
                properties.getPrintContent());
    }

    @Test
    void connectTimeoutGetterSetterWorks() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setConnectTimeoutSeconds(25);

        assertEquals(
                25,
                properties.getConnectTimeoutSeconds());
    }

    @Test
    void requestTimeoutGetterSetterWorks() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setRequestTimeoutSeconds(45);

        assertEquals(
                45,
                properties.getRequestTimeoutSeconds());
    }

    @Test
    void credEncodedGetterSetterWorks() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setCredEncoded(true);

        assertTrue(properties.isCredEncoded());

        properties.setCredEncoded(false);

        assertFalse(properties.isCredEncoded());
    }
}