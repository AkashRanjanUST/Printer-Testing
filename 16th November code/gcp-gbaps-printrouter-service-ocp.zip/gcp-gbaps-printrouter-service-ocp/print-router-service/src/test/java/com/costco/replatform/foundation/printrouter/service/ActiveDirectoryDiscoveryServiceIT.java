package com.costco.replatform.foundation.printrouter.service;

import com.costco.replatform.foundation.printrouter.config.PrinterIppProperties;
import com.costco.replatform.foundation.printrouter.model.ActiveDirectoryDiscoveryResponse;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;
import javax.naming.PartialResultException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedConstruction;
import org.springframework.test.util.ReflectionTestUtils;

import javax.naming.NamingEnumeration;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class ActiveDirectoryDiscoveryServiceIT {

    private ActiveDirectoryDiscoveryService service;

    @BeforeEach
    void setUp() {

        PrinterIppProperties properties =
                new PrinterIppProperties();

        properties.setCredEncoded(false);

        service =
                new ActiveDirectoryDiscoveryService(
                        properties);

        /*
         * Test LDAP configuration.
         * No real LDAP connection will be made because
         * InitialLdapContext construction is intercepted.
         */

        ReflectionTestUtils.setField(
                service,
                "dcProtocol",
                "ldap://");

        ReflectionTestUtils.setField(
                service,
                "dcHost",
                "localhost");

        ReflectionTestUtils.setField(
                service,
                "dcPort",
                ":389");

        ReflectionTestUtils.setField(
                service,
                "bindUser",
                "integration-user");

        ReflectionTestUtils.setField(
                service,
                "bindPassword",
                "integration-password");

        ReflectionTestUtils.setField(
                service,
                "domainDn",
                "DC=test,DC=com");
    }

    @Test
    void discoverPrinters_emptyLdapResult_returnsEmptyPrinterList()
            throws Exception {

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        // LDAP search succeeds but finds nothing
        when(enumeration.hasMore())
                .thenReturn(false);

        try (MockedConstruction<InitialLdapContext> mocked =
                     mockConstruction(
                             InitialLdapContext.class,
                             (context, constructionContext) -> {

                                 when(context.search(
                                         anyString(),
                                         anyString(),
                                         any(SearchControls.class)))
                                         .thenReturn(enumeration);

                                 when(context.getResponseControls())
                                         .thenReturn(null);
                             })) {

            ApiResponse<ActiveDirectoryDiscoveryResponse> result =
                    service.discoverPrintersByLocation(
                            "STORE01");

            assertNotNull(result);

            assertTrue(result.isSuccess());

            assertNotNull(result.getResponse());

            assertNotNull(
                    result.getResponse().getPrinterList());

            assertTrue(
                    result.getResponse()
                            .getPrinterList()
                            .isEmpty());

            assertEquals(
                    1,
                    mocked.constructed().size());

            InitialLdapContext context =
                    mocked.constructed().get(0);

            verify(context)
                    .search(
                            anyString(),
                            anyString(),
                            any(SearchControls.class));

            verify(enumeration)
                    .close();

            verify(context)
                    .close();
        }
    }

    @Test
    void discoverPrinters_ldapConnectionFailure_handlesFailure()
            throws Exception {

        try (MockedConstruction<InitialLdapContext> mocked =
                     mockConstruction(
                             InitialLdapContext.class,
                             (context, constructionContext) -> {
                                 throw new RuntimeException(
                                         "LDAP connection failed");
                             })) {

            ApiResponse<ActiveDirectoryDiscoveryResponse> result =
                    service.discoverPrintersByLocation(
                            "STORE01");

            assertNotNull(result);

            /*
             * Assert according to the current production contract.
             * Based on the service's existing behavior, discovery
             * failures are handled rather than escaping directly.
             */
            assertNotNull(result.getMessage());
        }
    }

    @Test
    void discoverPrinters_partialResultException_isHandled()
            throws Exception {

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        when(enumeration.hasMore())
                .thenThrow(
                        new PartialResultException(
                                "LDAP referral / partial result"));

        try (MockedConstruction<InitialLdapContext> mocked =
                     mockConstruction(
                             InitialLdapContext.class,
                             (context, constructionContext) -> {

                                 when(context.search(
                                         anyString(),
                                         anyString(),
                                         any(SearchControls.class)))
                                         .thenReturn(enumeration);

                                 when(context.getResponseControls())
                                         .thenReturn(null);
                             })) {

            ApiResponse<ActiveDirectoryDiscoveryResponse> result =
                    service.discoverPrintersByLocation(
                            "STORE01");

            assertNotNull(result);
            assertTrue(result.isSuccess());

            assertNotNull(result.getResponse());
            assertNotNull(result.getResponse().getPrinterList());

            assertTrue(
                    result.getResponse()
                            .getPrinterList()
                            .isEmpty());

            InitialLdapContext context =
                    mocked.constructed().get(0);

            verify(context)
                    .search(
                            anyString(),
                            anyString(),
                            any(SearchControls.class));

            verify(enumeration)
                    .close();

            verify(context)
                    .close();
        }
    }

    @Test
    void discoverPrinters_success_integratesLdapMappingWorkflow()
            throws Exception {

        // --------------------------------------------------------
        // Simulated LDAP result
        // --------------------------------------------------------

        SearchResult searchResult =
                mock(SearchResult.class);

        BasicAttributes attributes =
                new BasicAttributes();

        attributes.put(
                new BasicAttribute(
                        "cn",
                        "PRINTER01"));

        attributes.put(
                new BasicAttribute(
                        "printsharename",
                        "SHARE01"));

        attributes.put(
                new BasicAttribute(
                        "shortservername",
                        "SERVER01"));

        attributes.put(
                new BasicAttribute(
                        "location",
                        "STORE01"));

        attributes.put(
                new BasicAttribute(
                        "drivername",
                        "HP LaserJet"));

        attributes.put(
                new BasicAttribute(
                        "portname",
                        "IP_10.20.30.40"));

        when(searchResult.getAttributes())
                .thenReturn(attributes);

        // --------------------------------------------------------
        // LDAP enumeration
        // --------------------------------------------------------

        @SuppressWarnings("unchecked")
        NamingEnumeration<SearchResult> enumeration =
                mock(NamingEnumeration.class);

        when(enumeration.hasMore())
                .thenReturn(true, false);

        when(enumeration.next())
                .thenReturn(searchResult);

        // --------------------------------------------------------
        // Intercept real InitialLdapContext creation
        // --------------------------------------------------------

        try (MockedConstruction<InitialLdapContext> mocked =
                     mockConstruction(
                             InitialLdapContext.class,
                             (context, constructionContext) -> {

                                 when(context.search(
                                         anyString(),
                                         anyString(),
                                         any(SearchControls.class)))
                                         .thenReturn(enumeration);

                                 when(context.getResponseControls())
                                         .thenReturn(null);
                             })) {

            // ----------------------------------------------------
            // Execute REAL production discovery workflow
            // ----------------------------------------------------

            ApiResponse<ActiveDirectoryDiscoveryResponse> result =
                    service.discoverPrintersByLocation(
                            "STORE01");

            // ----------------------------------------------------
            // Validate API response
            // ----------------------------------------------------

            assertNotNull(result);

            assertTrue(
                    result.isSuccess());

            assertNotNull(
                    result.getResponse());

            List<PrinterMetadata> printers =
                    result.getResponse()
                            .getPrinterList();

            assertNotNull(printers);

            assertEquals(
                    1,
                    printers.size());

            // ----------------------------------------------------
            // Validate LDAP -> PrinterMetadata mapping
            // ----------------------------------------------------

            PrinterMetadata printer =
                    printers.get(0);

            assertEquals(
                    "PRINTER01",
                    printer.getPrinterName());

            assertEquals(
                    "SHARE01",
                    printer.getShareName());

            assertEquals(
                    "SERVER01",
                    printer.getServer());

            assertEquals(
                    "STORE01",
                    printer.getLocation());

            assertEquals(
                    "HP LaserJet",
                    printer.getModel());

            assertEquals(
                    "IP_10.20.30.40",
                    printer.getPortName());

            assertEquals(
                    "10.20.30.40",
                    printer.getIpAddress());

            // ----------------------------------------------------
            // Validate resource handling
            // ----------------------------------------------------

            assertEquals(
                    1,
                    mocked.constructed().size());

            InitialLdapContext context =
                    mocked.constructed().get(0);

            verify(context)
                    .search(
                            anyString(),
                            anyString(),
                            any(SearchControls.class));

            verify(enumeration)
                    .close();

            verify(context)
                    .close();
        }
    }
}
