package com.costco.replatform.foundation.printrouter.common.enums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintRequestStatusTest {

    @Test
    void values_containsAllExpectedStatuses() {

        PrintRequestStatus[] values =
                PrintRequestStatus.values();

        assertEquals(5, values.length);

        assertArrayEquals(
                new PrintRequestStatus[]{
                        PrintRequestStatus.PRINT_REQUESTED,
                        PrintRequestStatus.PRINT_REQUEST_FAILED,
                        PrintRequestStatus.PRINTER_NOT_FOUND,
                        PrintRequestStatus.PRINTER_CONNECTION_ERROR,
                        PrintRequestStatus.PRINTER_AUTHENTICATION_FAILED
                },
                values);
    }

    @Test
    void valueOf_returnsExpectedStatuses() {

        assertEquals(
                PrintRequestStatus.PRINT_REQUESTED,
                PrintRequestStatus.valueOf("PRINT_REQUESTED"));

        assertEquals(
                PrintRequestStatus.PRINT_REQUEST_FAILED,
                PrintRequestStatus.valueOf("PRINT_REQUEST_FAILED"));

        assertEquals(
                PrintRequestStatus.PRINTER_NOT_FOUND,
                PrintRequestStatus.valueOf("PRINTER_NOT_FOUND"));

        assertEquals(
                PrintRequestStatus.PRINTER_CONNECTION_ERROR,
                PrintRequestStatus.valueOf("PRINTER_CONNECTION_ERROR"));

        assertEquals(
                PrintRequestStatus.PRINTER_AUTHENTICATION_FAILED,
                PrintRequestStatus.valueOf(
                        "PRINTER_AUTHENTICATION_FAILED"));
    }

    @Test
    void valueOf_invalidStatus_throwsException() {

        assertThrows(
                IllegalArgumentException.class,
                () -> PrintRequestStatus.valueOf("INVALID"));
    }
}