package com.costco.replatform.foundation.printrouter.exception;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;

import javax.net.ssl.SSLHandshakeException;

import org.springframework.http.HttpStatus;

public class PrintStatusCheckException extends RuntimeException {

    public PrintStatusCheckException() {
        super();
    }

    public PrintStatusCheckException(String message) {
        super(message);
    }

    public PrintStatusCheckException(String message, Throwable cause) {
        super(message, cause);
    }

    public PrintStatusCheckException(Throwable cause) {
        super(cause);
    }

    /**
     * Method to get Http Status.
     * @param ex
     * @return
     */
       public static HttpStatus getHttpStatus(Throwable cause) {

        if (cause instanceof SocketTimeoutException) {
            return HttpStatus.GATEWAY_TIMEOUT;
        }

        if (cause instanceof ConnectException
                || cause instanceof SocketException) {
            return HttpStatus.SERVICE_UNAVAILABLE;
        }

        if (cause instanceof SSLHandshakeException) {
            return HttpStatus.BAD_GATEWAY;
        }

        if (cause instanceof IllegalArgumentException) {
            return HttpStatus.BAD_REQUEST;
        }

        return HttpStatus.INTERNAL_SERVER_ERROR;
    }

}
  

