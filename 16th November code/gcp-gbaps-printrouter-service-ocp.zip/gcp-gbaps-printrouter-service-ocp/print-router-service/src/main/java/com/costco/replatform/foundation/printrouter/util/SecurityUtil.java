package com.costco.replatform.foundation.printrouter.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SecurityUtil {
	
	
	private static final Logger log = LoggerFactory.getLogger(SecurityUtil.class);
	
	
	/**
	 * Method to decode base64.
	 * @param encodedValue
	 * @return
	 */
	public static String decodeBase64(String encodedValue) {
		log.info("SEC_DECODE::Decoding...");
		if (encodedValue == null || encodedValue.isBlank()) {
			return encodedValue;
		}

		try {
			return new String(Base64.getDecoder().decode(encodedValue), StandardCharsets.UTF_8);
		} catch (IllegalArgumentException ex) {
			log.info("SEC_DECODE::Decoding exception happened..fallback to original value...");
			return encodedValue;
		}
	}

}
