package com.costco.replatform.foundation.printrouter.util;

public final class LogSanitizer {

    private LogSanitizer() {
    }

    public static String sanitize(Object value) {
        String text = String.valueOf(value);
        StringBuilder safe = new StringBuilder(text.length());
        text.codePoints().forEach(codePoint -> {
            int type = Character.getType(codePoint);
            if (Character.isISOControl(codePoint) || type == Character.FORMAT
                    || type == Character.LINE_SEPARATOR || type == Character.PARAGRAPH_SEPARATOR) {
                safe.append(String.format("\\u%04x", codePoint));
            } else {
                safe.appendCodePoint(codePoint);
            }
        });
        return safe.toString();
    }
    
    /**
     * Method to mask data.
     * @param data
     * @return
     */
    public  static String mask(String data) {
        if (data == null || data.isEmpty()) {
            return "****";
        }
        
        int charsToMask = Math.min(4, data.length());
        
        if (data.length() <= charsToMask) {
            return "*".repeat(data.length());
        }
        
        return "*".repeat(charsToMask) + data.substring(charsToMask);
    }

}
