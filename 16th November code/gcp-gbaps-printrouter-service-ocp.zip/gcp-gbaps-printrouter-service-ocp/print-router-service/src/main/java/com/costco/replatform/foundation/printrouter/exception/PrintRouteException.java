package com.costco.replatform.foundation.printrouter.exception;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;

import javax.net.ssl.SSLHandshakeException;

import org.springframework.http.HttpStatus;

public class PrintRouteException extends RuntimeException {
	
	 public PrintRouteException() {
	        super();
	    }

	    public PrintRouteException(String message) {
	        super(message);
	    }

	    public PrintRouteException(String message, Throwable cause) {
	        super(message, cause);
	    }

	    public PrintRouteException(Throwable cause) {
	        super(cause);
	    }
	    
	    
	   


}
