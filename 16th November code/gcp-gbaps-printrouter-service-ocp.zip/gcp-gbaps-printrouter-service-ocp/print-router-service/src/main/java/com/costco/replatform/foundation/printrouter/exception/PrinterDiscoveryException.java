package com.costco.replatform.foundation.printrouter.exception;

public class PrinterDiscoveryException extends RuntimeException {
	
	 public PrinterDiscoveryException() {
	        super();
	    }

	    public PrinterDiscoveryException(String message) {
	        super(message);
	    }

	    public PrinterDiscoveryException(String message, Throwable cause) {
	        super(message, cause);
	    }

	    public PrinterDiscoveryException(Throwable cause) {
	        super(cause);
	    }
	    
	    
	   

}
