package com.costco.replatform.foundation.printrouter.exception;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;

import javax.net.ssl.SSLHandshakeException;

import org.springframework.http.HttpStatus;

public class ExceptionParser {
	
	 
    /**
     * Method to get Http Status.
     * @param ex
     * @return
     */
    public static HttpStatus getHttpStatus(Throwable cause) {

        if (cause == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }

        // 400 - Client Errors
        if (cause instanceof IllegalArgumentException
                || cause instanceof NumberFormatException) {
            return HttpStatus.BAD_REQUEST;
        }

        // 401 - Authentication Errors
        if (cause instanceof javax.naming.AuthenticationException) {
            return HttpStatus.UNAUTHORIZED;
        }

        // 403 - Authorization Errors
        if (cause instanceof SecurityException) {
            return HttpStatus.FORBIDDEN;
        }

        // 502 - SSL / Certificate / Downstream Errors
        if (cause instanceof SSLHandshakeException
                || cause instanceof javax.net.ssl.SSLException
                || cause instanceof java.security.cert.CertificateException) {
            return HttpStatus.BAD_GATEWAY;
        }

        // 503 - Service Unavailable
        if (cause instanceof ConnectException
                || cause instanceof SocketException
                || cause instanceof javax.naming.CommunicationException
                || cause instanceof javax.naming.NamingException) {
            return HttpStatus.SERVICE_UNAVAILABLE;
        }

        // 504 - Timeout
        if (cause instanceof SocketTimeoutException
                || cause instanceof java.util.concurrent.TimeoutException) {
            return HttpStatus.GATEWAY_TIMEOUT;
        }

        // REST Client Errors
        if (cause instanceof org.springframework.web.client.HttpClientErrorException.BadRequest) {
            return HttpStatus.BAD_REQUEST;
        }

        if (cause instanceof org.springframework.web.client.HttpClientErrorException.NotFound) {
            return HttpStatus.NOT_FOUND;
        }

        if (cause instanceof org.springframework.web.client.HttpClientErrorException.Unauthorized) {
            return HttpStatus.UNAUTHORIZED;
        }

        if (cause instanceof org.springframework.web.client.HttpServerErrorException) {
            return HttpStatus.BAD_GATEWAY;
        }

        if (cause instanceof org.springframework.web.client.ResourceAccessException) {
            return HttpStatus.SERVICE_UNAVAILABLE;
        }

        // JSON Processing
        if (cause instanceof com.fasterxml.jackson.core.JsonParseException
                || cause instanceof com.fasterxml.jackson.databind.JsonMappingException) {
            return HttpStatus.BAD_REQUEST;
        }

        // Unsupported Operations
        if (cause instanceof UnsupportedOperationException) {
            return HttpStatus.NOT_IMPLEMENTED;
        }

        // Fallback
        return HttpStatus.INTERNAL_SERVER_ERROR;
    }
       
       /**
        * Returns the appropriate ErrorCode based on the root cause.
        *
        * @param cause Root cause exception
        * @return ErrorCode
        */
       public static ErrorCode getErrorCode(Throwable cause) {

           if (cause == null) {
               return ErrorCode.INTERNAL_SERVER_ERROR;
           }

           // Validation Errors
           if (cause instanceof IllegalArgumentException) {
               return ErrorCode.ILLEGAL_ARGUMENT;
           }

           // Printer Connectivity
           if (cause instanceof ConnectException) {
               return ErrorCode.PRINTER_UNREACHABLE;
           }

           if (cause instanceof SocketTimeoutException) {
               return ErrorCode.CONNECTION_TIMEOUT;
           }

           if (cause instanceof SocketException) {
               return ErrorCode.SERVICE_UNAVAILABLE;
           }

           // SSL / Certificate
           if (cause instanceof SSLHandshakeException) {
               return ErrorCode.SSL_HANDSHAKE_FAILED;
           }

           if (cause instanceof java.security.cert.CertificateException) {
               return ErrorCode.CERTIFICATE_VALIDATION_FAILED;
           }

           if (cause instanceof javax.net.ssl.SSLException) {
               return ErrorCode.SSL_HANDSHAKE_FAILED;
           }

           // LDAP
           if (cause instanceof javax.naming.AuthenticationException) {
               return ErrorCode.LDAP_AUTHENTICATION_FAILED;
           }

           if (cause instanceof javax.naming.CommunicationException) {
               return ErrorCode.LDAP_CONNECTION_FAILED;
           }

           if (cause instanceof javax.naming.NamingException) {
               return ErrorCode.LDAP_CONNECTION_FAILED;
           }
         
           // HTTP Layer
           if (cause instanceof org.springframework.web.client.HttpClientErrorException) {
               return ErrorCode.INVALID_REQUEST;
           }

           if (cause instanceof org.springframework.web.client.HttpServerErrorException) {
               return ErrorCode.DOWNSTREAM_SERVICE_FAILURE;
           }

           if (cause instanceof org.springframework.web.client.ResourceAccessException) {
               return ErrorCode.SERVICE_UNAVAILABLE;
           }

           // JSON Processing
           if (cause instanceof com.fasterxml.jackson.core.JsonParseException
                   || cause instanceof com.fasterxml.jackson.databind.JsonMappingException) {
               return ErrorCode.INVALID_INPUT_FORMAT;
           }

          

           // Fallback
           return ErrorCode.INTERNAL_SERVER_ERROR;
       }

}
