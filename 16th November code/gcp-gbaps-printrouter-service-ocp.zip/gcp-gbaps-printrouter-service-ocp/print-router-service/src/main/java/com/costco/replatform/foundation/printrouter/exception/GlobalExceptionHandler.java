package com.costco.replatform.foundation.printrouter.exception;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.net.ssl.SSLHandshakeException;

import static com.costco.replatform.foundation.printrouter.exception.ExceptionParser.getHttpStatus;
import static com.costco.replatform.foundation.printrouter.exception.ExceptionParser.getErrorCode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.costco.replatform.foundation.printrouter.model.ApiResponse;

import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@Autowired
	private MessageSource messageSource;

	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	

	/**
	 * Method to throw exception for Method Argument Invalid.
	 * 
	 * @param ex
	 * @return
	 */
	@ExceptionHandler({ IllegalArgumentException.class })
	public ResponseEntity<ApiResponse<Void>> handlIllegalArgValidxceptions(IllegalArgumentException ex) {
		logger.warn("GlobalExceptionHandler:handlIllegalArgValidxceptions", ex);
		String message = messageSource.getMessage("costco.replatform.printroute.illegalarg.message",
				new Object[] { ex.getMessage() }, Locale.getDefault());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
				ApiResponse.failures(ErrorCode.ILLEGAL_ARGUMENT.getCode(), message, HttpStatus.BAD_REQUEST.value()));
	}

	/**
	 * Method to throw exception for Print Route.
	 * 
	 * @param ex
	 * @return
	 */

	@ExceptionHandler(PrintRouteException.class)
	public ResponseEntity<ApiResponse<Void>> handlePrintRoutetException(PrintRouteException ex) {
		logger.warn("GlobalExceptionHandler:handlePrintRouteException", ex);
		String message = messageSource.getMessage("costco.replatform.printroute.send.message",
				new Object[] { ex.getMessage() }, Locale.getDefault());
		return ResponseEntity.status(getHttpStatus(ex.getCause()))
				.body(ApiResponse.failures(getErrorCode(ex.getCause()).getCode(), message,
						getHttpStatus(ex.getCause()).value()));
	}

	/**
	 * Method to throw exception for Print Status Check.
	 * 
	 * @param ex
	 * @return
	 */

	@ExceptionHandler(PrintStatusCheckException.class)
	public ResponseEntity<ApiResponse<Void>> handlePrintStatusCheckException(PrintStatusCheckException ex) {
		logger.warn("GlobalExceptionHandler:handlePrintStatusCheckException", ex);
		String message = messageSource.getMessage("costco.replatform.printroute.status.message",
				new Object[] { ex.getMessage() }, Locale.getDefault());
		return ResponseEntity.status(getHttpStatus(ex.getCause()))
				.body(ApiResponse.failures(getErrorCode(ex.getCause()).getCode(), message,
						getHttpStatus(ex.getCause()).value()));
	}
	
	/**
	 * Method to throw exception for Print Status Check.
	 * 
	 * @param ex
	 * @return
	 */

	@ExceptionHandler(PrintStatusCheckInvalidResponseException.class)
	public ResponseEntity<ApiResponse<Void>> handlePrintStatusCheckRespInvalidException(PrintStatusCheckInvalidResponseException ex) {
		logger.warn("GlobalExceptionHandler:handlePrintStatusCheckRespInvalidException", ex);
		String message = messageSource.getMessage("costco.replatform.printroute.status.responseinvalid.message",
				new Object[] { ex.getMessage() }, Locale.getDefault());
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_CONTENT)
				.body(ApiResponse.failures(getErrorCode(ex.getCause()).getCode(), message,
						HttpStatus.UNPROCESSABLE_CONTENT.value()));
	}
	
	
	/**
	 * Method to throw exception for Print Status Check.
	 * 
	 * @param ex
	 * @return
	 */

	@ExceptionHandler(PrintRouteResponseInvalidException.class)
	public ResponseEntity<ApiResponse<Void>> handlePrintRouteResponseInvalidException(PrintRouteResponseInvalidException ex) {
		logger.warn("GlobalExceptionHandler:handlePrintRouteResponseInvalidException", ex);
		String message = messageSource.getMessage("costco.replatform.printroute.invalidresponse.message",
				new Object[] { ex.getMessage() }, Locale.getDefault());
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_CONTENT)
				.body(ApiResponse.failures(getErrorCode(ex.getCause()).getCode(), message,
						HttpStatus.UNPROCESSABLE_CONTENT.value()));
	}
	
	
	/**
	 * Method to throw exception for Print Status Check.
	 * 
	 * @param ex
	 * @return
	 */

	@ExceptionHandler(PrintRouteInvalidArgumentException.class)
	public ResponseEntity<ApiResponse<Void>> handlePrintRouteInvalidArgumentException(PrintRouteInvalidArgumentException ex) {
		logger.warn("GlobalExceptionHandler:handlePrintStatusCheckException", ex);
		String message = messageSource.getMessage("costco.replatform.printroute.invalidarg.message",
				new Object[] { ex.getMessage() }, Locale.getDefault());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body(ApiResponse.failures(getErrorCode(ex.getCause()).getCode(), message,
						HttpStatus.BAD_REQUEST.value()));
	}


	

	
	/**
	 * Method to throw exception for Print Discovery
	 * 
	 * @param ex
	 * @return
	 */

	@ExceptionHandler(PrinterDiscoveryException.class)
	public ResponseEntity<ApiResponse<Void>> handlePrinterDiscoveryException(PrinterDiscoveryException ex) {
		logger.warn("GlobalExceptionHandler:handlePrintStatusCheckException", ex);
		String message = messageSource.getMessage("costco.replatform.printroute.discovery.message",
				new Object[] { ex.getMessage() }, Locale.getDefault());
		return ResponseEntity.status(getHttpStatus(ex.getCause()))
				.body(ApiResponse.failures(getErrorCode(ex.getCause()).getCode(), message,
						getHttpStatus(ex.getCause()).value()));
	}
	
	/**
	 * Method to handle any exception with in Application.
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiResponse<Void>> handleUnhandledException(Exception ex, HttpServletRequest request) {

		logger.error("Unhandled exception for {} : {}", getRequestInfo(request),ex);

		String message = messageSource.getMessage("costco.replatform.printroute.internal.message", null,
				Locale.getDefault());

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ApiResponse.failures(
				ErrorCode.INTERNAL_SERVER_ERROR.getCode(), message, HttpStatus.INTERNAL_SERVER_ERROR.value()));
	}
	
	
	/**
	 * Method to get request details.
	 * @param request
	 * @return
	 */
	
	 private String getRequestInfo(HttpServletRequest request) {
	        if (request == null) return "Unknown Request";
	        return String.format("%s %s", request.getMethod(), request.getRequestURI());
	    }


}
