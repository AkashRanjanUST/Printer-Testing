//package com.costco.replatform.foundation.printrouter.config;
//
//import java.util.Arrays;
//import java.util.List;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest;
//import org.springframework.cache.annotation.EnableCaching;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.annotation.Order;
//import org.springframework.http.HttpMethod;
//import org.springframework.scheduling.annotation.EnableAsync;
//import org.springframework.security.config.Customizer;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//
//
//@Configuration
//@EnableWebSecurity
//@EnableAsync
//@EnableCaching
//public class CostcoWebConfig {
//
//	private static final Logger logger = LoggerFactory.getLogger(CostcoWebConfig.class);
//	
//	@Value("${app.security.request-matcher.path}")
//    private String pathPattern;
//	
//	@Value("${app.cors.allowed-origins}")
//    private String[] allowedOrigins;
//	
//	@Value("${app.security.exclude-paths}")
//    private String[] excludePaths;
//	
//	@Value("${app.security.allow-paths}")
//    private String[] allowPaths;
//	
//	@Value("${app.cors.allowed-headers}")
//    private String[] allowedHeaders;
//
//    @Value("${app.cors.exposed-headers}")
//    private String[] exposedHeaders;    
//
//    @Value("${spring_security_user_name}")
//    private String username;
//
//    @Value("${spring_security_user_password}")
//    private String password;
//
//    @Value("${app.security.exclude-path-for-messaging}")
//    private String exclude_path_for_messaging;
//    
// 	
//    /**
//     * Configures a dedicated {@link SecurityFilterChain} for Spring Boot Actuator endpoints.
//     * <p>
//     * This filter chain is applied <strong>only</strong> to Actuator endpoints using
//     * {@link org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest#toAnyEndpoint()}.
//     * All Actuator requests are permitted without authentication.
//     * <p>
//     * CSRF protection is disabled because Actuator endpoints are typically accessed
//     * programmatically (e.g., by monitoring systems) and do not require browser-based CSRF protection.
//     * <p>
//     * The {@link Order @Order(0)} annotation ensures this filter chain is evaluated
//     * before any other security filter chains.
//     *
//     * @param http the {@link org.springframework.security.config.annotation.web.builders.HttpSecurity}
//     *             used to configure the security filter chain
//     * @return the configured {@link SecurityFilterChain} for Actuator endpoints
//     * @throws Exception if an error occurs while building the security filter chain
//     */
//	
//
//	@Bean
//	@Order(0)
//	public SecurityFilterChain actuatorSecurityFilterChain(HttpSecurity http) throws Exception {
//		http
//        .securityMatcher(EndpointRequest.toAnyEndpoint())
//                .authorizeHttpRequests(auth -> auth.requestMatchers(EndpointRequest.to("health")).permitAll().anyRequest().hasRole("ACTUATOR"))
//                .csrf(csrf -> csrf.ignoringRequestMatchers(EndpointRequest.toAnyEndpoint()))
//        .httpBasic(Customizer.withDefaults()); 
//
//	    return http.build();
//	}
//	
//	
//	
//	@Bean
//	@Order(1)
//	public SecurityFilterChain apiSecurityFilterChain(HttpSecurity http) throws Exception {
//		
//		logger.info("Initializing API Security Filter Chain");
//		logger.info("Allow Paths: {}", Arrays.toString(allowPaths));
//		logger.info("Path Pattern: {}", pathPattern);
//
//	    http
//	        // CORS Enabling -  using your defined configuration
//	        .cors(cors -> cors.configurationSource(corsConfigurationSource()))
//
//	        // CSRF Bypassing - enabled globally but ignored for stateless/public endpoints
//	        .csrf(csrf -> csrf.ignoringRequestMatchers(
//	                new AntPathRequestMatcher(excludePaths[0]),
//	                new AntPathRequestMatcher(excludePaths[1]),
//	                new AntPathRequestMatcher(pathPattern, HttpMethod.OPTIONS.name()),
//	                new AntPathRequestMatcher(excludePaths[2]),
//	                new AntPathRequestMatcher(excludePaths[3]),
//	                // Add /api/v1/messages/** to CSRF ignore for POST, PUT, DELETE
//	                new AntPathRequestMatcher(exclude_path_for_messaging, HttpMethod.POST.name()),
//	                new AntPathRequestMatcher(exclude_path_for_messaging, HttpMethod.PUT.name()),
//	                new AntPathRequestMatcher(exclude_path_for_messaging, HttpMethod.DELETE.name())
//	        ))
//
//	        //Authorization bypassing
//	        .authorizeHttpRequests(auth -> {
//	            // 1. Allow OPTIONS requests first
//	            auth.requestMatchers(HttpMethod.OPTIONS, pathPattern).permitAll();
//	            
//	            // 2. Explicitly allow /api/v1/messages/** for all HTTP methods without authentication
//	            auth.requestMatchers(exclude_path_for_messaging).permitAll();
//	            
//	            // 3. Build array of AntPathRequestMatchers from other allowPaths
//	            java.util.List<AntPathRequestMatcher> matchers = new java.util.ArrayList<>();
//	            for (String allowPath : allowPaths) {
//	                // Skip /api/v1/messages/** as we've already handled it
//	                if (!allowPath.equals(exclude_path_for_messaging)) {
//	                    matchers.add(new AntPathRequestMatcher(allowPath));
//	                }
//	            }
//	            
//	            // 4. Apply all other matchers
//	            if (!matchers.isEmpty()) {
//	                auth.requestMatchers(matchers.toArray(new AntPathRequestMatcher[0])).permitAll();
//	            }
//	            
//	            // 5. All other requests require authentication
//	            auth.anyRequest().authenticated();
//	        })
//
//
//
//
//	        .httpBasic(Customizer.withDefaults());
//
//	    return http.build();
//	}
//
//	/**
//	 * Method to implement CORS Configuration.
//	 * @return
//	 */
//	@Bean
//	public CorsConfigurationSource corsConfigurationSource() {
//		CorsConfiguration configuration = new CorsConfiguration();
//		configuration.setAllowedOrigins(List.of(allowedOrigins)); // Frontend origin
//		configuration.setAllowedMethods(List.of(HttpMethod.GET.name(), HttpMethod.POST.name(), HttpMethod.PUT.name(), HttpMethod.DELETE.name(), HttpMethod.OPTIONS.name()));
////        configuration.setAllowedHeaders(List.of("*"));
////        configuration.setExposedHeaders(List.of("*"));
//		configuration.setAllowedHeaders(Arrays.asList(allowedHeaders));
//		configuration.setExposedHeaders(Arrays.asList(exposedHeaders));
//		configuration.setAllowCredentials(true); // Allow auth headers
//		logger.info("CORS configuration - origins: {}, methods: {}, credentials: {}",
//				configuration.getAllowedOrigins(), configuration.getAllowedMethods(),
//				configuration.getAllowCredentials());
//		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//		source.registerCorsConfiguration(pathPattern, configuration);
//		return source;
//	}
//	
//	
//	
//}
