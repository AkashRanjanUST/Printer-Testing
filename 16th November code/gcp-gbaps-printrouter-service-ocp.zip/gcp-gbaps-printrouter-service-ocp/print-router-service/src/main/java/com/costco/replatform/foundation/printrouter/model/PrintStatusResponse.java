package com.costco.replatform.foundation.printrouter.model;

public class PrintStatusResponse {
	
	
	
	private String printerName;
	
	private String printerIp;

	private Integer printJobId;

	private String printJobStatus;

	

	public String getPrinterIp() {
		return printerIp;
	}

	public void setPrinterIp(String printerIp) {
		this.printerIp = printerIp;
	}

	public String getPrintJobStatus() {
		return printJobStatus;
	}

	public void setPrintJobStatus(String printJobStatus) {
		this.printJobStatus = printJobStatus;
	}

	public String getPrinterName() {
		return printerName;
	}

	public void setPrinterName(String printerName) {
		this.printerName = printerName;
	}

	public Integer getPrintJobId() {
		return printJobId;
	}

	public void setPrintJobId(Integer printJobId) {
		this.printJobId = printJobId;
	}
	
	@Override
	public String toString() {
	    return "PrintStatusResponse{" +	          
	            ", printerName='" + printerName + '\'' +
	             ", printerIp='" + printerIp + '\'' +
	            ", printerJobId=" + printJobId +
	            ", printJobStatus='" + printJobStatus + '\'' +
	            '}';
	}
	

}
