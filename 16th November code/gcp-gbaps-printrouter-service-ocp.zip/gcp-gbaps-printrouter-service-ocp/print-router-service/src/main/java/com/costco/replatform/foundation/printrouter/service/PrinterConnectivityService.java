package com.costco.replatform.foundation.printrouter.service;

import static com.costco.replatform.foundation.printrouter.util.LogSanitizer.sanitize;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.costco.replatform.foundation.printrouter.common.enums.DocumentType;
import com.costco.replatform.foundation.printrouter.config.PrinterIppProperties;
import com.costco.replatform.foundation.printrouter.exception.ErrorCode;
import com.costco.replatform.foundation.printrouter.exception.PrintRouteException;
import com.costco.replatform.foundation.printrouter.exception.PrintRouteInvalidArgumentException;
import com.costco.replatform.foundation.printrouter.exception.PrintRouteResponseInvalidException;
import com.costco.replatform.foundation.printrouter.exception.PrintStatusCheckException;
import com.costco.replatform.foundation.printrouter.exception.PrintStatusCheckInvalidResponseException;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.ActiveDirectoryDiscoveryResponse;
import com.costco.replatform.foundation.printrouter.model.PrintRouteResponse;
import com.costco.replatform.foundation.printrouter.model.PrintStatusResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterIppResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;
import com.costco.replatform.foundation.printrouter.util.PrinterEndpointPolicy;
import static com.costco.replatform.foundation.printrouter.util.SecurityUtil.decodeBase64;
import static com.costco.replatform.foundation.printrouter.util.LogSanitizer.mask;

@Service
public class PrinterConnectivityService {

	private static final short PRINT_JOB_OPERATION_ID = 0x0002;

	private static final int OPERATION_ATTRIBUTES_TAG = 0x01;
	private static final int END_OF_ATTRIBUTES_TAG = 0x03;

	private static final int NAME_WITHOUT_LANGUAGE_TAG = 0x42;
	private static final int URI_TAG = 0x45;
	private static final int CHARSET_TAG = 0x47;
	private static final int NATURAL_LANGUAGE_TAG = 0x48;
	private static final int MIME_MEDIA_TYPE_TAG = 0x49;

	private static final int MINIMUM_IPP_RESPONSE_LENGTH = 8;

	private static final int INTEGER_TAG = 0x21;

	private static final short GET_JOB_ATTRIBUTES_OPERATION_ID = 0x0009;
	private static final int KEYWORD_TAG = 0x44;

	private final PrinterIppProperties properties;
	private final ActiveDirectoryDiscoveryService discoveryService;   

	@Value("${printrouter.auth.domainname}")
	private String domainName;
	
	@Value("${printrouter.auth.username}")
	private String printerAuthUserName;

	@Value("${printrouter.auth.password}")
	private String printerAuthPassword;
	
	public PrinterConnectivityService(PrinterIppProperties properties, ActiveDirectoryDiscoveryService discoveryService) {
		this.properties = properties;
		this.discoveryService = discoveryService;
	}

	private HttpClient httpClient(URI destination) {
		String username = properties.isCredEncoded()
				? decodeBase64(printerAuthUserName) : printerAuthUserName;
		username=domainName+"\\"+username;
		String password = properties.isCredEncoded()
				? decodeBase64(printerAuthPassword) : printerAuthPassword;
		
		log.info("PRINTER_AUTH::isEncdoed::"+properties.isCredEncoded());
		log.info("PRINTER_AUTH::username::"+mask(username));
		return HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER)
				.connectTimeout(Duration.ofSeconds(properties.getConnectTimeoutSeconds()))
				.authenticator(PrinterEndpointPolicy.authenticator(destination, username, password)).build();
	}

	private static final Logger log = LoggerFactory.getLogger(PrinterConnectivityService.class);

	/**
	 * Method to do Print.
	 * 
	 * @param printRouteResponse
	 * @param routeApiResponse
	 * @param itemNo
	 * @param documentName
	 * @param documentType
	 * @param trackingId
	 * @param printContent
	 * @param printerList
	 * @return
	 */

	public ApiResponse<PrintRouteResponse> doPrint(Integer itemNo, String documentName, String documentType,
			String trackingId, String printContent, List<PrinterMetadata> printerList, int copies) {
		
		validateInput();		
		PrintRouteResponse printRouteResponse = new PrintRouteResponse();
		ApiResponse<PrintRouteResponse> routeApiResponse = ApiResponse.init(printRouteResponse);
		
		try {
			for (PrinterMetadata printerMetadata : printerList) {
				if (printerMetadata != null) {
					String printerName = printerMetadata.getPrinterName();
					String printerIp = printerMetadata.getIpAddress();

					if (printerIp == null || printerIp.equalsIgnoreCase(StringUtils.EMPTY)
							|| printerIp.equalsIgnoreCase("EMPTY")) {
						log.warn("OCP_PRINT_ROUTE_EXCEPTION::IP address from AD response is invalid: {}", sanitize(printerIp));
						throw new PrintRouteInvalidArgumentException("PrinterIp is invalid");
					}
					PrinterEndpointPolicy.printerUri(printerIp);
					log.info("OCP_PRINT_ROUTE::Sending IPP request to printer: {}", sanitize(printerIp));
					Integer printResponseStatus = null;
					ApiResponse<PrinterIppResponse> printResponse = sendPrintRequest(itemNo, printerName, documentName,
							documentType, printContent, printerIp, copies);
					log.info("OCP_PRINT_ROUTE::Print request submitted to printer.TrackingID: {}", sanitize(trackingId));
					if (printResponse != null && printResponse.getResponse() != null) {
						log.info(
								"OCP_PRINT_ROUTE::Printer Response Received: {}", sanitize(printResponse.getResponse()));
						printResponseStatus = printResponse.getResponse().getStatus();
						log.info("OCP_PRINT_ROUTE::Printer Response HTTP Status: {}", printResponseStatus);

					}
					if (printResponseStatus != null && printResponseStatus == 200) {
						routeApiResponse = ApiResponse.ok(printRouteResponse);
						routeApiResponse.getResponse().setPrintStatus(printResponse.getResponse().getPrintJobStatus());
						routeApiResponse.getResponse().setPrinterName(printerName);
						routeApiResponse.getResponse().setPrinterIp(printerIp);
						routeApiResponse.getResponse().setLocationId(printerMetadata.getLocation());
						routeApiResponse.getResponse().setPrinterIp(printerMetadata.getIpAddress());
						routeApiResponse.getResponse().setPrintJobId(printResponse.getResponse().getPrintJobId());
						if (routeApiResponse.getResponse() != null) {
							log.info("OCP_PRINT_ROUTE_SUCCESS_RESP::RouteApiResponse.getResponse(): {}",
									sanitize(routeApiResponse.getResponse()));
						}
						log.info(
								"OCP_PRINT_ROUTE_SUCCESS::========== Print Request Routed to Printer Successfully ==========");
						return routeApiResponse;

					} else {						
						throw new PrintRouteResponseInvalidException("IPP Send Request failed");
					}
				}
			}

		} catch (PrintRouteInvalidArgumentException ex) {
			log.warn("OCP_PRINT_ROUTE_FAILED::========== Print Route failed==========", ex);
			throw new PrintRouteInvalidArgumentException(ex);
		}catch (Exception ex) {
			log.warn("OCP_PRINT_ROUTE_FAILED::========== Print Request Routed to Printer Failed ==========", ex);
			throw new PrintRouteException(ex);
		}

		return routeApiResponse;
	}

	/**
	 * Method to do Print.
	 * 
	 * @param printRouteResponse
	 * @param routeApiResponse
	 * @param itemNo
	 * @param documentName
	 * @param documentType
	 * @param trackingId
	 * @param printContent
	 * @param printerList
	 * @return
	 */

	public ApiResponse<PrintStatusResponse> doStatusCheck(Integer itemNo, String printerName, int jobId,
			String printerIp) {
		printerIp = approvedPrinterIp(printerName, printerIp);
		validateInput();
		PrintStatusResponse printRouteResponse = new PrintStatusResponse();
		ApiResponse<PrintStatusResponse> statusApiResponse = ApiResponse.init(printRouteResponse);
		try {
			if (printerName != null) {

				log.info("OCP_PRINT_STATUS::Sending IPP request to printer: {}", sanitize(printerName));
				Integer printResponseStatus = null;
				ApiResponse<PrinterIppResponse> printResponse = sendPrintJobStatusRequest(itemNo, printerName, jobId,
						printerIp);
				if (printResponse != null && printResponse.isSuccess()) {
					log.info("OCP_PRINT_STATUS::Job Statusrequest successfully submitted to printer.jobId:" + jobId
							+ "...");
				} else {
					log.info("OCP_PRINT_STATUS::Job Statusrequest failed to submit to printer.jobId:" + jobId + "...");
					throw new PrintStatusCheckInvalidResponseException("Print Job Status Enquiry Failed,JobId" + jobId);
				}
				if (printResponse != null && printResponse.getResponse() != null) {
					log.info("OCP_PRINT_STATUS::Printer Response Received: {}", sanitize(printResponse.getResponse()));
					printResponseStatus = printResponse.getResponse().getStatus();
					log.info("OCP_PRINT_STATUS::Printer Response HTTP Status: {}", printResponseStatus);

				}
				if (printResponseStatus != null && printResponseStatus == 200) {
					statusApiResponse = ApiResponse.ok(printRouteResponse);
					statusApiResponse.getResponse().setPrintJobStatus(printResponse.getResponse().getPrintJobStatus());
					statusApiResponse.getResponse().setPrinterName(printerName);
					statusApiResponse.getResponse().setPrinterIp(printerIp);
					statusApiResponse.getResponse().setPrintJobId(jobId);
					log.info("OCP_PRINT_STATUS_SUCCESS_RESP::RouteApiResponse.getResponse(): {}",
							sanitize(statusApiResponse.getResponse()));
					log.info(
							"OCP_PRINT_STATUS_SUCCESS::========== Print Status Request send to Printer Successfully ==========");
					return statusApiResponse;

				}
			}

		} catch (PrintStatusCheckInvalidResponseException exception) {
			log.warn("OCP_PRINT_STATUS_FAILED::========== Print Status Check Failed ==========",
					exception);
			throw exception;
		} catch (Exception exception) {
			log.warn("OCP_PRINT_STATUS_FAILED::========== Print Status Check request send to  Printer has been failed ==========",
					exception);
			throw new PrintStatusCheckException(exception);
		}

		return statusApiResponse;
	}

	private String approvedPrinterIp(String printerName, String printerIp) {
		PrinterEndpointPolicy.printerUri(printerIp);
		ApiResponse<ActiveDirectoryDiscoveryResponse> inventory = discoveryService.discoverPrintersByLocation(null);
		if (inventory == null || !inventory.isSuccess() || inventory.getResponse() == null
				|| inventory.getResponse().getPrinterList() == null) {
			throw new PrintStatusCheckException("Printer inventory is unavailable");
		}
		return inventory.getResponse().getPrinterList().stream()
				.filter(printer -> printer != null && printer.getPrinterName() != null
						&& printer.getPrinterName().equals(printerName) && printerIp.equals(printer.getIpAddress()))
				.map(PrinterMetadata::getIpAddress).findFirst()
				.orElseThrow(() -> new IllegalArgumentException("Printer name and address are not in the approved inventory"));
	}
     /**
      * Method to send Print Request
      * @param itemNo
      * @param printerName
      * @param printerJobName
      * @param docType
      * @param printContent
      * @param printerIp
      * @param copies
      * @return
      * @throws Exception
      */

	private ApiResponse<PrinterIppResponse> sendPrintRequest(int itemNo, String printerName, String printerJobName,
			String docType, String printContent, String printerIp, int copies) throws Exception {		

		byte[] ippRequest = buildIppPrintRequest(itemNo, printerName, printerJobName, docType, printContent, printerIp,
				copies);

		HttpRequest httpRequest = buildHttpRequest(ippRequest, printerIp);

		log.info("Sending IPP request...");
		log.info("Request Id      : {}", itemNo);
		log.info("Printer Name    : {}", sanitize(printerName));
		log.info("Print Job Name  : {}", sanitize(printerJobName));
		//log.info("Queue URL       : {}", sanitize(properties.getQueueUrl()));

		HttpResponse<byte[]> httpResponse;
		try (HttpClient client = httpClient(httpRequest.uri())) {
			httpResponse = client.send(httpRequest, HttpResponse.BodyHandlers.ofByteArray());
		}

		log.info("HTTP Status: {}", httpResponse.statusCode());

		httpResponse.headers().map().forEach((name, values) ->
				log.info("Header: {}={}", sanitize(name), sanitize(values)));

		if (httpResponse.statusCode() == 401) {

			String responseBody = new String(httpResponse.body(), StandardCharsets.UTF_8);

			log.error("Authentication failed.");
			log.error("Response Body: {}", sanitize(responseBody));

			return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(),
					"Authentication failed. Server returned HTTP 401.", HttpStatus.UNAUTHORIZED.value());
		}

		PrinterIppResponse printerResponse = processResponse(httpResponse, itemNo, "PRINT_REQUEST");

		if (printerResponse.isOk()) {
			return ApiResponse.ok(printerResponse);
		}

		return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), printerResponse.getMessage(),
				getFailureHttpStatus(printerResponse));

	}

	/**
	 * Sends the configured plain-text content to the configured IPP queue.
	 * 
	 * @param itemNo
	 * @param printerName
	 * @param printerJobName
	 * @return
	 */
	private ApiResponse<PrinterIppResponse> sendPrintJobStatusRequest(int itemNo, String printerName, int jobId,
			String printerIp) throws Exception {
		
		byte[] ippRequest = buildIppPrintJobStatusRequest(itemNo, printerName, jobId, printerIp);

		HttpRequest httpRequest = buildHttpRequest(ippRequest, printerIp);

		HttpResponse<byte[]> httpResponse;
		try (HttpClient client = httpClient(httpRequest.uri())) {
			httpResponse = client.send(httpRequest, HttpResponse.BodyHandlers.ofByteArray());
		}

		PrinterIppResponse printerResponse = processResponse(httpResponse, itemNo, "STATUS_REQUEST");

		if (printerResponse.isOk()) {
			return ApiResponse.ok(printerResponse);
		}

		return ApiResponse.failures(ErrorCode.INVALID_REQUEST.getCode(), printerResponse.getMessage(),
				getFailureHttpStatus(printerResponse));

	}

	/**
	 * Method to build Get Job Status Ipp Request.
	 * 
	 * @param requestId
	 * @param printerName
	 * @param jobId
	 * @return
	 * @throws IOException
	 */
	private byte[] buildIppPrintJobStatusRequest(int itemNo, String printerName, int jobId, String printerIp)
			throws Exception {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		try (DataOutputStream output = new DataOutputStream(buffer)) {
			// IPP Version 1.1
			output.writeByte(0x01);
			output.writeByte(0x01);
			// Get-Job-Attributes
			output.writeShort(GET_JOB_ATTRIBUTES_OPERATION_ID);
			output.writeInt(itemNo);
			output.writeByte(OPERATION_ATTRIBUTES_TAG);
			writeStringAttribute(output, CHARSET_TAG, "attributes-charset", "utf-8");
			writeStringAttribute(output, NATURAL_LANGUAGE_TAG, "attributes-natural-language", "en");
			writeStringAttribute(output, URI_TAG, "printer-uri", PrinterEndpointPolicy.printerUri(printerIp).toString());

			// Job ID to query
			writeIntegerAttribute(output, 0x21, "job-id", jobId);
			// Request only required status attribute
			writeStringAttribute(output, KEYWORD_TAG, "requested-attributes", "job-state");
			output.writeByte(END_OF_ATTRIBUTES_TAG);
			output.flush();
		}

		return buffer.toByteArray();
	}


	private HttpRequest buildHttpRequest(byte[] ippRequest, String printerIp) throws Exception {

		URI destination = PrinterEndpointPolicy.printerUri(printerIp);
		log.info("IPP Endpoint: {}", destination);
		return HttpRequest.newBuilder().uri(destination)
				.timeout(Duration.ofSeconds(properties.getRequestTimeoutSeconds()))
				.header("Content-Type", "application/ipp").header("Accept", "application/ipp")
				.POST(HttpRequest.BodyPublishers.ofByteArray(ippRequest)).build();
	}

	
	/**
	 * Method to build Request.
	 * 
	 * @param itemNumber
	 * @param printerName
	 * @param printJobName
	 * @return
	 * @throws IOException
	 */
	private byte[] buildIppPrintRequest(int itemNumber, String printerName, String printJobName, String documentType,
			String printContent, String printerIp, int copies) throws Exception {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();

		try (DataOutputStream output = new DataOutputStream(buffer)) {

			output.writeByte(0x01);
			output.writeByte(0x01);

			output.writeShort(PRINT_JOB_OPERATION_ID);
			output.writeInt(itemNumber);

			output.writeByte(OPERATION_ATTRIBUTES_TAG);

			writeStringAttribute(output, CHARSET_TAG, "attributes-charset", "utf-8");

			writeStringAttribute(output, NATURAL_LANGUAGE_TAG, "attributes-natural-language", "en");

			writeStringAttribute(output, URI_TAG, "printer-uri", PrinterEndpointPolicy.printerUri(printerIp).toString());

			writeStringAttribute(output, NAME_WITHOUT_LANGUAGE_TAG, "requesting-user-name",
					properties.getRequestingUser());

			writeStringAttribute(output, NAME_WITHOUT_LANGUAGE_TAG, "job-name", properties.getJobName() + printJobName);

			writeStringAttribute(output, MIME_MEDIA_TYPE_TAG, "document-format", "text/plain");

			// START JOB ATTRIBUTES GROUP
			output.writeByte(0x02);

			writeIntegerAttribute(output, 0x21, "copies", copies);

			output.writeByte(END_OF_ATTRIBUTES_TAG);

			// output.write(properties.getPrintContent().getBytes(StandardCharsets.UTF_8));

			byte[] documentBytes = getDocumentBytes(documentType, printContent);

			output.write(documentBytes);

			output.flush();
		}

		return buffer.toByteArray();
	}

	/**
	 * Method to get document Types.
	 * 
	 * @param documentType
	 * @param printContent
	 * @return
	 */
	private byte[] getDocumentBytes(String documentType, String printContent) throws Exception {
		byte[] documentBytes = null;

		if (DocumentType.PDF.name().equalsIgnoreCase(documentType)) {

			// PDF bytes were stored in String
			// Recover original bytes using ISO-8859-1
			documentBytes = printContent.getBytes(StandardCharsets.ISO_8859_1);

		} else if (DocumentType.ZPL.name().equalsIgnoreCase(documentType)) {

			// ZPL text
			documentBytes = printContent.getBytes(StandardCharsets.UTF_8);

		} else {

			// Fallback
			documentBytes = printContent.getBytes(StandardCharsets.UTF_8);
		}
		return documentBytes;
	}

	/**
	 * Method to write String Attribute.
	 * @param output
	 * @param valueTag
	 * @param attributeName
	 * @param attributeValue
	 * @throws IOException
	 */
	private void writeStringAttribute(DataOutputStream output, int valueTag, String attributeName,
			String attributeValue) throws Exception {
		byte[] nameBytes = attributeName.getBytes(StandardCharsets.US_ASCII);

		byte[] valueBytes = attributeValue.getBytes(StandardCharsets.UTF_8);

		output.writeByte(valueTag);

		output.writeShort(nameBytes.length);
		output.write(nameBytes);

		output.writeShort(valueBytes.length);
		output.write(valueBytes);
	}

	/**
	 * Method to write Integer Attribute
	 * 
	 * @param output
	 * @param valueTag
	 * @param attributeName
	 * @param value
	 * @throws IOException
	 */

	private void writeIntegerAttribute(DataOutputStream output, int valueTag, String attributeName, int value)
			throws Exception {

		output.writeByte(valueTag); // 0x21 = integer

		byte[] nameBytes = attributeName.getBytes(StandardCharsets.US_ASCII);
		output.writeShort(nameBytes.length);
		output.write(nameBytes);

		output.writeShort(4); // integer value length
		output.writeInt(value);
	}

	/**
	 * Method to process Response.
	 * @param response
	 * @param itemNumber
	 * @param reqType
	 * @return
	 */
	private PrinterIppResponse processResponse(HttpResponse<byte[]> response, int itemNumber, String reqType) throws Exception {
		int httpStatus = response.statusCode();
		byte[] responseBody = response.body();

		if (httpStatus == HttpStatus.UNAUTHORIZED.value()) {
			String authenticationScheme = response.headers().firstValue("WWW-Authenticate").orElse("Not provided");

			return buildPrinterResponse(httpStatus, null, itemNumber,
					"HTTP authentication failed. Scheme: " + authenticationScheme, false, null);
		}

		if (httpStatus == HttpStatus.FORBIDDEN.value()) {
			return buildPrinterResponse(httpStatus, null, itemNumber, "User is not authorized to print to this queue",
					false, null);
		}

		if (httpStatus == HttpStatus.NOT_FOUND.value()) {
			return buildPrinterResponse(httpStatus, null, itemNumber, "IPP queue URL was not found", false, null);
		}

		if (httpStatus < 200 || httpStatus >= 300) {
			return buildPrinterResponse(httpStatus, null, itemNumber,
					"IPP HTTP request failed with status " + httpStatus, false, null);
		}

		if (responseBody == null || responseBody.length < MINIMUM_IPP_RESPONSE_LENGTH) {
			return buildPrinterResponse(httpStatus, null, itemNumber,
					"HTTP request succeeded, but the response " + "is not a valid IPP response", false, null);
		}

		int ippMajorVersion = responseBody[0] & 0xFF;
		int ippMinorVersion = responseBody[1] & 0xFF;

		int ippStatus = ((responseBody[2] & 0xFF) << 8) | (responseBody[3] & 0xFF);

		int responseRequestId = ((responseBody[4] & 0xFF) << 24) | ((responseBody[5] & 0xFF) << 16)
				| ((responseBody[6] & 0xFF) << 8) | (responseBody[7] & 0xFF);

		if (responseRequestId != itemNumber) {
			return buildPrinterResponse(httpStatus, ippStatus, responseRequestId,
					"IPP response request ID mismatch. Expected: " + itemNumber + ", received: " + responseRequestId,
					false, null);
		}

		String statusMessage = "IPP version: " + ippMajorVersion + "." + ippMinorVersion + ", status: "
				+ String.format("0x%04X", ippStatus) + " " + getIppStatusDescription(ippStatus);

		if (ippStatus <= 0x00FF) { // 200-OK
			Integer jobId = extractJobId(responseBody);
			Integer jobState = null;
			if (reqType.equalsIgnoreCase("PRINT_REQUEST")) {
				jobState = extractJobStateOfPrintRequest(responseBody);
			} else if (reqType.equalsIgnoreCase("STATUS_REQUEST")) {
				jobState = extractJobStateOfJobStatusRequest(responseBody);
			}
			PrinterIppResponse responseObj = buildPrinterResponse(httpStatus, ippStatus, responseRequestId,
					"Print job accepted. " + statusMessage, true, jobId);
			if (jobState != null) {
				responseObj.setPrintJobStatus(getJobStateDescription(jobState));
			}
			return responseObj;
		}

		return buildPrinterResponse(httpStatus, ippStatus, responseRequestId, "Print job rejected. " + statusMessage,
				false, null);
	}

	/**
	 * Method to get Job description.
	 * 
	 * @param state
	 * @return
	 */
	private String getJobStateDescription(Integer state) throws Exception {

		if (state == null) {
			return null;
		}

		switch (state) {
		case 3:
			return "PENDING";

		case 4:
			return "PENDING_HELD";

		case 5:
			return "PROCESSING";

		case 6:
			return "STOPPED";

		case 7:
			return "CANCELED";

		case 8:
			return "ABORTED";

		case 9:
			return "COMPLETED";

		default:
			return "UNKNOWN(" + state + ")";
		}
	}

	/**
	 * Method to get job state.
	 * 
	 * @param ippResponse
	 * @return
	 */

	private Integer extractJobStateOfPrintRequest(byte[] ippResponse) throws Exception {

			for (int i = 0; i < ippResponse.length - 20; i++) {

				if ((ippResponse[i] & 0xFF) == 0x23) { // enum value tag

					int nameLength = ((ippResponse[i + 1] & 0xFF) << 8) | (ippResponse[i + 2] & 0xFF);

					if (nameLength <= 0 || i + 3 + nameLength >= ippResponse.length) {
						continue;
					}

					String attributeName = new String(ippResponse, i + 3, nameLength, StandardCharsets.US_ASCII);

					if ("job-state".equals(attributeName)) {

						int valueLengthIndex = i + 3 + nameLength;

						int valueLength = ((ippResponse[valueLengthIndex] & 0xFF) << 8)
								| (ippResponse[valueLengthIndex + 1] & 0xFF);

						if (valueLength == 4) {

							int valueIndex = valueLengthIndex + 2;

							return ((ippResponse[valueIndex] & 0xFF) << 24)
									| ((ippResponse[valueIndex + 1] & 0xFF) << 16)
									| ((ippResponse[valueIndex + 2] & 0xFF) << 8)
									| (ippResponse[valueIndex + 3] & 0xFF);
						}
					}
				}
			}

		

		return null;
	}

	/**
	 * Method to extract Job State.
	 * @param ippResponse
	 * @return
	 */
	private Integer extractJobStateOfJobStatusRequest(byte[] ippResponse) throws Exception {
		
			String responseText = new String(ippResponse, StandardCharsets.ISO_8859_1);

			int pos = responseText.indexOf("job-state");

			if (pos < 0) {
				return null;
			}

			int valueLengthIndex = pos + "job-state".length();

			while (valueLengthIndex < ippResponse.length && ippResponse[valueLengthIndex] != 0x04) {
				valueLengthIndex++;
			}

			if (valueLengthIndex + 4 >= ippResponse.length) {
				return null;
			}

			return ((ippResponse[valueLengthIndex + 1] & 0xFF) << 24)
					| ((ippResponse[valueLengthIndex + 2] & 0xFF) << 16)
					| ((ippResponse[valueLengthIndex + 3] & 0xFF) << 8) | (ippResponse[valueLengthIndex + 4] & 0xFF);

		
	}

	/**
	 * Method to get jobId.
	 * 
	 * @param ippResponse
	 * @return
	 */
	private Integer extractJobId(byte[] ippResponse) throws Exception {

		int pos = 8; // Skip IPP header

		while (pos < ippResponse.length) {

			int tag = ippResponse[pos++] & 0xFF;

			if (tag == 0x03) { // end-of-attributes-tag
				break;
			}

			if (tag <= 0x0F) {
				continue; // delimiter tags
			}

			if (pos + 2 > ippResponse.length)
				break;

			int nameLength = ((ippResponse[pos] & 0xFF) << 8) | (ippResponse[pos + 1] & 0xFF);
			pos += 2;

			if (pos + nameLength > ippResponse.length)
				break;

			String name = new String(ippResponse, pos, nameLength, java.nio.charset.StandardCharsets.UTF_8);
			pos += nameLength;

			int valueLength = ((ippResponse[pos] & 0xFF) << 8) | (ippResponse[pos + 1] & 0xFF);
			pos += 2;

			if (pos + valueLength > ippResponse.length)
				break;

			if ("job-id".equals(name) && valueLength == 4) {
				return ((ippResponse[pos] & 0xFF) << 24) | ((ippResponse[pos + 1] & 0xFF) << 16)
						| ((ippResponse[pos + 2] & 0xFF) << 8) | (ippResponse[pos + 3] & 0xFF);
			}

			pos += valueLength;
		}

		return null;
	}
	
	/**
	 * Method to build printer.
	 * @param httpStatus
	 * @param ippStatus
	 * @param requestId
	 * @param message
	 * @param success
	 * @param printJobId
	 * @return
	 */

	private PrinterIppResponse buildPrinterResponse(int httpStatus, Integer ippStatus, int requestId, String message,
			boolean success, Integer printJobId) throws Exception {
		PrinterIppResponse response = new PrinterIppResponse();
		response.setOk(success);
		// data.setTransId("TXN12345");
		response.setStatus(httpStatus);
		response.setMessage(message);
		// response.setPrinterName("Zebra-01");
		response.setPrintJobId(printJobId);
		// response.setPrintJobStatus("SUBMITTED");
		return response;
	}

	/**
	 * Method get Failure HttP Status.
	 * @param printerResponse
	 * @return
	 * @throws Exception
	 */
	private int getFailureHttpStatus(PrinterIppResponse printerResponse) throws Exception {
		int status = printerResponse.getStatus();

		if (status >= 400 && status <= 599) {
			return status;
		}

		return HttpStatus.BAD_GATEWAY.value();
	}

	
	/**
	 * Method to get Ipp Status.
	 * @param ippStatus
	 * @return
	 */
	private String getIppStatusDescription(int ippStatus) {
		return switch (ippStatus) {
		case 0x0000 -> "successful-ok";
		case 0x0001 -> "successful-ok-ignored-or-substituted-attributes";
		case 0x0002 -> "successful-ok-conflicting-attributes";
		case 0x0400 -> "client-error-bad-request";
		case 0x0401 -> "client-error-forbidden";
		case 0x0402 -> "client-error-not-authenticated";
		case 0x0403 -> "client-error-not-authorized";
		case 0x0404 -> "client-error-not-possible";
		case 0x0406 -> "client-error-not-found";
		case 0x040A -> "client-error-document-format-not-supported";
		case 0x0500 -> "server-error-internal-error";
		case 0x0501 -> "server-error-operation-not-supported";
		case 0x0502 -> "server-error-service-unavailable";
		case 0x0503 -> "server-error-version-not-supported";
		default -> String.format("unknown-ipp-status-0x%04X", ippStatus);
		};
	}

	/**
	 * Method to validate Input.
	 */
	private void validateInput() {
//		if (isBlank(properties.getQueueUrl())) {
//			throw new IllegalArgumentException("Queue URL must not be empty");
//		}

//		URI queueUri;

//		try {
//			queueUri = URI.create(properties.getQueueUrl());
//		} catch (IllegalArgumentException exception) {
//			throw new IllegalArgumentException("Queue URL is invalid", exception);
//		}

//		String scheme = queueUri.getScheme();
//
//		if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
//			throw new IllegalArgumentException("Queue URL must use HTTP or HTTPS");
//		}
//
//		if (isBlank(queueUri.getHost())) {
//			throw new IllegalArgumentException("Queue URL must contain a valid host");
//		}
//
//		if (isBlank(queueUri.getPath()) || "/".equals(queueUri.getPath())) {
//			throw new IllegalArgumentException("Queue URL must contain an IPP queue path");
//		}

		if (isBlank(properties.getRequestingUser())) {
			throw new IllegalArgumentException("Requesting user must not be empty");
		}

//		if (isBlank(properties.getDomainUsername())) {
//			throw new IllegalArgumentException("Authentication username must not be empty");
//		}
//
//		if (isBlank(properties.getPassword())) {
//			throw new IllegalArgumentException("Authentication password must not be empty");
//		}

		if (isBlank(properties.getJobName())) {
			throw new IllegalArgumentException("Job name must not be empty");
		}

		if (isBlank(properties.getPrintContent())) {
			throw new IllegalArgumentException("Print content must not be empty");
		}

		if (properties.getConnectTimeoutSeconds() <= 0) {
			throw new IllegalArgumentException("Connect timeout must be greater than zero");
		}

		if (properties.getRequestTimeoutSeconds() <= 0) {
			throw new IllegalArgumentException("Request timeout must be greater than zero");
		}
	}

	/**
	 * Method to check is Blank.
	 * @param value
	 * @return
	 */
	private boolean isBlank(String value) {
		return value == null || value.isBlank();
	}
	
	

	
}