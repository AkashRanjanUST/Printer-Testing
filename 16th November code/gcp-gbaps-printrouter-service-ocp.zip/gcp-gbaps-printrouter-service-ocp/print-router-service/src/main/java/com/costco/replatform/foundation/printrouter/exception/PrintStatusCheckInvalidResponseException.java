package com.costco.replatform.foundation.printrouter.exception;

public class PrintStatusCheckInvalidResponseException extends RuntimeException {

	
	 public PrintStatusCheckInvalidResponseException() {
	        super();
	    }

	    public PrintStatusCheckInvalidResponseException(String message) {
	        super(message);
	    }

	    public PrintStatusCheckInvalidResponseException(String message, Throwable cause) {
	        super(message, cause);
	    }

	    public PrintStatusCheckInvalidResponseException(Throwable cause) {
	        super(cause);
	    }
	    
	
}
