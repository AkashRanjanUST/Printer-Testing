package com.costco.replatform.foundation.printrouter.util;

import java.io.IOException;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.URL;
import java.util.Arrays;

public final class PrinterEndpointPolicy {

    private PrinterEndpointPolicy() {
    }

    public static URI discoveryUri(String targetUrl, String printerPath, String allowedHosts) {
        URI base = URI.create(targetUrl);
        String host = base.getHost();
        if (!isHttp(base) || host == null || base.getRawUserInfo() != null
                || base.getRawQuery() != null || base.getRawFragment() != null
                || !(base.getRawPath().isEmpty() || "/".equals(base.getRawPath()))
                || !(base.getPort() == -1 || base.getPort() == 80
                        || base.getPort() == 443 || base.getPort() == 631)) {
            throw new IllegalArgumentException("Invalid print server origin");
        }
        if (allowedHosts == null || Arrays.stream(allowedHosts.split(","))
                .map(String::trim).noneMatch(host::equalsIgnoreCase)) {
            throw new IllegalArgumentException("Print server host is not approved");
        }

        URI path = URI.create(printerPath);
        String decodedPath = path.getPath();
        if (path.isAbsolute() || path.getRawAuthority() != null
                || path.getRawQuery() != null || path.getRawFragment() != null
                || decodedPath == null || !decodedPath.startsWith("/printers/")
                || decodedPath.contains("\\") || decodedPath.contains("//")
                || decodedPath.contains("%")
                || decodedPath.codePoints().anyMatch(Character::isISOControl)
                || Arrays.stream(decodedPath.split("/")).anyMatch(segment ->
                        ".".equals(segment) || "..".equals(segment))) {
            throw new IllegalArgumentException("Invalid printer queue path");
        }
        return base.resolve(path);
    }

    public static HttpURLConnection openDiscoveryConnection(String targetUrl, String printerPath,
            String allowedHosts, String username, String password) throws IOException {
        URI destination = discoveryUri(targetUrl, printerPath, allowedHosts);
        HttpURLConnection connection = (HttpURLConnection) destination.toURL().openConnection();
        connection.setInstanceFollowRedirects(false);
        connection.setAuthenticator(authenticator(destination, username, password));
        return connection;
    }

    public static URI printerUri(String ipAddress) {
        if (ipAddress == null || !ipAddress.matches(
                "(?:0|[1-9][0-9]{0,2})(?:\\.(?:0|[1-9][0-9]{0,2})){3}")) {
            throw new IllegalArgumentException("Printer address must be an IPv4 literal");
        }
        String[] parts = ipAddress.split("\\.");
        byte[] address = new byte[4];
        for (int i = 0; i < parts.length; i++) {
            int octet = Integer.parseInt(parts[i]);
            if (octet > 255) {
                throw new IllegalArgumentException("Invalid printer IPv4 address");
            }
            address[i] = (byte) octet;
        }
        try {
            InetAddress parsed = InetAddress.getByAddress(address);
            if (parsed.isAnyLocalAddress() || parsed.isLoopbackAddress() || parsed.isLinkLocalAddress()
                    || parsed.isMulticastAddress() || (address[0] & 0xff) >= 240
                    || address[0] == 0) {
                throw new IllegalArgumentException("Printer address is not an allowed unicast address");
            }
        } catch (java.net.UnknownHostException ex) {
            throw new IllegalArgumentException("Invalid printer IPv4 address", ex);
        }
        return URI.create("http://" + ipAddress);
    }

    public static Authenticator authenticator(URI destination, String username, String password) {
        return new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                URL requestingUrl = getRequestingURL();
                if (getRequestorType() != RequestorType.SERVER || requestingUrl == null
                        || !destination.getScheme().equalsIgnoreCase(requestingUrl.getProtocol())
                        || !destination.getHost().equalsIgnoreCase(requestingUrl.getHost())
                        || effectivePort(destination) != (requestingUrl.getPort() == -1
                                ? requestingUrl.getDefaultPort() : requestingUrl.getPort())) {
                    return null;
                }
                return new PasswordAuthentication(username, password.toCharArray());
            }
        };
    }

    private static boolean isHttp(URI uri) {
        return "http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme());
    }

    private static int effectivePort(URI uri) {
        return uri.getPort() == -1 ? ("https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80) : uri.getPort();
    }
}
