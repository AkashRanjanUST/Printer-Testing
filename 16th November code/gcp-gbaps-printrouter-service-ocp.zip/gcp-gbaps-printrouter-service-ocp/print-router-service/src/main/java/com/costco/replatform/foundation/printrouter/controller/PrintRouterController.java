package com.costco.replatform.foundation.printrouter.controller;

import static com.costco.replatform.foundation.printrouter.util.LogSanitizer.sanitize;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.costco.replatform.foundation.printrouter.model.ActiveDirectoryDiscoveryResponse;
import com.costco.replatform.foundation.printrouter.model.ApiRequest;
import com.costco.replatform.foundation.printrouter.model.ApiResponse;
import com.costco.replatform.foundation.printrouter.model.PrintMetadata;
import com.costco.replatform.foundation.printrouter.model.PrintRouteRequest;
import com.costco.replatform.foundation.printrouter.model.PrintRouteResponse;
import com.costco.replatform.foundation.printrouter.model.PrintStatusRequest;
import com.costco.replatform.foundation.printrouter.model.PrintStatusResponse;
import com.costco.replatform.foundation.printrouter.model.PrinterMetadata;
import com.costco.replatform.foundation.printrouter.service.ActiveDirectoryDiscoveryService;
import com.costco.replatform.foundation.printrouter.service.PrinterConnectivityService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "OpenShift Print APIs", description = "Operations related to Print Processing and Print Dashboard hosted in OpenShift")
@RestController
@RequestMapping("/${app.url.api.name}/v1/printroute")
public class PrintRouterController {

	private final ActiveDirectoryDiscoveryService activeDirectoryDiscoveryService;

	private final PrinterConnectivityService printService;

	public PrintRouterController(ActiveDirectoryDiscoveryService activeDirectoryDiscoveryService,
			PrinterConnectivityService delegateService) {
		this.activeDirectoryDiscoveryService = activeDirectoryDiscoveryService;
		this.printService = delegateService;
	}

	private static final Logger log = LoggerFactory.getLogger(PrintRouterController.class);

	/**
	 * Controller method to route to right printer added in print server.
	 * 
	 * @param apiRequest containing the PrintRequest payload
	 * @return
	 */
	@Operation(summary = "Route Print Request to Printer.")
	@ApiResponses({
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Print request processed successfully"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid print request"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "401", description = "Unauthorized exception"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "403", description = "Forbidden request"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Data Not found"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "422", description = "Unprocessable Content"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Internal server error"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "501", description = "Not Implemented"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "502", description = "Bad Gatewayr"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "503", description = "Service Unavailable"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "504", description = "Gateway Timeout") })
	@PostMapping("/send")
	public ResponseEntity<ApiResponse<PrintRouteResponse>> routePrint(
			@RequestBody ApiRequest<PrintRouteRequest> apiRequest) {

		log.info("OCP_PRINT_ROUTE Starting");
		PrintRouteResponse printRouteResponse = new PrintRouteResponse();
		ApiResponse<PrintRouteResponse> routeApiResponse = ApiResponse.init(printRouteResponse);
		Integer itemNo = 0;
		Integer printCopies = 1;
		String documentName = null;
		String documentType = null;
		String trackingId = null;
		String locationId = null;
		String printContent = null;

		if (apiRequest != null) {
			String uiRequestId = apiRequest.getRequestId();
			PrintRouteRequest request = apiRequest.getRequest();
			if (request != null) {
				PrintMetadata metaData = request.getPrintMetadata();
				if (metaData != null) {
					printContent = metaData.getFilecontent();
					printCopies = metaData.getCopies();
					documentName = metaData.getDocumentName();
					documentType = metaData.getDocumentType().name();
					itemNo = metaData.getItemNo();
					locationId = metaData.getLocationId();
					String printerType = metaData.getPrinterType().name();
					String printType = metaData.getPrintType().name();
					String requestedUser = metaData.getRequestedUser();
					String requestTime = metaData.getRequestTime();
					trackingId = metaData.getTrackingId();
					log.info(
							"OCP_PRINT_ROUTE_REQ_DETAILS -> itemNo: {}, printCopies: {}, documentName: {}, trackingId: {}, locationId: {}, "
									+ "documentType: {}, printerType: {}, printType: {}, requestedUser: {}, requestTime: {}, uiRequestId: {}",
							itemNo, printCopies, sanitize(documentName), sanitize(trackingId), sanitize(locationId),
							documentType, printerType, printType, sanitize(mask(requestedUser)), sanitize(requestTime),
							sanitize(uiRequestId));

				}
			}

			// PrintRouteRequest printRequest = apiRequest.getRequest();
			ApiResponse<ActiveDirectoryDiscoveryResponse> discoveryApiResponse = activeDirectoryDiscoveryService
					.discoverPrintersByLocation(locationId);// "01680/LA/WHS/MGROFC"
			log.info("OCP_PRINT_ROUTE_DISCOVERY_RESP:: AD Discovery Response : {}", sanitize(discoveryApiResponse));
			List<PrinterMetadata> printerList = discoveryApiResponse.getResponse().getPrinterList();
			if (!CollectionUtils.isEmpty(printerList)) {
				routeApiResponse = printService.doPrint(itemNo, documentName, documentType, trackingId, printContent,
						printerList, printCopies);
				log.info("OCP_PRINT_ROUTE_RESPONSE::Print Response: {}", sanitize(routeApiResponse));
				return ResponseEntity.ok().body(routeApiResponse);
			} else if (CollectionUtils.isEmpty(printerList)) {
				log.info("OCP_PRINT_ROUTE::FAILED::Bad Request:: No Printers in requested location.");
				routeApiResponse.setErrorStatus("404");
				routeApiResponse.setMessage("No Printers in requested location");
				return ResponseEntity.badRequest().body(routeApiResponse);
			}

		} else {
			log.info("OCP_PRINT_ROUTE::FAILED::Bad Request:: API request is null.");
			routeApiResponse.setErrorStatus("400");
			routeApiResponse.setMessage("API request is null.");
			return ResponseEntity.badRequest().body(routeApiResponse);
		}
		return null;
	}

	/**
	 * Controller method to route to right printer added in print server.
	 * 
	 * @param apiRequest containing the PrintRequest payload
	 * @return
	 */

	@Operation(summary = "Get Job Status from Printer.")
	@ApiResponses({
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Print Job Status retrieved successfully"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Bad Request"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "401", description = "Unauthorized exception"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "403", description = "Forbidden request"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Data Not found"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "422", description = "Unprocessable Content"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Internal server error"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "501", description = "Not Implemented"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "502", description = "Bad Gatewayr"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "503", description = "Service Unavailable"),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "504", description = "Gateway Timeout")

	})
	@PostMapping("/status")
	public ResponseEntity<ApiResponse<PrintStatusResponse>> getPrintStatus(
			@RequestBody ApiRequest<PrintStatusRequest> apiRequest) {

		log.info("OCP_PRINT_ROUTE Starting");
		PrintStatusResponse printRouteResponse = new PrintStatusResponse();
		ApiResponse<PrintStatusResponse> statusResponse = ApiResponse.init(printRouteResponse);
		if (apiRequest != null) {
			String uiRequestId = apiRequest.getRequestId();
			PrintStatusRequest request = apiRequest.getRequest();
			if (request != null) {
				log.info("OCP_PRINT_STATUS_REQ_DETAILS -> itemNo: {}, printerName: {}, printJobId: {}, uiRequestId: {}",
						request.getItemNo(), sanitize(request.getPrinterName()), request.getPrintJobId(),
						sanitize(uiRequestId));

				// PrintRouteRequest printRequest = apiRequest.getRequest();
//			ApiResponse<ActiveDirectoryDiscoveryResponse> discoveryApiResponse = activeDirectoryDiscoveryService
//					.discoverPrintersByLocation(locationId);// "01680/LA/WHS/MGROFC"
//			log.info("OCP_PRINT_ROUTE_DISCOVERY_RESP:: AD Discovery Response : {}", discoveryApiResponse);
//			List<PrinterMetadata> printerList = discoveryApiResponse.getResponse().getPrinterList();
//			if (!CollectionUtils.isEmpty(printerList)) {
//				routeApiResponse = printService.doPrint(itemNo, documentName, documentType, trackingId, printContent,
//						printerList);
//			}
				statusResponse = printService.doStatusCheck(request.getItemNo(), request.getPrinterName(),
						request.getPrintJobId(), request.getPrinterIp());
			}
			log.info("OCP_PRINT_STATUS_SUCCESS::Status Request Requested Successfully: {}", sanitize(statusResponse));
			return ResponseEntity.ok().body(statusResponse);
		} else {
			log.info("OCP_PRINT_ROUTE::FAILED::Bad Request:: API request is null.");
			return ResponseEntity.badRequest().body(statusResponse);
		}
	}

	/**
	 * Method to mask sensitive userId
	 * 
	 * @param data
	 * @return
	 */
	private static String mask(String data) {
		if (data == null || data.isBlank()) {
			return data;
		}

		if (data.length() <= 2) {
			return "*".repeat(data.length());
		}

		return data.charAt(0) + "*".repeat(data.length() - 2) + data.charAt(data.length() - 1);
	}
}
