package com.costco.replatform.foundation.printrouter.exception;

public class PrintRouteResponseInvalidException extends RuntimeException {
	
	 public PrintRouteResponseInvalidException() {
	        super();
	    }

	    public PrintRouteResponseInvalidException(String message) {
	        super(message);
	    }

	    public PrintRouteResponseInvalidException(String message, Throwable cause) {
	        super(message, cause);
	    }

	    public PrintRouteResponseInvalidException(Throwable cause) {
	        super(cause);
	    }
	    


}
