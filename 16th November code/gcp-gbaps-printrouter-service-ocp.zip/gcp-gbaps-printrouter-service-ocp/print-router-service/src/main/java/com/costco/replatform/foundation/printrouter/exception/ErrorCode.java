package com.costco.replatform.foundation.printrouter.exception;

public enum ErrorCode {

    // ────────────── Request Validation ──────────────
    INVALID_REQUEST("PRT_001", "The request is invalid."),
    MISSING_REQUIRED_FIELD("PRT_002", "A required field is missing."),
    INVALID_INPUT_FORMAT("PRT_003", "The input format is invalid."),
    INVALID_PRINTER_IP("PRT_004", "The printer IP address is invalid."),
    INVALID_PRINTER_URI("PRT_005", "The printer URI is invalid."),
    INVALID_PRINT_JOB_ID("PRT_006", "The print job ID is invalid."),

    // ────────────── Printer / IPP Errors ──────────────
    PRINTER_NOT_FOUND("PRT_100", "The specified printer was not found."),
    PRINTER_UNREACHABLE("PRT_101", "Unable to connect to the printer."),
    PRINTER_UNAVAILABLE("PRT_102", "The printer is currently unavailable."),
    PRINTER_BUSY("PRT_103", "The printer is currently busy."),
    PRINT_JOB_NOT_FOUND("PRT_104", "The requested print job was not found."),
    PRINT_JOB_REJECTED("PRT_105", "The printer rejected the print job."),
    PRINT_JOB_CANCELLED("PRT_106", "The print job was cancelled."),
    PRINT_JOB_FAILED("PRT_107", "The print job failed."),

    // ────────────── IPP Protocol Errors ──────────────
    IPP_REQUEST_FAILED("PRT_200", "IPP request processing failed."),
    IPP_BAD_REQUEST("PRT_201", "IPP request is invalid."),
    IPP_UNSUPPORTED_ATTRIBUTE("PRT_202", "IPP attribute is not supported."),
    IPP_RESPONSE_PARSE_ERROR("PRT_203", "Unable to parse IPP response."),
    IPP_VERSION_NOT_SUPPORTED("PRT_204", "IPP version is not supported."),

    // ────────────── Security / SSL ──────────────
    SSL_HANDSHAKE_FAILED("PRT_300", "SSL handshake failed."),
    CERTIFICATE_VALIDATION_FAILED("PRT_301", "Certificate validation failed."),
    TRUSTSTORE_CONFIGURATION_ERROR("PRT_302", "Truststore configuration error."),
    LDAP_AUTHENTICATION_FAILED("PRT_303", "LDAP authentication failed."),
    LDAP_CONNECTION_FAILED("PRT_304", "LDAP connection failed."),

    // ────────────── Authorization / Security ──────────────
    UNAUTHORIZED("PRT_400", "Unauthorized access."),
    FORBIDDEN("PRT_401", "Access is forbidden."),

    // ────────────── Network / Integration ──────────────
    CONNECTION_TIMEOUT("PRT_500", "Connection timed out."),
    READ_TIMEOUT("PRT_501", "Response timed out."),
    SERVICE_UNAVAILABLE("PRT_502", "Service unavailable."),
    DOWNSTREAM_SERVICE_FAILURE("PRT_503", "Downstream service failure."),

    // ────────────── Business Response ──────────────
    SERVICE_RESULT("PRT_600", "Business response returned successfully."),

    // ────────────── Unexpected Errors ──────────────
    ILLEGAL_ARGUMENT("PRT_900", "Invalid argument."),
    INTERNAL_SERVER_ERROR("PRT_999", "Unexpected internal server error.");

    private final String code;
    private final String description;

    ErrorCode(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}