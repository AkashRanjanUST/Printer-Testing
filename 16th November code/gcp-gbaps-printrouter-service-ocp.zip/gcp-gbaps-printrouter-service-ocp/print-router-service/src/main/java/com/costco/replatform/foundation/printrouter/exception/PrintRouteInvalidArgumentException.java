package com.costco.replatform.foundation.printrouter.exception;

public class PrintRouteInvalidArgumentException extends RuntimeException {
	
	 public PrintRouteInvalidArgumentException() {
	        super();
	    }

	    public PrintRouteInvalidArgumentException(String message) {
	        super(message);
	    }

	    public PrintRouteInvalidArgumentException(String message, Throwable cause) {
	        super(message, cause);
	    }

	    public PrintRouteInvalidArgumentException(Throwable cause) {
	        super(cause);
	    }
	    

}
