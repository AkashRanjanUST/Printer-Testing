package com.costco.replatform.foundation.printrouter.model;

public class PrintRouteResponse {
	
	private String locationId;
	private String printerName;
	private Integer printJobId;
	private String printStatus;
	private String printerIp;	
	

	public String getPrinterIp() {
		return printerIp;
	}

	public void setPrinterIp(String printerIp) {
		this.printerIp = printerIp;
	}

	public String getPrintStatus() {
		return printStatus;
	}

	public void setPrintStatus(String printStatus) {
		this.printStatus = printStatus;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getPrinterName() {
		return printerName;
	}

	public void setPrinterName(String printerName) {
		this.printerName = printerName;
	}

	public Integer getPrintJobId() {
		return printJobId;
	}

	public void setPrintJobId(Integer printJobId) {
		this.printJobId = printJobId;
	}
	
	@Override
	public String toString() {
	    return "PrintRouteResponse{" +
	            "locationId='" + locationId + '\'' +
	            ", printerName='" + printerName + '\'' +
	            ", printerJobId=" + printJobId +
	            ", printStatus='" + printStatus + '\'' +
	            '}';
	}
	

}
