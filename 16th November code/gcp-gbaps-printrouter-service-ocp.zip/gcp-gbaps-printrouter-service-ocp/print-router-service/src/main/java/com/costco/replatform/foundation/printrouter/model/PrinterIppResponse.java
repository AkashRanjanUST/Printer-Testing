package com.costco.replatform.foundation.printrouter.model;

public class PrinterIppResponse {

	private boolean ok;

	private String transId;

	private int status;

	private String message;

	private String printerName;
	
	private String printerIp;

	private Integer printJobId;

	private String printJobStatus;
	
	
	


	public String getPrinterIp() {
		return printerIp;
	}

	public void setPrinterIp(String printerIp) {
		this.printerIp = printerIp;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	// Getters and Setters
	public boolean isOk() {
		return ok;
	}

	public void setOk(boolean ok) {
		this.ok = ok;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}
	
	
	public int getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		if (status != null) { // Workaround for not changing the APIGEE contract in 603 project, But in 645
								// needs to be Integer and null need to show in response
			this.status = status;
		}
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPrinterName() {
		return printerName;
	}

	public void setPrinterName(String printerName) {
		this.printerName = printerName;
	}

	public Integer getPrintJobId() {
		return printJobId;
	}

	public void setPrintJobId(Integer printJobId) {
		this.printJobId = printJobId;
	}

	public String getPrintJobStatus() {
		return printJobStatus;
	}

	public void setPrintJobStatus(String printJobStatus) {
		this.printJobStatus = printJobStatus;
	}
	
	@Override
	public String toString() {
	    return "PrinterIppResponse{" +
	            "ok=" + ok +
	             ", printerIp='" + printerIp + '\'' +
	            ", transId='" + transId + '\'' +
	            ", status=" + status +
	            ", message='" + message + '\'' +
	            ", printerName='" + printerName + '\'' +
	            ", printJobId='" + printJobId + '\'' +
	            ", printJobStatus='" + printJobStatus + '\'' +
	            '}';
	}

}
