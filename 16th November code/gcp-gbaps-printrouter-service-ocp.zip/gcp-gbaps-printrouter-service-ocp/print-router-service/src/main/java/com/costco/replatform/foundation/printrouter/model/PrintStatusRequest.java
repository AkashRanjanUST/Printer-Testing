package com.costco.replatform.foundation.printrouter.model;


public class PrintStatusRequest {

	 private Integer itemNo;
	 
	 private String printerName;
	 
	 private Integer printJobId;
	 
	 private String printerIp;
	 
	 

	 public String getPrinterIp() {
		return printerIp;
	}

	 public void setPrinterIp(String printerIp) {
		 this.printerIp = printerIp;
	 }

	 public Integer getItemNo() {
		 return itemNo;
	 }

	 public void setItemNo(Integer itemNo) {
		 this.itemNo = itemNo;
	 }

	 public String getPrinterName() {
		 return printerName;
	 }

	 public void setPrinterName(String printerName) {
		 this.printerName = printerName;
	 }

	 public Integer getPrintJobId() {
		 return printJobId;
	 }

	 public void setPrintJobId(Integer printJobId) {
		 this.printJobId = printJobId;
	 }
	 
	 


}
